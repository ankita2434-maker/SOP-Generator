const mammoth = __vite__cjsImport0_mammoth;import __vite__cjsImport0_mammoth from "/node_modules/.vite/deps/mammoth.js?v=aba35700";
export async function extractTextFromFile(file) {
	const extension = file.name.split(".").pop()?.toLowerCase();
	const filename = file.name;
	if (extension === "txt" || extension === "md") {
		const text = await file.text();
		return {
			text: text.trim(),
			filename
		};
	}
	if (extension === "docx") {
		const arrayBuffer = await file.arrayBuffer();
		const result = await mammoth.extractRawText({ arrayBuffer });
		return {
			text: result.value.trim(),
			filename
		};
	}
	if (extension === "pdf") {
		// Read raw text if available or arrayBuffer
		const arrayBuffer = await file.arrayBuffer();
		const decoder = new TextDecoder("utf-8", { fatal: false });
		const rawContent = decoder.decode(arrayBuffer);
		// Extract printable stream chunks / text strings from PDF structure
		const textSegments = [];
		const textRegex = /\(([^)]+)\)\s*Tj|\[([^\]]+)\]\s*TJ/g;
		let match;
		while ((match = textRegex.exec(rawContent)) !== null) {
			const matchText = match[1] || match[2] || "";
			// Filter clean ASCII/Unicode text
			const cleaned = matchText.replace(/\\[nrtbf()]/g, " ").replace(/[^\x20-\x7E\s]/g, "");
			if (cleaned.trim().length > 1) {
				textSegments.push(cleaned.trim());
			}
		}
		if (textSegments.length > 5) {
			return {
				text: textSegments.join("\n"),
				filename
			};
		}
		// Fallback if compressed PDF stream: extract readable ASCII character groups
		const asciiMatches = rawContent.match(/[A-Za-z0-9][A-Za-z0-9\s.,:;'"()/-]{10,}/g);
		if (asciiMatches && asciiMatches.length > 0) {
			const filtered = asciiMatches.filter((chunk) => !chunk.includes("obj") && !chunk.includes("endobj") && !chunk.includes("xref") && !chunk.includes("stream")).join("\n");
			return {
				text: filtered.trim(),
				filename
			};
		}
		return {
			text: `[PDF File: ${filename}] - Extracted binary content. If extraction is partial, you can paste plaintext directly.`,
			filename
		};
	}
	// Default fallback for any other text formats
	const fallbackText = await file.text();
	return {
		text: fallbackText.trim(),
		filename
	};
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxhQUFhO0FBRXBCLE9BQU8sZUFBZSxvQkFBb0IsTUFBeUQ7Q0FDakcsTUFBTSxZQUFZLEtBQUssS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxFQUFFLFlBQVk7Q0FDMUQsTUFBTSxXQUFXLEtBQUs7Q0FFdEIsSUFBSSxjQUFjLFNBQVMsY0FBYyxNQUFNO0VBQzdDLE1BQU0sT0FBTyxNQUFNLEtBQUssS0FBSztFQUM3QixPQUFPO0dBQUUsTUFBTSxLQUFLLEtBQUs7R0FBRztFQUFTO0NBQ3ZDO0NBRUEsSUFBSSxjQUFjLFFBQVE7RUFDeEIsTUFBTSxjQUFjLE1BQU0sS0FBSyxZQUFZO0VBQzNDLE1BQU0sU0FBUyxNQUFNLFFBQVEsZUFBZSxFQUFFLFlBQVksQ0FBQztFQUMzRCxPQUFPO0dBQUUsTUFBTSxPQUFPLE1BQU0sS0FBSztHQUFHO0VBQVM7Q0FDL0M7Q0FFQSxJQUFJLGNBQWMsT0FBTzs7RUFFdkIsTUFBTSxjQUFjLE1BQU0sS0FBSyxZQUFZO0VBQzNDLE1BQU0sVUFBVSxJQUFJLFlBQVksU0FBUyxFQUFFLE9BQU8sTUFBTSxDQUFDO0VBQ3pELE1BQU0sYUFBYSxRQUFRLE9BQU8sV0FBVzs7RUFHN0MsTUFBTSxlQUF5QixDQUFDO0VBQ2hDLE1BQU0sWUFBWTtFQUNsQixJQUFJO0VBQ0osUUFBUSxRQUFRLFVBQVUsS0FBSyxVQUFVLE9BQU8sTUFBTTtHQUNwRCxNQUFNLFlBQVksTUFBTSxNQUFNLE1BQU0sTUFBTTs7R0FFMUMsTUFBTSxVQUFVLFVBQVUsUUFBUSxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsUUFBUSxtQkFBbUIsRUFBRTtHQUNwRixJQUFJLFFBQVEsS0FBSyxDQUFDLENBQUMsU0FBUyxHQUFHO0lBQzdCLGFBQWEsS0FBSyxRQUFRLEtBQUssQ0FBQztHQUNsQztFQUNGO0VBRUEsSUFBSSxhQUFhLFNBQVMsR0FBRztHQUMzQixPQUFPO0lBQUUsTUFBTSxhQUFhLEtBQUssSUFBSTtJQUFHO0dBQVM7RUFDbkQ7O0VBR0EsTUFBTSxlQUFlLFdBQVcsTUFBTSwwQ0FBMEM7RUFDaEYsSUFBSSxnQkFBZ0IsYUFBYSxTQUFTLEdBQUc7R0FDM0MsTUFBTSxXQUFXLGFBQ2QsUUFBUSxVQUFVLENBQUMsTUFBTSxTQUFTLEtBQUssS0FBSyxDQUFDLE1BQU0sU0FBUyxRQUFRLEtBQUssQ0FBQyxNQUFNLFNBQVMsTUFBTSxLQUFLLENBQUMsTUFBTSxTQUFTLFFBQVEsQ0FBQyxDQUFDLENBQzlILEtBQUssSUFBSTtHQUNaLE9BQU87SUFBRSxNQUFNLFNBQVMsS0FBSztJQUFHO0dBQVM7RUFDM0M7RUFFQSxPQUFPO0dBQ0wsTUFBTSxjQUFjLFNBQVM7R0FDN0I7RUFDRjtDQUNGOztDQUdBLE1BQU0sZUFBZSxNQUFNLEtBQUssS0FBSztDQUNyQyxPQUFPO0VBQUUsTUFBTSxhQUFhLEtBQUs7RUFBRztDQUFTO0FBQy9DIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInRleHRFeHRyYWN0b3IudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1hbW1vdGggZnJvbSAnbWFtbW90aCc7XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBleHRyYWN0VGV4dEZyb21GaWxlKGZpbGU6IEZpbGUpOiBQcm9taXNlPHsgdGV4dDogc3RyaW5nOyBmaWxlbmFtZTogc3RyaW5nIH0+IHtcbiAgY29uc3QgZXh0ZW5zaW9uID0gZmlsZS5uYW1lLnNwbGl0KCcuJykucG9wKCk/LnRvTG93ZXJDYXNlKCk7XG4gIGNvbnN0IGZpbGVuYW1lID0gZmlsZS5uYW1lO1xuXG4gIGlmIChleHRlbnNpb24gPT09ICd0eHQnIHx8IGV4dGVuc2lvbiA9PT0gJ21kJykge1xuICAgIGNvbnN0IHRleHQgPSBhd2FpdCBmaWxlLnRleHQoKTtcbiAgICByZXR1cm4geyB0ZXh0OiB0ZXh0LnRyaW0oKSwgZmlsZW5hbWUgfTtcbiAgfVxuXG4gIGlmIChleHRlbnNpb24gPT09ICdkb2N4Jykge1xuICAgIGNvbnN0IGFycmF5QnVmZmVyID0gYXdhaXQgZmlsZS5hcnJheUJ1ZmZlcigpO1xuICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IG1hbW1vdGguZXh0cmFjdFJhd1RleHQoeyBhcnJheUJ1ZmZlciB9KTtcbiAgICByZXR1cm4geyB0ZXh0OiByZXN1bHQudmFsdWUudHJpbSgpLCBmaWxlbmFtZSB9O1xuICB9XG5cbiAgaWYgKGV4dGVuc2lvbiA9PT0gJ3BkZicpIHtcbiAgICAvLyBSZWFkIHJhdyB0ZXh0IGlmIGF2YWlsYWJsZSBvciBhcnJheUJ1ZmZlclxuICAgIGNvbnN0IGFycmF5QnVmZmVyID0gYXdhaXQgZmlsZS5hcnJheUJ1ZmZlcigpO1xuICAgIGNvbnN0IGRlY29kZXIgPSBuZXcgVGV4dERlY29kZXIoJ3V0Zi04JywgeyBmYXRhbDogZmFsc2UgfSk7XG4gICAgY29uc3QgcmF3Q29udGVudCA9IGRlY29kZXIuZGVjb2RlKGFycmF5QnVmZmVyKTtcblxuICAgIC8vIEV4dHJhY3QgcHJpbnRhYmxlIHN0cmVhbSBjaHVua3MgLyB0ZXh0IHN0cmluZ3MgZnJvbSBQREYgc3RydWN0dXJlXG4gICAgY29uc3QgdGV4dFNlZ21lbnRzOiBzdHJpbmdbXSA9IFtdO1xuICAgIGNvbnN0IHRleHRSZWdleCA9IC9cXCgoW14pXSspXFwpXFxzKlRqfFxcWyhbXlxcXV0rKVxcXVxccypUSi9nO1xuICAgIGxldCBtYXRjaDtcbiAgICB3aGlsZSAoKG1hdGNoID0gdGV4dFJlZ2V4LmV4ZWMocmF3Q29udGVudCkpICE9PSBudWxsKSB7XG4gICAgICBjb25zdCBtYXRjaFRleHQgPSBtYXRjaFsxXSB8fCBtYXRjaFsyXSB8fCAnJztcbiAgICAgIC8vIEZpbHRlciBjbGVhbiBBU0NJSS9Vbmljb2RlIHRleHRcbiAgICAgIGNvbnN0IGNsZWFuZWQgPSBtYXRjaFRleHQucmVwbGFjZSgvXFxcXFtucnRiZigpXS9nLCAnICcpLnJlcGxhY2UoL1teXFx4MjAtXFx4N0VcXHNdL2csICcnKTtcbiAgICAgIGlmIChjbGVhbmVkLnRyaW0oKS5sZW5ndGggPiAxKSB7XG4gICAgICAgIHRleHRTZWdtZW50cy5wdXNoKGNsZWFuZWQudHJpbSgpKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAodGV4dFNlZ21lbnRzLmxlbmd0aCA+IDUpIHtcbiAgICAgIHJldHVybiB7IHRleHQ6IHRleHRTZWdtZW50cy5qb2luKCdcXG4nKSwgZmlsZW5hbWUgfTtcbiAgICB9XG5cbiAgICAvLyBGYWxsYmFjayBpZiBjb21wcmVzc2VkIFBERiBzdHJlYW06IGV4dHJhY3QgcmVhZGFibGUgQVNDSUkgY2hhcmFjdGVyIGdyb3Vwc1xuICAgIGNvbnN0IGFzY2lpTWF0Y2hlcyA9IHJhd0NvbnRlbnQubWF0Y2goL1tBLVphLXowLTldW0EtWmEtejAtOVxccy4sOjsnXCIoKS8tXXsxMCx9L2cpO1xuICAgIGlmIChhc2NpaU1hdGNoZXMgJiYgYXNjaWlNYXRjaGVzLmxlbmd0aCA+IDApIHtcbiAgICAgIGNvbnN0IGZpbHRlcmVkID0gYXNjaWlNYXRjaGVzXG4gICAgICAgIC5maWx0ZXIoKGNodW5rKSA9PiAhY2h1bmsuaW5jbHVkZXMoJ29iaicpICYmICFjaHVuay5pbmNsdWRlcygnZW5kb2JqJykgJiYgIWNodW5rLmluY2x1ZGVzKCd4cmVmJykgJiYgIWNodW5rLmluY2x1ZGVzKCdzdHJlYW0nKSlcbiAgICAgICAgLmpvaW4oJ1xcbicpO1xuICAgICAgcmV0dXJuIHsgdGV4dDogZmlsdGVyZWQudHJpbSgpLCBmaWxlbmFtZSB9O1xuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICB0ZXh0OiBgW1BERiBGaWxlOiAke2ZpbGVuYW1lfV0gLSBFeHRyYWN0ZWQgYmluYXJ5IGNvbnRlbnQuIElmIGV4dHJhY3Rpb24gaXMgcGFydGlhbCwgeW91IGNhbiBwYXN0ZSBwbGFpbnRleHQgZGlyZWN0bHkuYCxcbiAgICAgIGZpbGVuYW1lLFxuICAgIH07XG4gIH1cblxuICAvLyBEZWZhdWx0IGZhbGxiYWNrIGZvciBhbnkgb3RoZXIgdGV4dCBmb3JtYXRzXG4gIGNvbnN0IGZhbGxiYWNrVGV4dCA9IGF3YWl0IGZpbGUudGV4dCgpO1xuICByZXR1cm4geyB0ZXh0OiBmYWxsYmFja1RleHQudHJpbSgpLCBmaWxlbmFtZSB9O1xufVxuIl19