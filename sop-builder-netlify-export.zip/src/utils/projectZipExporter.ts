const JSZip = __vite__cjsImport0_jszip;import __vite__cjsImport0_jszip from "/node_modules/.vite/deps/jszip.js?v=aba35700";
export async function generateProjectZip() {
	const zip = new JSZip();
	// Root files
	zip.file("netlify.toml", `[build]
  command = "npm run build"
  publish = "dist"
  functions = "netlify/functions"

[[redirects]]
  from = "/api/generate-sop"
  to = "/.netlify/functions/generate-sop"
  status = 200

[[redirects]]
  from = "/api/verify-passcode"
  to = "/.netlify/functions/verify-passcode"
  status = 200

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
`);
	zip.file(".env.example", `# GEMINI_API_KEY: Your Google Gemini API Key from https://aistudio.google.com/app/apikey
GEMINI_API_KEY="your-gemini-api-key-here"

# SOP_PASSCODE: Shared team passcode (defaults to ops-auth-8492-team if unset)
SOP_PASSCODE="ops-auth-8492-team"
`);
	zip.file(".gitignore", `node_modules
dist
.env
.env.local
.DS_Store
`);
	zip.file("README.md", `# SOP Builder - HR & Operations Standard Operating Procedure Generator

A lightweight, portable web application built for HR and Operations teams to turn messy operational notes, Slack logs, audio transcripts, and meeting minutes into auditable, standardized SOPs.

## Deploying to Netlify (Non-Developer Step-by-Step Guide)

### Step 1: Push to GitHub or GitLab
1. Unzip this package.
2. Initialize git in the folder:
   \`\`\`bash
   git init
   git add .
   git commit -m "Initial commit for SOP Builder"
   \`\`\`
3. Create a new repository on [GitHub](https://github.com/new) and push the code:
   \`\`\`bash
   git remote add origin https://github.com/YOUR_USERNAME/sop-builder.git
   git branch -M main
   git push -u origin main
   \`\`\`

### Step 2: Connect to Netlify
1. Log in to [Netlify](https://app.netlify.com).
2. Click **"Add new site"** -> **"Import an existing project"**.
3. Choose **GitHub** and select your \`sop-builder\` repository.
4. Netlify will automatically detect the settings from \`netlify.toml\`:
   - **Build command:** \`npm run build\`
   - **Publish directory:** \`dist\`
   - **Functions directory:** \`netlify/functions\`

### Step 3: Add Environment Variables in Netlify (CRITICAL)
Before clicking Deploy, click **"Add environment variables"** (or go to **Site configuration > Environment variables** after creation):

1. **\`GEMINI_API_KEY\`**:
   - Go to [Google AI Studio API Keys](https://aistudio.google.com/app/apikey)
   - Click "Create API Key", copy it, and paste it as the value for \`GEMINI_API_KEY\`.
2. **\`SOP_PASSCODE\`**:
   - Set any team passcode of your choice, e.g. \`ops-auth-8492-team\` or \`acme-hr-sop-2025\`.

### Step 4: Deploy Site
- Click **"Deploy sop-builder"**.
- In 1-2 minutes, your live site will be ready at your Netlify URL (e.g., \`https://sop-builder-acme.netlify.app\`).
`);
	// We can fetch or include the core template files
	// For client-side zip creation, fetch files from window.location.origin
	const filesToFetch = [
		"package.json",
		"tsconfig.json",
		"vite.config.ts",
		"index.html",
		"server.ts",
		"metadata.json",
		"src/main.tsx",
		"src/App.tsx",
		"src/index.css",
		"src/types/sop.ts",
		"src/data/templates.ts",
		"src/utils/textExtractor.ts",
		"src/utils/exporter.ts",
		"src/utils/projectZipExporter.ts",
		"server/geminiService.ts",
		"netlify/functions/generate-sop.ts",
		"netlify/functions/verify-passcode.ts"
	];
	for (const filePath of filesToFetch) {
		try {
			const response = await fetch(`/${filePath}`);
			if (response.ok) {
				const text = await response.text();
				zip.file(filePath, text);
			}
		} catch (e) {
			console.warn(`Could not add ${filePath} from server directly`, e);
		}
	}
	return await zip.generateAsync({ type: "blob" });
}
export function downloadProjectZip(blob) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = "sop-builder-netlify-export.zip";
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
	URL.revokeObjectURL(url);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLE9BQU8sZUFBZSxxQkFBb0M7Q0FDeEQsTUFBTSxNQUFNLElBQUksTUFBTTs7Q0FHdEIsSUFBSSxLQUNGLGdCQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBb0JGO0NBRUEsSUFBSSxLQUNGLGdCQUNBOzs7OztDQU1GO0NBRUEsSUFBSSxLQUNGLGNBQ0E7Ozs7O0NBTUY7Q0FFQSxJQUFJLEtBQ0YsYUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMkNGOzs7Q0FJQSxNQUFNLGVBQWU7RUFDbkI7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGO0NBRUEsS0FBSyxNQUFNLFlBQVksY0FBYztFQUNuQyxJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTSxJQUFJLFVBQVU7R0FDM0MsSUFBSSxTQUFTLElBQUk7SUFDZixNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUs7SUFDakMsSUFBSSxLQUFLLFVBQVUsSUFBSTtHQUN6QjtFQUNGLFNBQVMsR0FBRztHQUNWLFFBQVEsS0FBSyxpQkFBaUIsU0FBUyx3QkFBd0IsQ0FBQztFQUNsRTtDQUNGO0NBRUEsT0FBTyxNQUFNLElBQUksY0FBYyxFQUFFLE1BQU0sT0FBTyxDQUFDO0FBQ2pEO0FBRUEsT0FBTyxTQUFTLG1CQUFtQixNQUFZO0NBQzdDLE1BQU0sTUFBTSxJQUFJLGdCQUFnQixJQUFJO0NBQ3BDLE1BQU0sSUFBSSxTQUFTLGNBQWMsR0FBRztDQUNwQyxFQUFFLE9BQU87Q0FDVCxFQUFFLFdBQVc7Q0FDYixTQUFTLEtBQUssWUFBWSxDQUFDO0NBQzNCLEVBQUUsTUFBTTtDQUNSLFNBQVMsS0FBSyxZQUFZLENBQUM7Q0FDM0IsSUFBSSxnQkFBZ0IsR0FBRztBQUN6QiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJwcm9qZWN0WmlwRXhwb3J0ZXIudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEpTWmlwIGZyb20gJ2pzemlwJztcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdlbmVyYXRlUHJvamVjdFppcCgpOiBQcm9taXNlPEJsb2I+IHtcbiAgY29uc3QgemlwID0gbmV3IEpTWmlwKCk7XG5cbiAgLy8gUm9vdCBmaWxlc1xuICB6aXAuZmlsZShcbiAgICAnbmV0bGlmeS50b21sJyxcbiAgICBgW2J1aWxkXVxuICBjb21tYW5kID0gXCJucG0gcnVuIGJ1aWxkXCJcbiAgcHVibGlzaCA9IFwiZGlzdFwiXG4gIGZ1bmN0aW9ucyA9IFwibmV0bGlmeS9mdW5jdGlvbnNcIlxuXG5bW3JlZGlyZWN0c11dXG4gIGZyb20gPSBcIi9hcGkvZ2VuZXJhdGUtc29wXCJcbiAgdG8gPSBcIi8ubmV0bGlmeS9mdW5jdGlvbnMvZ2VuZXJhdGUtc29wXCJcbiAgc3RhdHVzID0gMjAwXG5cbltbcmVkaXJlY3RzXV1cbiAgZnJvbSA9IFwiL2FwaS92ZXJpZnktcGFzc2NvZGVcIlxuICB0byA9IFwiLy5uZXRsaWZ5L2Z1bmN0aW9ucy92ZXJpZnktcGFzc2NvZGVcIlxuICBzdGF0dXMgPSAyMDBcblxuW1tyZWRpcmVjdHNdXVxuICBmcm9tID0gXCIvKlwiXG4gIHRvID0gXCIvaW5kZXguaHRtbFwiXG4gIHN0YXR1cyA9IDIwMFxuYFxuICApO1xuXG4gIHppcC5maWxlKFxuICAgICcuZW52LmV4YW1wbGUnLFxuICAgIGAjIEdFTUlOSV9BUElfS0VZOiBZb3VyIEdvb2dsZSBHZW1pbmkgQVBJIEtleSBmcm9tIGh0dHBzOi8vYWlzdHVkaW8uZ29vZ2xlLmNvbS9hcHAvYXBpa2V5XG5HRU1JTklfQVBJX0tFWT1cInlvdXItZ2VtaW5pLWFwaS1rZXktaGVyZVwiXG5cbiMgU09QX1BBU1NDT0RFOiBTaGFyZWQgdGVhbSBwYXNzY29kZSAoZGVmYXVsdHMgdG8gb3BzLWF1dGgtODQ5Mi10ZWFtIGlmIHVuc2V0KVxuU09QX1BBU1NDT0RFPVwib3BzLWF1dGgtODQ5Mi10ZWFtXCJcbmBcbiAgKTtcblxuICB6aXAuZmlsZShcbiAgICAnLmdpdGlnbm9yZScsXG4gICAgYG5vZGVfbW9kdWxlc1xuZGlzdFxuLmVudlxuLmVudi5sb2NhbFxuLkRTX1N0b3JlXG5gXG4gICk7XG5cbiAgemlwLmZpbGUoXG4gICAgJ1JFQURNRS5tZCcsXG4gICAgYCMgU09QIEJ1aWxkZXIgLSBIUiAmIE9wZXJhdGlvbnMgU3RhbmRhcmQgT3BlcmF0aW5nIFByb2NlZHVyZSBHZW5lcmF0b3JcblxuQSBsaWdodHdlaWdodCwgcG9ydGFibGUgd2ViIGFwcGxpY2F0aW9uIGJ1aWx0IGZvciBIUiBhbmQgT3BlcmF0aW9ucyB0ZWFtcyB0byB0dXJuIG1lc3N5IG9wZXJhdGlvbmFsIG5vdGVzLCBTbGFjayBsb2dzLCBhdWRpbyB0cmFuc2NyaXB0cywgYW5kIG1lZXRpbmcgbWludXRlcyBpbnRvIGF1ZGl0YWJsZSwgc3RhbmRhcmRpemVkIFNPUHMuXG5cbiMjIERlcGxveWluZyB0byBOZXRsaWZ5IChOb24tRGV2ZWxvcGVyIFN0ZXAtYnktU3RlcCBHdWlkZSlcblxuIyMjIFN0ZXAgMTogUHVzaCB0byBHaXRIdWIgb3IgR2l0TGFiXG4xLiBVbnppcCB0aGlzIHBhY2thZ2UuXG4yLiBJbml0aWFsaXplIGdpdCBpbiB0aGUgZm9sZGVyOlxuICAgXFxgXFxgXFxgYmFzaFxuICAgZ2l0IGluaXRcbiAgIGdpdCBhZGQgLlxuICAgZ2l0IGNvbW1pdCAtbSBcIkluaXRpYWwgY29tbWl0IGZvciBTT1AgQnVpbGRlclwiXG4gICBcXGBcXGBcXGBcbjMuIENyZWF0ZSBhIG5ldyByZXBvc2l0b3J5IG9uIFtHaXRIdWJdKGh0dHBzOi8vZ2l0aHViLmNvbS9uZXcpIGFuZCBwdXNoIHRoZSBjb2RlOlxuICAgXFxgXFxgXFxgYmFzaFxuICAgZ2l0IHJlbW90ZSBhZGQgb3JpZ2luIGh0dHBzOi8vZ2l0aHViLmNvbS9ZT1VSX1VTRVJOQU1FL3NvcC1idWlsZGVyLmdpdFxuICAgZ2l0IGJyYW5jaCAtTSBtYWluXG4gICBnaXQgcHVzaCAtdSBvcmlnaW4gbWFpblxuICAgXFxgXFxgXFxgXG5cbiMjIyBTdGVwIDI6IENvbm5lY3QgdG8gTmV0bGlmeVxuMS4gTG9nIGluIHRvIFtOZXRsaWZ5XShodHRwczovL2FwcC5uZXRsaWZ5LmNvbSkuXG4yLiBDbGljayAqKlwiQWRkIG5ldyBzaXRlXCIqKiAtPiAqKlwiSW1wb3J0IGFuIGV4aXN0aW5nIHByb2plY3RcIioqLlxuMy4gQ2hvb3NlICoqR2l0SHViKiogYW5kIHNlbGVjdCB5b3VyIFxcYHNvcC1idWlsZGVyXFxgIHJlcG9zaXRvcnkuXG40LiBOZXRsaWZ5IHdpbGwgYXV0b21hdGljYWxseSBkZXRlY3QgdGhlIHNldHRpbmdzIGZyb20gXFxgbmV0bGlmeS50b21sXFxgOlxuICAgLSAqKkJ1aWxkIGNvbW1hbmQ6KiogXFxgbnBtIHJ1biBidWlsZFxcYFxuICAgLSAqKlB1Ymxpc2ggZGlyZWN0b3J5OioqIFxcYGRpc3RcXGBcbiAgIC0gKipGdW5jdGlvbnMgZGlyZWN0b3J5OioqIFxcYG5ldGxpZnkvZnVuY3Rpb25zXFxgXG5cbiMjIyBTdGVwIDM6IEFkZCBFbnZpcm9ubWVudCBWYXJpYWJsZXMgaW4gTmV0bGlmeSAoQ1JJVElDQUwpXG5CZWZvcmUgY2xpY2tpbmcgRGVwbG95LCBjbGljayAqKlwiQWRkIGVudmlyb25tZW50IHZhcmlhYmxlc1wiKiogKG9yIGdvIHRvICoqU2l0ZSBjb25maWd1cmF0aW9uID4gRW52aXJvbm1lbnQgdmFyaWFibGVzKiogYWZ0ZXIgY3JlYXRpb24pOlxuXG4xLiAqKlxcYEdFTUlOSV9BUElfS0VZXFxgKio6XG4gICAtIEdvIHRvIFtHb29nbGUgQUkgU3R1ZGlvIEFQSSBLZXlzXShodHRwczovL2Fpc3R1ZGlvLmdvb2dsZS5jb20vYXBwL2FwaWtleSlcbiAgIC0gQ2xpY2sgXCJDcmVhdGUgQVBJIEtleVwiLCBjb3B5IGl0LCBhbmQgcGFzdGUgaXQgYXMgdGhlIHZhbHVlIGZvciBcXGBHRU1JTklfQVBJX0tFWVxcYC5cbjIuICoqXFxgU09QX1BBU1NDT0RFXFxgKio6XG4gICAtIFNldCBhbnkgdGVhbSBwYXNzY29kZSBvZiB5b3VyIGNob2ljZSwgZS5nLiBcXGBvcHMtYXV0aC04NDkyLXRlYW1cXGAgb3IgXFxgYWNtZS1oci1zb3AtMjAyNVxcYC5cblxuIyMjIFN0ZXAgNDogRGVwbG95IFNpdGVcbi0gQ2xpY2sgKipcIkRlcGxveSBzb3AtYnVpbGRlclwiKiouXG4tIEluIDEtMiBtaW51dGVzLCB5b3VyIGxpdmUgc2l0ZSB3aWxsIGJlIHJlYWR5IGF0IHlvdXIgTmV0bGlmeSBVUkwgKGUuZy4sIFxcYGh0dHBzOi8vc29wLWJ1aWxkZXItYWNtZS5uZXRsaWZ5LmFwcFxcYCkuXG5gXG4gICk7XG5cbiAgLy8gV2UgY2FuIGZldGNoIG9yIGluY2x1ZGUgdGhlIGNvcmUgdGVtcGxhdGUgZmlsZXNcbiAgLy8gRm9yIGNsaWVudC1zaWRlIHppcCBjcmVhdGlvbiwgZmV0Y2ggZmlsZXMgZnJvbSB3aW5kb3cubG9jYXRpb24ub3JpZ2luXG4gIGNvbnN0IGZpbGVzVG9GZXRjaCA9IFtcbiAgICAncGFja2FnZS5qc29uJyxcbiAgICAndHNjb25maWcuanNvbicsXG4gICAgJ3ZpdGUuY29uZmlnLnRzJyxcbiAgICAnaW5kZXguaHRtbCcsXG4gICAgJ3NlcnZlci50cycsXG4gICAgJ21ldGFkYXRhLmpzb24nLFxuICAgICdzcmMvbWFpbi50c3gnLFxuICAgICdzcmMvQXBwLnRzeCcsXG4gICAgJ3NyYy9pbmRleC5jc3MnLFxuICAgICdzcmMvdHlwZXMvc29wLnRzJyxcbiAgICAnc3JjL2RhdGEvdGVtcGxhdGVzLnRzJyxcbiAgICAnc3JjL3V0aWxzL3RleHRFeHRyYWN0b3IudHMnLFxuICAgICdzcmMvdXRpbHMvZXhwb3J0ZXIudHMnLFxuICAgICdzcmMvdXRpbHMvcHJvamVjdFppcEV4cG9ydGVyLnRzJyxcbiAgICAnc2VydmVyL2dlbWluaVNlcnZpY2UudHMnLFxuICAgICduZXRsaWZ5L2Z1bmN0aW9ucy9nZW5lcmF0ZS1zb3AudHMnLFxuICAgICduZXRsaWZ5L2Z1bmN0aW9ucy92ZXJpZnktcGFzc2NvZGUudHMnLFxuICBdO1xuXG4gIGZvciAoY29uc3QgZmlsZVBhdGggb2YgZmlsZXNUb0ZldGNoKSB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYC8ke2ZpbGVQYXRofWApO1xuICAgICAgaWYgKHJlc3BvbnNlLm9rKSB7XG4gICAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gICAgICAgIHppcC5maWxlKGZpbGVQYXRoLCB0ZXh0KTtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICBjb25zb2xlLndhcm4oYENvdWxkIG5vdCBhZGQgJHtmaWxlUGF0aH0gZnJvbSBzZXJ2ZXIgZGlyZWN0bHlgLCBlKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gYXdhaXQgemlwLmdlbmVyYXRlQXN5bmMoeyB0eXBlOiAnYmxvYicgfSk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkb3dubG9hZFByb2plY3RaaXAoYmxvYjogQmxvYikge1xuICBjb25zdCB1cmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGJsb2IpO1xuICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICBhLmhyZWYgPSB1cmw7XG4gIGEuZG93bmxvYWQgPSAnc29wLWJ1aWxkZXItbmV0bGlmeS1leHBvcnQuemlwJztcbiAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChhKTtcbiAgYS5jbGljaygpO1xuICBkb2N1bWVudC5ib2R5LnJlbW92ZUNoaWxkKGEpO1xuICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XG59XG4iXX0=