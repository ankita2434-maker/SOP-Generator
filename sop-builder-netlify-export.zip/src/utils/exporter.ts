import { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType, ShadingType } from "/node_modules/.vite/deps/docx.js?v=aba35700";
import jsPDF from "/node_modules/.vite/deps/jspdf.js?v=aba35700";
/**
* Download real formatted Word document (.docx)
*/
export async function downloadAsDocx(doc) {
	const unresolvedMissing = doc.missing_fields.filter((m) => !m.resolved);
	const isApproved = doc.status === "APPROVED";
	const children = [];
	// Top Status Header / Draft Marker
	children.push(new Paragraph({
		children: [new TextRun({
			text: isApproved ? "APPROVED STANDARD OPERATING PROCEDURE" : "DRAFT — HUMAN REVIEW REQUIRED BEFORE PUBLISHING",
			bold: true,
			color: isApproved ? "006948" : "B45309",
			size: 20
		})],
		spacing: { after: 120 }
	}));
	// Document Title
	children.push(new Paragraph({
		text: doc.title,
		heading: HeadingLevel.TITLE,
		spacing: { after: 120 }
	}));
	// Document Sub-info
	children.push(new Paragraph({
		children: [new TextRun({
			text: `Document Identifier: ${doc.code}  |  Department: ${doc.department}  |  Status: ${doc.status}`,
			bold: true,
			color: "515F74",
			size: 18
		})],
		spacing: { after: 240 }
	}));
	// Unresolved Missing Fields Callout
	if (unresolvedMissing.length > 0) {
		children.push(new Paragraph({
			children: [new TextRun({
				text: `[ACTION REQUIRED — ${unresolvedMissing.length} UNRESOLVED MISSING ITEM(S)]`,
				bold: true,
				color: "BA1A1A",
				size: 20
			})],
			spacing: {
				before: 120,
				after: 80
			}
		}));
		unresolvedMissing.forEach((item, index) => {
			children.push(new Paragraph({
				children: [
					new TextRun({
						text: `• ${item.field_name}: `,
						bold: true,
						color: "BA1A1A"
					}),
					new TextRun({
						text: item.issue_description,
						italics: true
					}),
					new TextRun({
						text: " — [MISSING — not found in source notes]",
						color: "BA1A1A"
					})
				],
				spacing: { after: 60 }
			}));
		});
		children.push(new Paragraph({ spacing: { after: 200 } }));
	}
	// Sections
	doc.sections.forEach((sec, sIdx) => {
		// Section Header with Confidence Badge
		children.push(new Paragraph({
			children: [new TextRun({
				text: sec.field_name,
				bold: true,
				size: 26,
				color: "0037B0"
			}), new TextRun({
				text: `  [Confidence: ${sec.confidence.toUpperCase()}${sec.user_edited ? " - Human Edited" : ""}]`,
				bold: true,
				size: 18,
				color: sec.confidence === "high" ? "006948" : sec.confidence === "medium" ? "B45309" : "BA1A1A"
			})],
			heading: HeadingLevel.HEADING_2,
			spacing: {
				before: 240,
				after: 120
			}
		}));
		// Section Content
		const paragraphs = sec.content.split("\n\n");
		paragraphs.forEach((pText) => {
			const cleanP = pText.trim();
			if (!cleanP) return;
			if (cleanP.startsWith("•") || cleanP.startsWith("-") || cleanP.startsWith("*")) {
				children.push(new Paragraph({
					text: cleanP,
					bullet: { level: 0 },
					spacing: { after: 80 }
				}));
			} else {
				children.push(new Paragraph({
					text: cleanP,
					spacing: { after: 120 }
				}));
			}
		});
		// Sub-steps if any
		if (sec.sub_steps && sec.sub_steps.length > 0) {
			sec.sub_steps.forEach((step) => {
				children.push(new Paragraph({
					children: [new TextRun({
						text: `Step ${step.step_number}: ${step.title}`,
						bold: true,
						color: "1D4ED8"
					}), step.sla ? new TextRun({
						text: ` [SLA: ${step.sla}]`,
						bold: true,
						color: "515F74"
					}) : new TextRun("")],
					spacing: {
						before: 100,
						after: 60
					}
				}));
				children.push(new Paragraph({
					text: step.description,
					spacing: { after: 100 }
				}));
			});
		}
		// Evidence Quotes Callout Box
		if (sec.evidence_quotes && sec.evidence_quotes.length > 0) {
			children.push(new Paragraph({
				children: [new TextRun({
					text: "Source Evidence Traceability:",
					bold: true,
					italics: true,
					size: 18,
					color: "515F74"
				})],
				spacing: {
					before: 100,
					after: 60
				}
			}));
			sec.evidence_quotes.forEach((quote) => {
				children.push(new Paragraph({
					children: [new TextRun({
						text: `"${quote}"`,
						italics: true,
						color: "434655"
					})],
					spacing: { after: 60 }
				}));
			});
		}
		children.push(new Paragraph({ spacing: { after: 160 } }));
	});
	// Governance and Metadata Table
	children.push(new Paragraph({
		text: "Document Governance & Control Metadata",
		heading: HeadingLevel.HEADING_2,
		spacing: {
			before: 240,
			after: 120
		}
	}));
	const tableRows = [
		new TableRow({ children: [new TableCell({
			children: [new Paragraph({ children: [new TextRun({
				text: "Metadata Field",
				bold: true
			})] })],
			shading: {
				fill: "EFF4FF",
				type: ShadingType.CLEAR,
				color: "auto"
			},
			width: {
				size: 3e3,
				type: WidthType.DXA
			}
		}), new TableCell({
			children: [new Paragraph({ children: [new TextRun({
				text: "Value",
				bold: true
			})] })],
			shading: {
				fill: "EFF4FF",
				type: ShadingType.CLEAR,
				color: "auto"
			},
			width: {
				size: 6e3,
				type: WidthType.DXA
			}
		})] }),
		new TableRow({ children: [new TableCell({ children: [new Paragraph("Document Code")] }), new TableCell({ children: [new Paragraph(doc.code || "SOP-8492")] })] }),
		new TableRow({ children: [new TableCell({ children: [new Paragraph("Version")] }), new TableCell({ children: [new Paragraph(doc.version || "1.0 (Draft)")] })] }),
		new TableRow({ children: [new TableCell({ children: [new Paragraph("Process Owner")] }), new TableCell({ children: [new Paragraph(doc.owner || "[MISSING — not found in source notes]")] })] }),
		new TableRow({ children: [new TableCell({ children: [new Paragraph("Effective Date")] }), new TableCell({ children: [new Paragraph(doc.effective_date || "[MISSING — not found in source notes]")] })] }),
		new TableRow({ children: [new TableCell({ children: [new Paragraph("Review Cadence")] }), new TableCell({ children: [new Paragraph(doc.review_cycle || "Annual")] })] }),
		new TableRow({ children: [new TableCell({ children: [new Paragraph("Compliance Standard")] }), new TableCell({ children: [new Paragraph(doc.compliance_standard || "SOC 2 Type II / ISO 9001")] })] }),
		new TableRow({ children: [new TableCell({ children: [new Paragraph("Classification")] }), new TableCell({ children: [new Paragraph(doc.classification || "Internal Confidential")] })] })
	];
	const govTable = new Table({
		rows: tableRows,
		width: {
			size: 9e3,
			type: WidthType.DXA
		}
	});
	children.push(govTable);
	const wordDoc = new Document({ sections: [{
		properties: {},
		children
	}] });
	const blob = await Packer.toBlob(wordDoc);
	const cleanTitle = (doc.title || "SOP").replace(/[^a-zA-Z0-9_-]/g, "_");
	downloadBlob(blob, `${doc.code || "SOP"}_${cleanTitle}.docx`);
}
/**
* Download real formatted PDF
*/
export function downloadAsPdf(doc) {
	const pdf = new jsPDF({
		orientation: "portrait",
		unit: "pt",
		format: "a4"
	});
	const pageWidth = pdf.internal.pageSize.getWidth();
	const pageHeight = pdf.internal.pageSize.getHeight();
	const margin = 40;
	const contentWidth = pageWidth - margin * 2;
	let y = margin;
	function checkPageBreak(requiredHeight) {
		if (y + requiredHeight > pageHeight - margin) {
			pdf.addPage();
			y = margin;
		}
	}
	// Header band
	const isApproved = doc.status === "APPROVED";
	pdf.setFillColor(isApproved ? 209 : 254, isApproved ? 250 : 243, isApproved ? 229 : 199);
	pdf.rect(margin, y, contentWidth, 24, "F");
	pdf.setTextColor(isApproved ? 4 : 180, isApproved ? 120 : 83, isApproved ? 87 : 9);
	pdf.setFont("helvetica", "bold");
	pdf.setFontSize(10);
	pdf.text(isApproved ? "APPROVED STANDARD OPERATING PROCEDURE" : "DRAFT — HUMAN REVIEW REQUIRED BEFORE PUBLISHING", margin + 10, y + 16);
	y += 34;
	// Title
	pdf.setTextColor(11, 28, 48);
	pdf.setFont("helvetica", "bold");
	pdf.setFontSize(18);
	const titleLines = pdf.splitTextToSize(doc.title, contentWidth);
	pdf.text(titleLines, margin, y);
	y += titleLines.length * 22;
	// Metadata Subline
	pdf.setTextColor(81, 95, 116);
	pdf.setFont("helvetica", "normal");
	pdf.setFontSize(10);
	pdf.text(`Code: ${doc.code}  |  Department: ${doc.department}  |  Status: ${doc.status}  |  Version: ${doc.version}`, margin, y);
	y += 20;
	// Missing Fields Warning if any
	const unresolved = doc.missing_fields.filter((m) => !m.resolved);
	if (unresolved.length > 0) {
		checkPageBreak(50 + unresolved.length * 16);
		pdf.setDrawColor(245, 158, 11);
		pdf.setFillColor(254, 243, 199);
		pdf.roundedRect(margin, y, contentWidth, 24 + unresolved.length * 16, 4, 4, "FD");
		pdf.setTextColor(180, 83, 9);
		pdf.setFont("helvetica", "bold");
		pdf.setFontSize(11);
		pdf.text(`Missing Information (${unresolved.length} items found) — Action Needed:`, margin + 10, y + 16);
		let my = y + 32;
		pdf.setFont("helvetica", "normal");
		pdf.setFontSize(9);
		unresolved.forEach((item) => {
			pdf.text(`• ${item.field_name}: ${item.issue_description} [MISSING — not found in notes]`, margin + 14, my);
			my += 14;
		});
		y += 32 + unresolved.length * 16 + 10;
	}
	// Sections
	doc.sections.forEach((sec) => {
		checkPageBreak(60);
		// Section title
		pdf.setFont("helvetica", "bold");
		pdf.setFontSize(13);
		pdf.setTextColor(0, 55, 176);
		pdf.text(sec.field_name, margin, y);
		// Confidence badge
		pdf.setFontSize(9);
		if (sec.confidence === "high") {
			pdf.setTextColor(0, 105, 72);
			pdf.text(`[Confidence: High (Validated)]`, margin + 280, y);
		} else if (sec.confidence === "medium") {
			pdf.setTextColor(180, 83, 9);
			pdf.text(`[Confidence: Medium]`, margin + 280, y);
		} else {
			pdf.setTextColor(186, 26, 26);
			pdf.text(`[Confidence: Low]`, margin + 280, y);
		}
		y += 18;
		// Content
		pdf.setFont("helvetica", "normal");
		pdf.setFontSize(10);
		pdf.setTextColor(11, 28, 48);
		const contentLines = pdf.splitTextToSize(sec.content, contentWidth);
		checkPageBreak(contentLines.length * 14 + 20);
		pdf.text(contentLines, margin, y);
		y += contentLines.length * 14 + 10;
		// Sub-steps if any
		if (sec.sub_steps && sec.sub_steps.length > 0) {
			sec.sub_steps.forEach((step) => {
				checkPageBreak(36);
				pdf.setFont("helvetica", "bold");
				pdf.setFontSize(10);
				pdf.setTextColor(29, 78, 216);
				pdf.text(`${step.step_number}. ${step.title} ${step.sla ? `(SLA: ${step.sla})` : ""}`, margin + 10, y);
				y += 14;
				pdf.setFont("helvetica", "normal");
				pdf.setFontSize(9);
				pdf.setTextColor(81, 95, 116);
				const descLines = pdf.splitTextToSize(step.description, contentWidth - 20);
				checkPageBreak(descLines.length * 13 + 10);
				pdf.text(descLines, margin + 10, y);
				y += descLines.length * 13 + 8;
			});
		}
		// Evidence
		if (sec.evidence_quotes && sec.evidence_quotes.length > 0) {
			checkPageBreak(30 + sec.evidence_quotes.length * 14);
			pdf.setFont("helvetica", "italic");
			pdf.setFontSize(8);
			pdf.setTextColor(100, 116, 139);
			pdf.text("Cited source evidence:", margin + 6, y);
			y += 12;
			sec.evidence_quotes.forEach((eq) => {
				const eqLines = pdf.splitTextToSize(`"${eq}"`, contentWidth - 12);
				checkPageBreak(eqLines.length * 11);
				pdf.text(eqLines, margin + 12, y);
				y += eqLines.length * 11 + 4;
			});
			y += 6;
		}
		y += 14;
	});
	// Governance section
	checkPageBreak(120);
	pdf.setFont("helvetica", "bold");
	pdf.setFontSize(12);
	pdf.setTextColor(0, 55, 176);
	pdf.text("Document Governance & Metadata", margin, y);
	y += 18;
	const metadataItems = [
		["Version", doc.version || "1.0 (Draft)"],
		["Process Owner", doc.owner || "[MISSING — not found in source notes]"],
		["Effective Date", doc.effective_date || "[MISSING — not found in source notes]"],
		["Review Cadence", doc.review_cycle || "Annual"],
		["Compliance Standard", doc.compliance_standard || "SOC 2 Type II / ISO 9001"],
		["Classification", doc.classification || "Internal Confidential"]
	];
	pdf.setFontSize(9);
	metadataItems.forEach(([label, value]) => {
		checkPageBreak(16);
		pdf.setFont("helvetica", "bold");
		pdf.setTextColor(81, 95, 116);
		pdf.text(`${label}:`, margin + 10, y);
		pdf.setFont("helvetica", "normal");
		pdf.setTextColor(11, 28, 48);
		pdf.text(`${value}`, margin + 160, y);
		y += 15;
	});
	const cleanTitle = (doc.title || "SOP").replace(/[^a-zA-Z0-9_-]/g, "_");
	pdf.save(`${doc.code || "SOP"}_${cleanTitle}.pdf`);
}
/**
* Download plain-text generation notes summary (.txt)
*/
export function downloadGenerationNotes(doc) {
	const unresolved = doc.missing_fields.filter((m) => !m.resolved);
	const resolved = doc.missing_fields.filter((m) => m.resolved);
	const lines = [
		"========================================================================",
		`SOP GENERATION NOTES & AUDIT VERIFICATION LOG`,
		"========================================================================",
		`Document Code       : ${doc.code}`,
		`Title               : ${doc.title}`,
		`Generated At        : ${doc.created_at || new Date().toISOString()}`,
		`Review Status       : ${doc.status}`,
		`Tone Profile        : ${doc.tone === "plain" ? "Plain Everyday Language" : "Formal Audit-Ready Language"}`,
		`Template Applied    : ${doc.template_type.toUpperCase()}`,
		`Word Count          : ~${doc.stats.wordCount} words`,
		`Estimated Read Time : ${doc.stats.readTimeMin} min(s)`,
		"",
		"------------------------------------------------------------------------",
		"1. MISSING FIELDS & HUMAN RESOLUTION AUDIT TRAIL",
		"------------------------------------------------------------------------"
	];
	if (doc.missing_fields.length === 0) {
		lines.push("No missing core fields detected. All parameters verified in source notes.");
	} else {
		lines.push(`Total Missing Parameters Flagged: ${doc.missing_fields.length}`);
		lines.push(`Resolved by Reviewer             : ${resolved.length}`);
		lines.push(`Remaining Unresolved             : ${unresolved.length}`);
		lines.push("");
		if (resolved.length > 0) {
			lines.push("RESOLVED PARAMETERS:");
			resolved.forEach((item, i) => {
				lines.push(`  ${i + 1}. [RESOLVED] ${item.field_name}`);
				lines.push(`     Issue Description : ${item.issue_description}`);
				lines.push(`     Resolution Method : ${item.resolution_method === "direct_inline" ? "Direct Inline Field Edit" : "Answered Clarifying Question"}`);
				lines.push(`     User Value Input  : "${item.resolved_value || ""}"`);
			});
			lines.push("");
		}
		if (unresolved.length > 0) {
			lines.push("UNRESOLVED / STILL MISSING PARAMETERS:");
			unresolved.forEach((item, i) => {
				lines.push(`  ${i + 1}. [UNRESOLVED] ${item.field_name}`);
				lines.push(`     Issue Description : ${item.issue_description}`);
				lines.push(`     Guardrail Status  : Preserved as "[MISSING — not found in source notes]"`);
			});
			lines.push("");
		}
	}
	lines.push("------------------------------------------------------------------------");
	lines.push("2. SECTION CONFIDENCE & SOURCE EVIDENCE TRACEABILITY");
	lines.push("------------------------------------------------------------------------");
	doc.sections.forEach((sec, idx) => {
		lines.push(`Section ${idx + 1}: ${sec.field_name}`);
		lines.push(`Confidence Level : ${sec.confidence.toUpperCase()}${sec.user_edited ? " (Human edited)" : ""}`);
		lines.push(`Evidence Quotes Cited (${sec.evidence_quotes.length} excerpt(s)):`);
		if (sec.evidence_quotes.length === 0) {
			lines.push("  - No explicit verbatim quote found; field marked missing or defaulted.");
		} else {
			sec.evidence_quotes.forEach((q) => {
				lines.push(`  * "${q}"`);
			});
		}
		lines.push("");
	});
	lines.push("------------------------------------------------------------------------");
	lines.push("3. DATA PRIVACY & RETENTION STATEMENT");
	lines.push("------------------------------------------------------------------------");
	lines.push("Hard privacy guarantee: No uploaded transcripts or operational notes are");
	lines.push("retained in any permanent database or file store. This log is generated");
	lines.push("fresh in-memory at download time exclusively for your compliance audit.");
	lines.push("========================================================================");
	const textContent = lines.join("\n");
	const blob = new Blob([textContent], { type: "text/plain;charset=utf-8" });
	const cleanTitle = (doc.title || "SOP").replace(/[^a-zA-Z0-9_-]/g, "_");
	downloadBlob(blob, `${doc.code || "SOP"}_generation_notes.txt`);
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
	URL.revokeObjectURL(url);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFFBQVEsV0FBVyxTQUFTLGNBQWMsT0FBTyxVQUFVLFdBQVcsV0FBd0IsbUJBQW1CO0FBQ3BJLE9BQU8sV0FBVzs7OztBQU1sQixPQUFPLGVBQWUsZUFBZSxLQUFpQztDQUNwRSxNQUFNLG9CQUFvQixJQUFJLGVBQWUsUUFBUSxNQUFNLENBQUMsRUFBRSxRQUFRO0NBQ3RFLE1BQU0sYUFBYSxJQUFJLFdBQVc7Q0FFbEMsTUFBTSxXQUFrQyxDQUFDOztDQUd6QyxTQUFTLEtBQ1AsSUFBSSxVQUFVO0VBQ1osVUFBVSxDQUNSLElBQUksUUFBUTtHQUNWLE1BQU0sYUFBYSwwQ0FBMEM7R0FDN0QsTUFBTTtHQUNOLE9BQU8sYUFBYSxXQUFXO0dBQy9CLE1BQU07RUFDUixDQUFDLENBQ0g7RUFDQSxTQUFTLEVBQUUsT0FBTyxJQUFJO0NBQ3hCLENBQUMsQ0FDSDs7Q0FHQSxTQUFTLEtBQ1AsSUFBSSxVQUFVO0VBQ1osTUFBTSxJQUFJO0VBQ1YsU0FBUyxhQUFhO0VBQ3RCLFNBQVMsRUFBRSxPQUFPLElBQUk7Q0FDeEIsQ0FBQyxDQUNIOztDQUdBLFNBQVMsS0FDUCxJQUFJLFVBQVU7RUFDWixVQUFVLENBQ1IsSUFBSSxRQUFRO0dBQUUsTUFBTSx3QkFBd0IsSUFBSSxLQUFLLG1CQUFtQixJQUFJLFdBQVcsZUFBZSxJQUFJO0dBQVUsTUFBTTtHQUFNLE9BQU87R0FBVSxNQUFNO0VBQUcsQ0FBQyxDQUM3SjtFQUNBLFNBQVMsRUFBRSxPQUFPLElBQUk7Q0FDeEIsQ0FBQyxDQUNIOztDQUdBLElBQUksa0JBQWtCLFNBQVMsR0FBRztFQUNoQyxTQUFTLEtBQ1AsSUFBSSxVQUFVO0dBQ1osVUFBVSxDQUNSLElBQUksUUFBUTtJQUFFLE1BQU0sc0JBQXNCLGtCQUFrQixPQUFPO0lBQStCLE1BQU07SUFBTSxPQUFPO0lBQVUsTUFBTTtHQUFHLENBQUMsQ0FDM0k7R0FDQSxTQUFTO0lBQUUsUUFBUTtJQUFLLE9BQU87R0FBRztFQUNwQyxDQUFDLENBQ0g7RUFFQSxrQkFBa0IsU0FBUyxNQUFNLFVBQVU7R0FDekMsU0FBUyxLQUNQLElBQUksVUFBVTtJQUNaLFVBQVU7S0FDUixJQUFJLFFBQVE7TUFBRSxNQUFNLEtBQUssS0FBSyxXQUFXO01BQUssTUFBTTtNQUFNLE9BQU87S0FBUyxDQUFDO0tBQzNFLElBQUksUUFBUTtNQUFFLE1BQU0sS0FBSztNQUFtQixTQUFTO0tBQUssQ0FBQztLQUMzRCxJQUFJLFFBQVE7TUFBRSxNQUFNO01BQTRDLE9BQU87S0FBUyxDQUFDO0lBQ25GO0lBQ0EsU0FBUyxFQUFFLE9BQU8sR0FBRztHQUN2QixDQUFDLENBQ0g7RUFDRixDQUFDO0VBQ0QsU0FBUyxLQUFLLElBQUksVUFBVSxFQUFFLFNBQVMsRUFBRSxPQUFPLElBQUksRUFBRSxDQUFDLENBQUM7Q0FDMUQ7O0NBR0EsSUFBSSxTQUFTLFNBQVMsS0FBSyxTQUFTOztFQUVsQyxTQUFTLEtBQ1AsSUFBSSxVQUFVO0dBQ1osVUFBVSxDQUNSLElBQUksUUFBUTtJQUFFLE1BQU0sSUFBSTtJQUFZLE1BQU07SUFBTSxNQUFNO0lBQUksT0FBTztHQUFTLENBQUMsR0FDM0UsSUFBSSxRQUFRO0lBQ1YsTUFBTSxrQkFBa0IsSUFBSSxXQUFXLFlBQVksSUFBSSxJQUFJLGNBQWMsb0JBQW9CLEdBQUc7SUFDaEcsTUFBTTtJQUNOLE1BQU07SUFDTixPQUFPLElBQUksZUFBZSxTQUFTLFdBQVcsSUFBSSxlQUFlLFdBQVcsV0FBVztHQUN6RixDQUFDLENBQ0g7R0FDQSxTQUFTLGFBQWE7R0FDdEIsU0FBUztJQUFFLFFBQVE7SUFBSyxPQUFPO0dBQUk7RUFDckMsQ0FBQyxDQUNIOztFQUdBLE1BQU0sYUFBYSxJQUFJLFFBQVEsTUFBTSxNQUFNO0VBQzNDLFdBQVcsU0FBUyxVQUFVO0dBQzVCLE1BQU0sU0FBUyxNQUFNLEtBQUs7R0FDMUIsSUFBSSxDQUFDLFFBQVE7R0FFYixJQUFJLE9BQU8sV0FBVyxHQUFHLEtBQUssT0FBTyxXQUFXLEdBQUcsS0FBSyxPQUFPLFdBQVcsR0FBRyxHQUFHO0lBQzlFLFNBQVMsS0FDUCxJQUFJLFVBQVU7S0FDWixNQUFNO0tBQ04sUUFBUSxFQUFFLE9BQU8sRUFBRTtLQUNuQixTQUFTLEVBQUUsT0FBTyxHQUFHO0lBQ3ZCLENBQUMsQ0FDSDtHQUNGLE9BQU87SUFDTCxTQUFTLEtBQ1AsSUFBSSxVQUFVO0tBQ1osTUFBTTtLQUNOLFNBQVMsRUFBRSxPQUFPLElBQUk7SUFDeEIsQ0FBQyxDQUNIO0dBQ0Y7RUFDRixDQUFDOztFQUdELElBQUksSUFBSSxhQUFhLElBQUksVUFBVSxTQUFTLEdBQUc7R0FDN0MsSUFBSSxVQUFVLFNBQVMsU0FBUztJQUM5QixTQUFTLEtBQ1AsSUFBSSxVQUFVO0tBQ1osVUFBVSxDQUNSLElBQUksUUFBUTtNQUFFLE1BQU0sUUFBUSxLQUFLLFlBQVksSUFBSSxLQUFLO01BQVMsTUFBTTtNQUFNLE9BQU87S0FBUyxDQUFDLEdBQzVGLEtBQUssTUFBTSxJQUFJLFFBQVE7TUFBRSxNQUFNLFVBQVUsS0FBSyxJQUFJO01BQUksTUFBTTtNQUFNLE9BQU87S0FBUyxDQUFDLElBQUksSUFBSSxRQUFRLEVBQUUsQ0FDdkc7S0FDQSxTQUFTO01BQUUsUUFBUTtNQUFLLE9BQU87S0FBRztJQUNwQyxDQUFDLENBQ0g7SUFDQSxTQUFTLEtBQ1AsSUFBSSxVQUFVO0tBQ1osTUFBTSxLQUFLO0tBQ1gsU0FBUyxFQUFFLE9BQU8sSUFBSTtJQUN4QixDQUFDLENBQ0g7R0FDRixDQUFDO0VBQ0g7O0VBR0EsSUFBSSxJQUFJLG1CQUFtQixJQUFJLGdCQUFnQixTQUFTLEdBQUc7R0FDekQsU0FBUyxLQUNQLElBQUksVUFBVTtJQUNaLFVBQVUsQ0FDUixJQUFJLFFBQVE7S0FBRSxNQUFNO0tBQWlDLE1BQU07S0FBTSxTQUFTO0tBQU0sTUFBTTtLQUFJLE9BQU87SUFBUyxDQUFDLENBQzdHO0lBQ0EsU0FBUztLQUFFLFFBQVE7S0FBSyxPQUFPO0lBQUc7R0FDcEMsQ0FBQyxDQUNIO0dBRUEsSUFBSSxnQkFBZ0IsU0FBUyxVQUFVO0lBQ3JDLFNBQVMsS0FDUCxJQUFJLFVBQVU7S0FDWixVQUFVLENBQ1IsSUFBSSxRQUFRO01BQUUsTUFBTSxJQUFJLE1BQU07TUFBSSxTQUFTO01BQU0sT0FBTztLQUFTLENBQUMsQ0FDcEU7S0FDQSxTQUFTLEVBQUUsT0FBTyxHQUFHO0lBQ3ZCLENBQUMsQ0FDSDtHQUNGLENBQUM7RUFDSDtFQUVBLFNBQVMsS0FBSyxJQUFJLFVBQVUsRUFBRSxTQUFTLEVBQUUsT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0NBQzFELENBQUM7O0NBR0QsU0FBUyxLQUNQLElBQUksVUFBVTtFQUNaLE1BQU07RUFDTixTQUFTLGFBQWE7RUFDdEIsU0FBUztHQUFFLFFBQVE7R0FBSyxPQUFPO0VBQUk7Q0FDckMsQ0FBQyxDQUNIO0NBRUEsTUFBTSxZQUFZO0VBQ2hCLElBQUksU0FBUyxFQUNYLFVBQVUsQ0FDUixJQUFJLFVBQVU7R0FDWixVQUFVLENBQUMsSUFBSSxVQUFVLEVBQUUsVUFBVSxDQUFDLElBQUksUUFBUTtJQUFFLE1BQU07SUFBa0IsTUFBTTtHQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztHQUM3RixTQUFTO0lBQUUsTUFBTTtJQUFVLE1BQU0sWUFBWTtJQUFPLE9BQU87R0FBTztHQUNsRSxPQUFPO0lBQUUsTUFBTTtJQUFNLE1BQU0sVUFBVTtHQUFJO0VBQzNDLENBQUMsR0FDRCxJQUFJLFVBQVU7R0FDWixVQUFVLENBQUMsSUFBSSxVQUFVLEVBQUUsVUFBVSxDQUFDLElBQUksUUFBUTtJQUFFLE1BQU07SUFBUyxNQUFNO0dBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0dBQ3BGLFNBQVM7SUFBRSxNQUFNO0lBQVUsTUFBTSxZQUFZO0lBQU8sT0FBTztHQUFPO0dBQ2xFLE9BQU87SUFBRSxNQUFNO0lBQU0sTUFBTSxVQUFVO0dBQUk7RUFDM0MsQ0FBQyxDQUNILEVBQ0YsQ0FBQztFQUNELElBQUksU0FBUyxFQUNYLFVBQVUsQ0FDUixJQUFJLFVBQVUsRUFBRSxVQUFVLENBQUMsSUFBSSxVQUFVLGVBQWUsQ0FBQyxFQUFFLENBQUMsR0FDNUQsSUFBSSxVQUFVLEVBQUUsVUFBVSxDQUFDLElBQUksVUFBVSxJQUFJLFFBQVEsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUNyRSxFQUNGLENBQUM7RUFDRCxJQUFJLFNBQVMsRUFDWCxVQUFVLENBQ1IsSUFBSSxVQUFVLEVBQUUsVUFBVSxDQUFDLElBQUksVUFBVSxTQUFTLENBQUMsRUFBRSxDQUFDLEdBQ3RELElBQUksVUFBVSxFQUFFLFVBQVUsQ0FBQyxJQUFJLFVBQVUsSUFBSSxXQUFXLGFBQWEsQ0FBQyxFQUFFLENBQUMsQ0FDM0UsRUFDRixDQUFDO0VBQ0QsSUFBSSxTQUFTLEVBQ1gsVUFBVSxDQUNSLElBQUksVUFBVSxFQUFFLFVBQVUsQ0FBQyxJQUFJLFVBQVUsZUFBZSxDQUFDLEVBQUUsQ0FBQyxHQUM1RCxJQUFJLFVBQVUsRUFDWixVQUFVLENBQ1IsSUFBSSxVQUNGLElBQUksU0FBUyx1Q0FDZixDQUNGLEVBQ0YsQ0FBQyxDQUNILEVBQ0YsQ0FBQztFQUNELElBQUksU0FBUyxFQUNYLFVBQVUsQ0FDUixJQUFJLFVBQVUsRUFBRSxVQUFVLENBQUMsSUFBSSxVQUFVLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxHQUM3RCxJQUFJLFVBQVUsRUFDWixVQUFVLENBQ1IsSUFBSSxVQUNGLElBQUksa0JBQWtCLHVDQUN4QixDQUNGLEVBQ0YsQ0FBQyxDQUNILEVBQ0YsQ0FBQztFQUNELElBQUksU0FBUyxFQUNYLFVBQVUsQ0FDUixJQUFJLFVBQVUsRUFBRSxVQUFVLENBQUMsSUFBSSxVQUFVLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxHQUM3RCxJQUFJLFVBQVUsRUFBRSxVQUFVLENBQUMsSUFBSSxVQUFVLElBQUksZ0JBQWdCLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FDM0UsRUFDRixDQUFDO0VBQ0QsSUFBSSxTQUFTLEVBQ1gsVUFBVSxDQUNSLElBQUksVUFBVSxFQUFFLFVBQVUsQ0FBQyxJQUFJLFVBQVUscUJBQXFCLENBQUMsRUFBRSxDQUFDLEdBQ2xFLElBQUksVUFBVSxFQUFFLFVBQVUsQ0FBQyxJQUFJLFVBQVUsSUFBSSx1QkFBdUIsMEJBQTBCLENBQUMsRUFBRSxDQUFDLENBQ3BHLEVBQ0YsQ0FBQztFQUNELElBQUksU0FBUyxFQUNYLFVBQVUsQ0FDUixJQUFJLFVBQVUsRUFBRSxVQUFVLENBQUMsSUFBSSxVQUFVLGdCQUFnQixDQUFDLEVBQUUsQ0FBQyxHQUM3RCxJQUFJLFVBQVUsRUFBRSxVQUFVLENBQUMsSUFBSSxVQUFVLElBQUksa0JBQWtCLHVCQUF1QixDQUFDLEVBQUUsQ0FBQyxDQUM1RixFQUNGLENBQUM7Q0FDSDtDQUVBLE1BQU0sV0FBVyxJQUFJLE1BQU07RUFDekIsTUFBTTtFQUNOLE9BQU87R0FBRSxNQUFNO0dBQU0sTUFBTSxVQUFVO0VBQUk7Q0FDM0MsQ0FBQztDQUVELFNBQVMsS0FBSyxRQUFRO0NBRXRCLE1BQU0sVUFBVSxJQUFJLFNBQVMsRUFDM0IsVUFBVSxDQUNSO0VBQ0UsWUFBWSxDQUFDO0VBQ2I7Q0FDRixDQUNGLEVBQ0YsQ0FBQztDQUVELE1BQU0sT0FBTyxNQUFNLE9BQU8sT0FBTyxPQUFPO0NBQ3hDLE1BQU0sY0FBYyxJQUFJLFNBQVMsTUFBSyxDQUFFLFFBQVEsbUJBQW1CLEdBQUc7Q0FDdEUsYUFBYSxNQUFNLEdBQUcsSUFBSSxRQUFRLE1BQU0sR0FBRyxXQUFXLE1BQU07QUFDOUQ7Ozs7QUFLQSxPQUFPLFNBQVMsY0FBYyxLQUF3QjtDQUNwRCxNQUFNLE1BQU0sSUFBSSxNQUFNO0VBQ3BCLGFBQWE7RUFDYixNQUFNO0VBQ04sUUFBUTtDQUNWLENBQUM7Q0FFRCxNQUFNLFlBQVksSUFBSSxTQUFTLFNBQVMsU0FBUztDQUNqRCxNQUFNLGFBQWEsSUFBSSxTQUFTLFNBQVMsVUFBVTtDQUNuRCxNQUFNLFNBQVM7Q0FDZixNQUFNLGVBQWUsWUFBWSxTQUFTO0NBQzFDLElBQUksSUFBSTtDQUVSLFNBQVMsZUFBZSxnQkFBd0I7RUFDOUMsSUFBSSxJQUFJLGlCQUFpQixhQUFhLFFBQVE7R0FDNUMsSUFBSSxRQUFRO0dBQ1osSUFBSTtFQUNOO0NBQ0Y7O0NBR0EsTUFBTSxhQUFhLElBQUksV0FBVztDQUNsQyxJQUFJLGFBQWEsYUFBYSxNQUFNLEtBQUssYUFBYSxNQUFNLEtBQUssYUFBYSxNQUFNLEdBQUc7Q0FDdkYsSUFBSSxLQUFLLFFBQVEsR0FBRyxjQUFjLElBQUksR0FBRztDQUN6QyxJQUFJLGFBQWEsYUFBYSxJQUFJLEtBQUssYUFBYSxNQUFNLElBQUksYUFBYSxLQUFLLENBQUM7Q0FDakYsSUFBSSxRQUFRLGFBQWEsTUFBTTtDQUMvQixJQUFJLFlBQVksRUFBRTtDQUNsQixJQUFJLEtBQ0YsYUFBYSwwQ0FBMEMsbURBQ3ZELFNBQVMsSUFDVCxJQUFJLEVBQ047Q0FDQSxLQUFLOztDQUdMLElBQUksYUFBYSxJQUFJLElBQUksRUFBRTtDQUMzQixJQUFJLFFBQVEsYUFBYSxNQUFNO0NBQy9CLElBQUksWUFBWSxFQUFFO0NBQ2xCLE1BQU0sYUFBYSxJQUFJLGdCQUFnQixJQUFJLE9BQU8sWUFBWTtDQUM5RCxJQUFJLEtBQUssWUFBWSxRQUFRLENBQUM7Q0FDOUIsS0FBSyxXQUFXLFNBQVM7O0NBR3pCLElBQUksYUFBYSxJQUFJLElBQUksR0FBRztDQUM1QixJQUFJLFFBQVEsYUFBYSxRQUFRO0NBQ2pDLElBQUksWUFBWSxFQUFFO0NBQ2xCLElBQUksS0FBSyxTQUFTLElBQUksS0FBSyxtQkFBbUIsSUFBSSxXQUFXLGVBQWUsSUFBSSxPQUFPLGdCQUFnQixJQUFJLFdBQVcsUUFBUSxDQUFDO0NBQy9ILEtBQUs7O0NBR0wsTUFBTSxhQUFhLElBQUksZUFBZSxRQUFRLE1BQU0sQ0FBQyxFQUFFLFFBQVE7Q0FDL0QsSUFBSSxXQUFXLFNBQVMsR0FBRztFQUN6QixlQUFlLEtBQUssV0FBVyxTQUFTLEVBQUU7RUFDMUMsSUFBSSxhQUFhLEtBQUssS0FBSyxFQUFFO0VBQzdCLElBQUksYUFBYSxLQUFLLEtBQUssR0FBRztFQUM5QixJQUFJLFlBQVksUUFBUSxHQUFHLGNBQWMsS0FBSyxXQUFXLFNBQVMsSUFBSSxHQUFHLEdBQUcsSUFBSTtFQUVoRixJQUFJLGFBQWEsS0FBSyxJQUFJLENBQUM7RUFDM0IsSUFBSSxRQUFRLGFBQWEsTUFBTTtFQUMvQixJQUFJLFlBQVksRUFBRTtFQUNsQixJQUFJLEtBQUssd0JBQXdCLFdBQVcsT0FBTyxpQ0FBaUMsU0FBUyxJQUFJLElBQUksRUFBRTtFQUV2RyxJQUFJLEtBQUssSUFBSTtFQUNiLElBQUksUUFBUSxhQUFhLFFBQVE7RUFDakMsSUFBSSxZQUFZLENBQUM7RUFDakIsV0FBVyxTQUFTLFNBQVM7R0FDM0IsSUFBSSxLQUFLLEtBQUssS0FBSyxXQUFXLElBQUksS0FBSyxrQkFBa0Isa0NBQWtDLFNBQVMsSUFBSSxFQUFFO0dBQzFHLE1BQU07RUFDUixDQUFDO0VBRUQsS0FBSyxLQUFLLFdBQVcsU0FBUyxLQUFLO0NBQ3JDOztDQUdBLElBQUksU0FBUyxTQUFTLFFBQVE7RUFDNUIsZUFBZSxFQUFFOztFQUdqQixJQUFJLFFBQVEsYUFBYSxNQUFNO0VBQy9CLElBQUksWUFBWSxFQUFFO0VBQ2xCLElBQUksYUFBYSxHQUFHLElBQUksR0FBRztFQUMzQixJQUFJLEtBQUssSUFBSSxZQUFZLFFBQVEsQ0FBQzs7RUFHbEMsSUFBSSxZQUFZLENBQUM7RUFDakIsSUFBSSxJQUFJLGVBQWUsUUFBUTtHQUM3QixJQUFJLGFBQWEsR0FBRyxLQUFLLEVBQUU7R0FDM0IsSUFBSSxLQUFLLGtDQUFrQyxTQUFTLEtBQUssQ0FBQztFQUM1RCxPQUFPLElBQUksSUFBSSxlQUFlLFVBQVU7R0FDdEMsSUFBSSxhQUFhLEtBQUssSUFBSSxDQUFDO0dBQzNCLElBQUksS0FBSyx3QkFBd0IsU0FBUyxLQUFLLENBQUM7RUFDbEQsT0FBTztHQUNMLElBQUksYUFBYSxLQUFLLElBQUksRUFBRTtHQUM1QixJQUFJLEtBQUsscUJBQXFCLFNBQVMsS0FBSyxDQUFDO0VBQy9DO0VBQ0EsS0FBSzs7RUFHTCxJQUFJLFFBQVEsYUFBYSxRQUFRO0VBQ2pDLElBQUksWUFBWSxFQUFFO0VBQ2xCLElBQUksYUFBYSxJQUFJLElBQUksRUFBRTtFQUMzQixNQUFNLGVBQWUsSUFBSSxnQkFBZ0IsSUFBSSxTQUFTLFlBQVk7RUFDbEUsZUFBZSxhQUFhLFNBQVMsS0FBSyxFQUFFO0VBQzVDLElBQUksS0FBSyxjQUFjLFFBQVEsQ0FBQztFQUNoQyxLQUFLLGFBQWEsU0FBUyxLQUFLOztFQUdoQyxJQUFJLElBQUksYUFBYSxJQUFJLFVBQVUsU0FBUyxHQUFHO0dBQzdDLElBQUksVUFBVSxTQUFTLFNBQVM7SUFDOUIsZUFBZSxFQUFFO0lBQ2pCLElBQUksUUFBUSxhQUFhLE1BQU07SUFDL0IsSUFBSSxZQUFZLEVBQUU7SUFDbEIsSUFBSSxhQUFhLElBQUksSUFBSSxHQUFHO0lBQzVCLElBQUksS0FBSyxHQUFHLEtBQUssWUFBWSxJQUFJLEtBQUssTUFBTSxHQUFHLEtBQUssTUFBTSxTQUFTLEtBQUssSUFBSSxLQUFLLE1BQU0sU0FBUyxJQUFJLENBQUM7SUFDckcsS0FBSztJQUVMLElBQUksUUFBUSxhQUFhLFFBQVE7SUFDakMsSUFBSSxZQUFZLENBQUM7SUFDakIsSUFBSSxhQUFhLElBQUksSUFBSSxHQUFHO0lBQzVCLE1BQU0sWUFBWSxJQUFJLGdCQUFnQixLQUFLLGFBQWEsZUFBZSxFQUFFO0lBQ3pFLGVBQWUsVUFBVSxTQUFTLEtBQUssRUFBRTtJQUN6QyxJQUFJLEtBQUssV0FBVyxTQUFTLElBQUksQ0FBQztJQUNsQyxLQUFLLFVBQVUsU0FBUyxLQUFLO0dBQy9CLENBQUM7RUFDSDs7RUFHQSxJQUFJLElBQUksbUJBQW1CLElBQUksZ0JBQWdCLFNBQVMsR0FBRztHQUN6RCxlQUFlLEtBQUssSUFBSSxnQkFBZ0IsU0FBUyxFQUFFO0dBQ25ELElBQUksUUFBUSxhQUFhLFFBQVE7R0FDakMsSUFBSSxZQUFZLENBQUM7R0FDakIsSUFBSSxhQUFhLEtBQUssS0FBSyxHQUFHO0dBQzlCLElBQUksS0FBSywwQkFBMEIsU0FBUyxHQUFHLENBQUM7R0FDaEQsS0FBSztHQUVMLElBQUksZ0JBQWdCLFNBQVMsT0FBTztJQUNsQyxNQUFNLFVBQVUsSUFBSSxnQkFBZ0IsSUFBSSxHQUFHLElBQUksZUFBZSxFQUFFO0lBQ2hFLGVBQWUsUUFBUSxTQUFTLEVBQUU7SUFDbEMsSUFBSSxLQUFLLFNBQVMsU0FBUyxJQUFJLENBQUM7SUFDaEMsS0FBSyxRQUFRLFNBQVMsS0FBSztHQUM3QixDQUFDO0dBQ0QsS0FBSztFQUNQO0VBRUEsS0FBSztDQUNQLENBQUM7O0NBR0QsZUFBZSxHQUFHO0NBQ2xCLElBQUksUUFBUSxhQUFhLE1BQU07Q0FDL0IsSUFBSSxZQUFZLEVBQUU7Q0FDbEIsSUFBSSxhQUFhLEdBQUcsSUFBSSxHQUFHO0NBQzNCLElBQUksS0FBSyxrQ0FBa0MsUUFBUSxDQUFDO0NBQ3BELEtBQUs7Q0FFTCxNQUFNLGdCQUFnQjtFQUNwQixDQUFDLFdBQVcsSUFBSSxXQUFXLGFBQWE7RUFDeEMsQ0FBQyxpQkFBaUIsSUFBSSxTQUFTLHVDQUF1QztFQUN0RSxDQUFDLGtCQUFrQixJQUFJLGtCQUFrQix1Q0FBdUM7RUFDaEYsQ0FBQyxrQkFBa0IsSUFBSSxnQkFBZ0IsUUFBUTtFQUMvQyxDQUFDLHVCQUF1QixJQUFJLHVCQUF1QiwwQkFBMEI7RUFDN0UsQ0FBQyxrQkFBa0IsSUFBSSxrQkFBa0IsdUJBQXVCO0NBQ2xFO0NBRUEsSUFBSSxZQUFZLENBQUM7Q0FDakIsY0FBYyxTQUFTLENBQUMsT0FBTyxXQUFXO0VBQ3hDLGVBQWUsRUFBRTtFQUNqQixJQUFJLFFBQVEsYUFBYSxNQUFNO0VBQy9CLElBQUksYUFBYSxJQUFJLElBQUksR0FBRztFQUM1QixJQUFJLEtBQUssR0FBRyxNQUFNLElBQUksU0FBUyxJQUFJLENBQUM7RUFFcEMsSUFBSSxRQUFRLGFBQWEsUUFBUTtFQUNqQyxJQUFJLGFBQWEsSUFBSSxJQUFJLEVBQUU7RUFDM0IsSUFBSSxLQUFLLEdBQUcsU0FBUyxTQUFTLEtBQUssQ0FBQztFQUNwQyxLQUFLO0NBQ1AsQ0FBQztDQUVELE1BQU0sY0FBYyxJQUFJLFNBQVMsTUFBSyxDQUFFLFFBQVEsbUJBQW1CLEdBQUc7Q0FDdEUsSUFBSSxLQUFLLEdBQUcsSUFBSSxRQUFRLE1BQU0sR0FBRyxXQUFXLEtBQUs7QUFDbkQ7Ozs7QUFLQSxPQUFPLFNBQVMsd0JBQXdCLEtBQXdCO0NBQzlELE1BQU0sYUFBYSxJQUFJLGVBQWUsUUFBUSxNQUFNLENBQUMsRUFBRSxRQUFRO0NBQy9ELE1BQU0sV0FBVyxJQUFJLGVBQWUsUUFBUSxNQUFNLEVBQUUsUUFBUTtDQUU1RCxNQUFNLFFBQWtCO0VBQ3RCO0VBQ0E7RUFDQTtFQUNBLHlCQUF5QixJQUFJO0VBQzdCLHlCQUF5QixJQUFJO0VBQzdCLHlCQUF5QixJQUFJLGNBQWMsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0VBQ2xFLHlCQUF5QixJQUFJO0VBQzdCLHlCQUF5QixJQUFJLFNBQVMsVUFBVSw0QkFBNEI7RUFDNUUseUJBQXlCLElBQUksY0FBYyxZQUFZO0VBQ3ZELDBCQUEwQixJQUFJLE1BQU0sVUFBVTtFQUM5Qyx5QkFBeUIsSUFBSSxNQUFNLFlBQVk7RUFDL0M7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtDQUVBLElBQUksSUFBSSxlQUFlLFdBQVcsR0FBRztFQUNuQyxNQUFNLEtBQUssMkVBQTJFO0NBQ3hGLE9BQU87RUFDTCxNQUFNLEtBQUsscUNBQXFDLElBQUksZUFBZSxRQUFRO0VBQzNFLE1BQU0sS0FBSyxzQ0FBc0MsU0FBUyxRQUFRO0VBQ2xFLE1BQU0sS0FBSyxzQ0FBc0MsV0FBVyxRQUFRO0VBQ3BFLE1BQU0sS0FBSyxFQUFFO0VBRWIsSUFBSSxTQUFTLFNBQVMsR0FBRztHQUN2QixNQUFNLEtBQUssc0JBQXNCO0dBQ2pDLFNBQVMsU0FBUyxNQUFNLE1BQU07SUFDNUIsTUFBTSxLQUFLLEtBQUssSUFBSSxFQUFFLGVBQWUsS0FBSyxZQUFZO0lBQ3RELE1BQU0sS0FBSyw0QkFBNEIsS0FBSyxtQkFBbUI7SUFDL0QsTUFBTSxLQUFLLDRCQUE0QixLQUFLLHNCQUFzQixrQkFBa0IsNkJBQTZCLGdDQUFnQztJQUNqSixNQUFNLEtBQUssNkJBQTZCLEtBQUssa0JBQWtCLEdBQUcsRUFBRTtHQUN0RSxDQUFDO0dBQ0QsTUFBTSxLQUFLLEVBQUU7RUFDZjtFQUVBLElBQUksV0FBVyxTQUFTLEdBQUc7R0FDekIsTUFBTSxLQUFLLHdDQUF3QztHQUNuRCxXQUFXLFNBQVMsTUFBTSxNQUFNO0lBQzlCLE1BQU0sS0FBSyxLQUFLLElBQUksRUFBRSxpQkFBaUIsS0FBSyxZQUFZO0lBQ3hELE1BQU0sS0FBSyw0QkFBNEIsS0FBSyxtQkFBbUI7SUFDL0QsTUFBTSxLQUFLLCtFQUErRTtHQUM1RixDQUFDO0dBQ0QsTUFBTSxLQUFLLEVBQUU7RUFDZjtDQUNGO0NBRUEsTUFBTSxLQUFLLDBFQUEwRTtDQUNyRixNQUFNLEtBQUssc0RBQXNEO0NBQ2pFLE1BQU0sS0FBSywwRUFBMEU7Q0FFckYsSUFBSSxTQUFTLFNBQVMsS0FBSyxRQUFRO0VBQ2pDLE1BQU0sS0FBSyxXQUFXLE1BQU0sRUFBRSxJQUFJLElBQUksWUFBWTtFQUNsRCxNQUFNLEtBQUssc0JBQXNCLElBQUksV0FBVyxZQUFZLElBQUksSUFBSSxjQUFjLG9CQUFvQixJQUFJO0VBQzFHLE1BQU0sS0FBSywwQkFBMEIsSUFBSSxnQkFBZ0IsT0FBTyxjQUFjO0VBQzlFLElBQUksSUFBSSxnQkFBZ0IsV0FBVyxHQUFHO0dBQ3BDLE1BQU0sS0FBSywwRUFBMEU7RUFDdkYsT0FBTztHQUNMLElBQUksZ0JBQWdCLFNBQVMsTUFBTTtJQUNqQyxNQUFNLEtBQUssUUFBUSxFQUFFLEVBQUU7R0FDekIsQ0FBQztFQUNIO0VBQ0EsTUFBTSxLQUFLLEVBQUU7Q0FDZixDQUFDO0NBRUQsTUFBTSxLQUFLLDBFQUEwRTtDQUNyRixNQUFNLEtBQUssdUNBQXVDO0NBQ2xELE1BQU0sS0FBSywwRUFBMEU7Q0FDckYsTUFBTSxLQUFLLDBFQUEwRTtDQUNyRixNQUFNLEtBQUsseUVBQXlFO0NBQ3BGLE1BQU0sS0FBSyx5RUFBeUU7Q0FDcEYsTUFBTSxLQUFLLDBFQUEwRTtDQUVyRixNQUFNLGNBQWMsTUFBTSxLQUFLLElBQUk7Q0FDbkMsTUFBTSxPQUFPLElBQUksS0FBSyxDQUFDLFdBQVcsR0FBRyxFQUFFLE1BQU0sMkJBQTJCLENBQUM7Q0FDekUsTUFBTSxjQUFjLElBQUksU0FBUyxNQUFLLENBQUUsUUFBUSxtQkFBbUIsR0FBRztDQUN0RSxhQUFhLE1BQU0sR0FBRyxJQUFJLFFBQVEsTUFBTSxzQkFBc0I7QUFDaEU7QUFFQSxTQUFTLGFBQWEsTUFBWSxVQUF3QjtDQUN4RCxNQUFNLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtDQUNwQyxNQUFNLElBQUksU0FBUyxjQUFjLEdBQUc7Q0FDcEMsRUFBRSxPQUFPO0NBQ1QsRUFBRSxXQUFXO0NBQ2IsU0FBUyxLQUFLLFlBQVksQ0FBQztDQUMzQixFQUFFLE1BQU07Q0FDUixTQUFTLEtBQUssWUFBWSxDQUFDO0NBQzNCLElBQUksZ0JBQWdCLEdBQUc7QUFDekIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiZXhwb3J0ZXIudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRG9jdW1lbnQsIFBhY2tlciwgUGFyYWdyYXBoLCBUZXh0UnVuLCBIZWFkaW5nTGV2ZWwsIFRhYmxlLCBUYWJsZVJvdywgVGFibGVDZWxsLCBXaWR0aFR5cGUsIEJvcmRlclN0eWxlLCBTaGFkaW5nVHlwZSB9IGZyb20gJ2RvY3gnO1xuaW1wb3J0IGpzUERGIGZyb20gJ2pzcGRmJztcbmltcG9ydCB7IFNPUERvY3VtZW50IH0gZnJvbSAnLi4vdHlwZXMvc29wJztcblxuLyoqXG4gKiBEb3dubG9hZCByZWFsIGZvcm1hdHRlZCBXb3JkIGRvY3VtZW50ICguZG9jeClcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRvd25sb2FkQXNEb2N4KGRvYzogU09QRG9jdW1lbnQpOiBQcm9taXNlPHZvaWQ+IHtcbiAgY29uc3QgdW5yZXNvbHZlZE1pc3NpbmcgPSBkb2MubWlzc2luZ19maWVsZHMuZmlsdGVyKChtKSA9PiAhbS5yZXNvbHZlZCk7XG4gIGNvbnN0IGlzQXBwcm92ZWQgPSBkb2Muc3RhdHVzID09PSAnQVBQUk9WRUQnO1xuXG4gIGNvbnN0IGNoaWxkcmVuOiAoUGFyYWdyYXBoIHwgVGFibGUpW10gPSBbXTtcblxuICAvLyBUb3AgU3RhdHVzIEhlYWRlciAvIERyYWZ0IE1hcmtlclxuICBjaGlsZHJlbi5wdXNoKFxuICAgIG5ldyBQYXJhZ3JhcGgoe1xuICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgbmV3IFRleHRSdW4oe1xuICAgICAgICAgIHRleHQ6IGlzQXBwcm92ZWQgPyAnQVBQUk9WRUQgU1RBTkRBUkQgT1BFUkFUSU5HIFBST0NFRFVSRScgOiAnRFJBRlQg4oCUIEhVTUFOIFJFVklFVyBSRVFVSVJFRCBCRUZPUkUgUFVCTElTSElORycsXG4gICAgICAgICAgYm9sZDogdHJ1ZSxcbiAgICAgICAgICBjb2xvcjogaXNBcHByb3ZlZCA/ICcwMDY5NDgnIDogJ0I0NTMwOScsXG4gICAgICAgICAgc2l6ZTogMjAsXG4gICAgICAgIH0pLFxuICAgICAgXSxcbiAgICAgIHNwYWNpbmc6IHsgYWZ0ZXI6IDEyMCB9LFxuICAgIH0pXG4gICk7XG5cbiAgLy8gRG9jdW1lbnQgVGl0bGVcbiAgY2hpbGRyZW4ucHVzaChcbiAgICBuZXcgUGFyYWdyYXBoKHtcbiAgICAgIHRleHQ6IGRvYy50aXRsZSxcbiAgICAgIGhlYWRpbmc6IEhlYWRpbmdMZXZlbC5USVRMRSxcbiAgICAgIHNwYWNpbmc6IHsgYWZ0ZXI6IDEyMCB9LFxuICAgIH0pXG4gICk7XG5cbiAgLy8gRG9jdW1lbnQgU3ViLWluZm9cbiAgY2hpbGRyZW4ucHVzaChcbiAgICBuZXcgUGFyYWdyYXBoKHtcbiAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgIG5ldyBUZXh0UnVuKHsgdGV4dDogYERvY3VtZW50IElkZW50aWZpZXI6ICR7ZG9jLmNvZGV9ICB8ICBEZXBhcnRtZW50OiAke2RvYy5kZXBhcnRtZW50fSAgfCAgU3RhdHVzOiAke2RvYy5zdGF0dXN9YCwgYm9sZDogdHJ1ZSwgY29sb3I6ICc1MTVGNzQnLCBzaXplOiAxOCB9KSxcbiAgICAgIF0sXG4gICAgICBzcGFjaW5nOiB7IGFmdGVyOiAyNDAgfSxcbiAgICB9KVxuICApO1xuXG4gIC8vIFVucmVzb2x2ZWQgTWlzc2luZyBGaWVsZHMgQ2FsbG91dFxuICBpZiAodW5yZXNvbHZlZE1pc3NpbmcubGVuZ3RoID4gMCkge1xuICAgIGNoaWxkcmVuLnB1c2goXG4gICAgICBuZXcgUGFyYWdyYXBoKHtcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICBuZXcgVGV4dFJ1bih7IHRleHQ6IGBbQUNUSU9OIFJFUVVJUkVEIOKAlCAke3VucmVzb2x2ZWRNaXNzaW5nLmxlbmd0aH0gVU5SRVNPTFZFRCBNSVNTSU5HIElURU0oUyldYCwgYm9sZDogdHJ1ZSwgY29sb3I6ICdCQTFBMUEnLCBzaXplOiAyMCB9KSxcbiAgICAgICAgXSxcbiAgICAgICAgc3BhY2luZzogeyBiZWZvcmU6IDEyMCwgYWZ0ZXI6IDgwIH0sXG4gICAgICB9KVxuICAgICk7XG5cbiAgICB1bnJlc29sdmVkTWlzc2luZy5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xuICAgICAgY2hpbGRyZW4ucHVzaChcbiAgICAgICAgbmV3IFBhcmFncmFwaCh7XG4gICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIG5ldyBUZXh0UnVuKHsgdGV4dDogYOKAoiAke2l0ZW0uZmllbGRfbmFtZX06IGAsIGJvbGQ6IHRydWUsIGNvbG9yOiAnQkExQTFBJyB9KSxcbiAgICAgICAgICAgIG5ldyBUZXh0UnVuKHsgdGV4dDogaXRlbS5pc3N1ZV9kZXNjcmlwdGlvbiwgaXRhbGljczogdHJ1ZSB9KSxcbiAgICAgICAgICAgIG5ldyBUZXh0UnVuKHsgdGV4dDogJyDigJQgW01JU1NJTkcg4oCUIG5vdCBmb3VuZCBpbiBzb3VyY2Ugbm90ZXNdJywgY29sb3I6ICdCQTFBMUEnIH0pLFxuICAgICAgICAgIF0sXG4gICAgICAgICAgc3BhY2luZzogeyBhZnRlcjogNjAgfSxcbiAgICAgICAgfSlcbiAgICAgICk7XG4gICAgfSk7XG4gICAgY2hpbGRyZW4ucHVzaChuZXcgUGFyYWdyYXBoKHsgc3BhY2luZzogeyBhZnRlcjogMjAwIH0gfSkpO1xuICB9XG5cbiAgLy8gU2VjdGlvbnNcbiAgZG9jLnNlY3Rpb25zLmZvckVhY2goKHNlYywgc0lkeCkgPT4ge1xuICAgIC8vIFNlY3Rpb24gSGVhZGVyIHdpdGggQ29uZmlkZW5jZSBCYWRnZVxuICAgIGNoaWxkcmVuLnB1c2goXG4gICAgICBuZXcgUGFyYWdyYXBoKHtcbiAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICBuZXcgVGV4dFJ1bih7IHRleHQ6IHNlYy5maWVsZF9uYW1lLCBib2xkOiB0cnVlLCBzaXplOiAyNiwgY29sb3I6ICcwMDM3QjAnIH0pLFxuICAgICAgICAgIG5ldyBUZXh0UnVuKHtcbiAgICAgICAgICAgIHRleHQ6IGAgIFtDb25maWRlbmNlOiAke3NlYy5jb25maWRlbmNlLnRvVXBwZXJDYXNlKCl9JHtzZWMudXNlcl9lZGl0ZWQgPyAnIC0gSHVtYW4gRWRpdGVkJyA6ICcnfV1gLFxuICAgICAgICAgICAgYm9sZDogdHJ1ZSxcbiAgICAgICAgICAgIHNpemU6IDE4LFxuICAgICAgICAgICAgY29sb3I6IHNlYy5jb25maWRlbmNlID09PSAnaGlnaCcgPyAnMDA2OTQ4JyA6IHNlYy5jb25maWRlbmNlID09PSAnbWVkaXVtJyA/ICdCNDUzMDknIDogJ0JBMUExQScsXG4gICAgICAgICAgfSksXG4gICAgICAgIF0sXG4gICAgICAgIGhlYWRpbmc6IEhlYWRpbmdMZXZlbC5IRUFESU5HXzIsXG4gICAgICAgIHNwYWNpbmc6IHsgYmVmb3JlOiAyNDAsIGFmdGVyOiAxMjAgfSxcbiAgICAgIH0pXG4gICAgKTtcblxuICAgIC8vIFNlY3Rpb24gQ29udGVudFxuICAgIGNvbnN0IHBhcmFncmFwaHMgPSBzZWMuY29udGVudC5zcGxpdCgnXFxuXFxuJyk7XG4gICAgcGFyYWdyYXBocy5mb3JFYWNoKChwVGV4dCkgPT4ge1xuICAgICAgY29uc3QgY2xlYW5QID0gcFRleHQudHJpbSgpO1xuICAgICAgaWYgKCFjbGVhblApIHJldHVybjtcblxuICAgICAgaWYgKGNsZWFuUC5zdGFydHNXaXRoKCfigKInKSB8fCBjbGVhblAuc3RhcnRzV2l0aCgnLScpIHx8IGNsZWFuUC5zdGFydHNXaXRoKCcqJykpIHtcbiAgICAgICAgY2hpbGRyZW4ucHVzaChcbiAgICAgICAgICBuZXcgUGFyYWdyYXBoKHtcbiAgICAgICAgICAgIHRleHQ6IGNsZWFuUCxcbiAgICAgICAgICAgIGJ1bGxldDogeyBsZXZlbDogMCB9LFxuICAgICAgICAgICAgc3BhY2luZzogeyBhZnRlcjogODAgfSxcbiAgICAgICAgICB9KVxuICAgICAgICApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY2hpbGRyZW4ucHVzaChcbiAgICAgICAgICBuZXcgUGFyYWdyYXBoKHtcbiAgICAgICAgICAgIHRleHQ6IGNsZWFuUCxcbiAgICAgICAgICAgIHNwYWNpbmc6IHsgYWZ0ZXI6IDEyMCB9LFxuICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyBTdWItc3RlcHMgaWYgYW55XG4gICAgaWYgKHNlYy5zdWJfc3RlcHMgJiYgc2VjLnN1Yl9zdGVwcy5sZW5ndGggPiAwKSB7XG4gICAgICBzZWMuc3ViX3N0ZXBzLmZvckVhY2goKHN0ZXApID0+IHtcbiAgICAgICAgY2hpbGRyZW4ucHVzaChcbiAgICAgICAgICBuZXcgUGFyYWdyYXBoKHtcbiAgICAgICAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgICAgICAgIG5ldyBUZXh0UnVuKHsgdGV4dDogYFN0ZXAgJHtzdGVwLnN0ZXBfbnVtYmVyfTogJHtzdGVwLnRpdGxlfWAsIGJvbGQ6IHRydWUsIGNvbG9yOiAnMUQ0RUQ4JyB9KSxcbiAgICAgICAgICAgICAgc3RlcC5zbGEgPyBuZXcgVGV4dFJ1bih7IHRleHQ6IGAgW1NMQTogJHtzdGVwLnNsYX1dYCwgYm9sZDogdHJ1ZSwgY29sb3I6ICc1MTVGNzQnIH0pIDogbmV3IFRleHRSdW4oJycpLFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIHNwYWNpbmc6IHsgYmVmb3JlOiAxMDAsIGFmdGVyOiA2MCB9LFxuICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgICAgIGNoaWxkcmVuLnB1c2goXG4gICAgICAgICAgbmV3IFBhcmFncmFwaCh7XG4gICAgICAgICAgICB0ZXh0OiBzdGVwLmRlc2NyaXB0aW9uLFxuICAgICAgICAgICAgc3BhY2luZzogeyBhZnRlcjogMTAwIH0sXG4gICAgICAgICAgfSlcbiAgICAgICAgKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIC8vIEV2aWRlbmNlIFF1b3RlcyBDYWxsb3V0IEJveFxuICAgIGlmIChzZWMuZXZpZGVuY2VfcXVvdGVzICYmIHNlYy5ldmlkZW5jZV9xdW90ZXMubGVuZ3RoID4gMCkge1xuICAgICAgY2hpbGRyZW4ucHVzaChcbiAgICAgICAgbmV3IFBhcmFncmFwaCh7XG4gICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIG5ldyBUZXh0UnVuKHsgdGV4dDogJ1NvdXJjZSBFdmlkZW5jZSBUcmFjZWFiaWxpdHk6JywgYm9sZDogdHJ1ZSwgaXRhbGljczogdHJ1ZSwgc2l6ZTogMTgsIGNvbG9yOiAnNTE1Rjc0JyB9KSxcbiAgICAgICAgICBdLFxuICAgICAgICAgIHNwYWNpbmc6IHsgYmVmb3JlOiAxMDAsIGFmdGVyOiA2MCB9LFxuICAgICAgICB9KVxuICAgICAgKTtcblxuICAgICAgc2VjLmV2aWRlbmNlX3F1b3Rlcy5mb3JFYWNoKChxdW90ZSkgPT4ge1xuICAgICAgICBjaGlsZHJlbi5wdXNoKFxuICAgICAgICAgIG5ldyBQYXJhZ3JhcGgoe1xuICAgICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgICAgbmV3IFRleHRSdW4oeyB0ZXh0OiBgXCIke3F1b3RlfVwiYCwgaXRhbGljczogdHJ1ZSwgY29sb3I6ICc0MzQ2NTUnIH0pLFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIHNwYWNpbmc6IHsgYWZ0ZXI6IDYwIH0sXG4gICAgICAgICAgfSlcbiAgICAgICAgKTtcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGNoaWxkcmVuLnB1c2gobmV3IFBhcmFncmFwaCh7IHNwYWNpbmc6IHsgYWZ0ZXI6IDE2MCB9IH0pKTtcbiAgfSk7XG5cbiAgLy8gR292ZXJuYW5jZSBhbmQgTWV0YWRhdGEgVGFibGVcbiAgY2hpbGRyZW4ucHVzaChcbiAgICBuZXcgUGFyYWdyYXBoKHtcbiAgICAgIHRleHQ6ICdEb2N1bWVudCBHb3Zlcm5hbmNlICYgQ29udHJvbCBNZXRhZGF0YScsXG4gICAgICBoZWFkaW5nOiBIZWFkaW5nTGV2ZWwuSEVBRElOR18yLFxuICAgICAgc3BhY2luZzogeyBiZWZvcmU6IDI0MCwgYWZ0ZXI6IDEyMCB9LFxuICAgIH0pXG4gICk7XG5cbiAgY29uc3QgdGFibGVSb3dzID0gW1xuICAgIG5ldyBUYWJsZVJvdyh7XG4gICAgICBjaGlsZHJlbjogW1xuICAgICAgICBuZXcgVGFibGVDZWxsKHtcbiAgICAgICAgICBjaGlsZHJlbjogW25ldyBQYXJhZ3JhcGgoeyBjaGlsZHJlbjogW25ldyBUZXh0UnVuKHsgdGV4dDogJ01ldGFkYXRhIEZpZWxkJywgYm9sZDogdHJ1ZSB9KV0gfSldLFxuICAgICAgICAgIHNoYWRpbmc6IHsgZmlsbDogJ0VGRjRGRicsIHR5cGU6IFNoYWRpbmdUeXBlLkNMRUFSLCBjb2xvcjogJ2F1dG8nIH0sXG4gICAgICAgICAgd2lkdGg6IHsgc2l6ZTogMzAwMCwgdHlwZTogV2lkdGhUeXBlLkRYQSB9LFxuICAgICAgICB9KSxcbiAgICAgICAgbmV3IFRhYmxlQ2VsbCh7XG4gICAgICAgICAgY2hpbGRyZW46IFtuZXcgUGFyYWdyYXBoKHsgY2hpbGRyZW46IFtuZXcgVGV4dFJ1bih7IHRleHQ6ICdWYWx1ZScsIGJvbGQ6IHRydWUgfSldIH0pXSxcbiAgICAgICAgICBzaGFkaW5nOiB7IGZpbGw6ICdFRkY0RkYnLCB0eXBlOiBTaGFkaW5nVHlwZS5DTEVBUiwgY29sb3I6ICdhdXRvJyB9LFxuICAgICAgICAgIHdpZHRoOiB7IHNpemU6IDYwMDAsIHR5cGU6IFdpZHRoVHlwZS5EWEEgfSxcbiAgICAgICAgfSksXG4gICAgICBdLFxuICAgIH0pLFxuICAgIG5ldyBUYWJsZVJvdyh7XG4gICAgICBjaGlsZHJlbjogW1xuICAgICAgICBuZXcgVGFibGVDZWxsKHsgY2hpbGRyZW46IFtuZXcgUGFyYWdyYXBoKCdEb2N1bWVudCBDb2RlJyldIH0pLFxuICAgICAgICBuZXcgVGFibGVDZWxsKHsgY2hpbGRyZW46IFtuZXcgUGFyYWdyYXBoKGRvYy5jb2RlIHx8ICdTT1AtODQ5MicpXSB9KSxcbiAgICAgIF0sXG4gICAgfSksXG4gICAgbmV3IFRhYmxlUm93KHtcbiAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgIG5ldyBUYWJsZUNlbGwoeyBjaGlsZHJlbjogW25ldyBQYXJhZ3JhcGgoJ1ZlcnNpb24nKV0gfSksXG4gICAgICAgIG5ldyBUYWJsZUNlbGwoeyBjaGlsZHJlbjogW25ldyBQYXJhZ3JhcGgoZG9jLnZlcnNpb24gfHwgJzEuMCAoRHJhZnQpJyldIH0pLFxuICAgICAgXSxcbiAgICB9KSxcbiAgICBuZXcgVGFibGVSb3coe1xuICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgbmV3IFRhYmxlQ2VsbCh7IGNoaWxkcmVuOiBbbmV3IFBhcmFncmFwaCgnUHJvY2VzcyBPd25lcicpXSB9KSxcbiAgICAgICAgbmV3IFRhYmxlQ2VsbCh7XG4gICAgICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgICAgIG5ldyBQYXJhZ3JhcGgoXG4gICAgICAgICAgICAgIGRvYy5vd25lciB8fCAnW01JU1NJTkcg4oCUIG5vdCBmb3VuZCBpbiBzb3VyY2Ugbm90ZXNdJ1xuICAgICAgICAgICAgKSxcbiAgICAgICAgICBdLFxuICAgICAgICB9KSxcbiAgICAgIF0sXG4gICAgfSksXG4gICAgbmV3IFRhYmxlUm93KHtcbiAgICAgIGNoaWxkcmVuOiBbXG4gICAgICAgIG5ldyBUYWJsZUNlbGwoeyBjaGlsZHJlbjogW25ldyBQYXJhZ3JhcGgoJ0VmZmVjdGl2ZSBEYXRlJyldIH0pLFxuICAgICAgICBuZXcgVGFibGVDZWxsKHtcbiAgICAgICAgICBjaGlsZHJlbjogW1xuICAgICAgICAgICAgbmV3IFBhcmFncmFwaChcbiAgICAgICAgICAgICAgZG9jLmVmZmVjdGl2ZV9kYXRlIHx8ICdbTUlTU0lORyDigJQgbm90IGZvdW5kIGluIHNvdXJjZSBub3Rlc10nXG4gICAgICAgICAgICApLFxuICAgICAgICAgIF0sXG4gICAgICAgIH0pLFxuICAgICAgXSxcbiAgICB9KSxcbiAgICBuZXcgVGFibGVSb3coe1xuICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgbmV3IFRhYmxlQ2VsbCh7IGNoaWxkcmVuOiBbbmV3IFBhcmFncmFwaCgnUmV2aWV3IENhZGVuY2UnKV0gfSksXG4gICAgICAgIG5ldyBUYWJsZUNlbGwoeyBjaGlsZHJlbjogW25ldyBQYXJhZ3JhcGgoZG9jLnJldmlld19jeWNsZSB8fCAnQW5udWFsJyldIH0pLFxuICAgICAgXSxcbiAgICB9KSxcbiAgICBuZXcgVGFibGVSb3coe1xuICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgbmV3IFRhYmxlQ2VsbCh7IGNoaWxkcmVuOiBbbmV3IFBhcmFncmFwaCgnQ29tcGxpYW5jZSBTdGFuZGFyZCcpXSB9KSxcbiAgICAgICAgbmV3IFRhYmxlQ2VsbCh7IGNoaWxkcmVuOiBbbmV3IFBhcmFncmFwaChkb2MuY29tcGxpYW5jZV9zdGFuZGFyZCB8fCAnU09DIDIgVHlwZSBJSSAvIElTTyA5MDAxJyldIH0pLFxuICAgICAgXSxcbiAgICB9KSxcbiAgICBuZXcgVGFibGVSb3coe1xuICAgICAgY2hpbGRyZW46IFtcbiAgICAgICAgbmV3IFRhYmxlQ2VsbCh7IGNoaWxkcmVuOiBbbmV3IFBhcmFncmFwaCgnQ2xhc3NpZmljYXRpb24nKV0gfSksXG4gICAgICAgIG5ldyBUYWJsZUNlbGwoeyBjaGlsZHJlbjogW25ldyBQYXJhZ3JhcGgoZG9jLmNsYXNzaWZpY2F0aW9uIHx8ICdJbnRlcm5hbCBDb25maWRlbnRpYWwnKV0gfSksXG4gICAgICBdLFxuICAgIH0pLFxuICBdO1xuXG4gIGNvbnN0IGdvdlRhYmxlID0gbmV3IFRhYmxlKHtcbiAgICByb3dzOiB0YWJsZVJvd3MsXG4gICAgd2lkdGg6IHsgc2l6ZTogOTAwMCwgdHlwZTogV2lkdGhUeXBlLkRYQSB9LFxuICB9KTtcblxuICBjaGlsZHJlbi5wdXNoKGdvdlRhYmxlKTtcblxuICBjb25zdCB3b3JkRG9jID0gbmV3IERvY3VtZW50KHtcbiAgICBzZWN0aW9uczogW1xuICAgICAge1xuICAgICAgICBwcm9wZXJ0aWVzOiB7fSxcbiAgICAgICAgY2hpbGRyZW4sXG4gICAgICB9LFxuICAgIF0sXG4gIH0pO1xuXG4gIGNvbnN0IGJsb2IgPSBhd2FpdCBQYWNrZXIudG9CbG9iKHdvcmREb2MpO1xuICBjb25zdCBjbGVhblRpdGxlID0gKGRvYy50aXRsZSB8fCAnU09QJykucmVwbGFjZSgvW15hLXpBLVowLTlfLV0vZywgJ18nKTtcbiAgZG93bmxvYWRCbG9iKGJsb2IsIGAke2RvYy5jb2RlIHx8ICdTT1AnfV8ke2NsZWFuVGl0bGV9LmRvY3hgKTtcbn1cblxuLyoqXG4gKiBEb3dubG9hZCByZWFsIGZvcm1hdHRlZCBQREZcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRvd25sb2FkQXNQZGYoZG9jOiBTT1BEb2N1bWVudCk6IHZvaWQge1xuICBjb25zdCBwZGYgPSBuZXcganNQREYoe1xuICAgIG9yaWVudGF0aW9uOiAncG9ydHJhaXQnLFxuICAgIHVuaXQ6ICdwdCcsXG4gICAgZm9ybWF0OiAnYTQnLFxuICB9KTtcblxuICBjb25zdCBwYWdlV2lkdGggPSBwZGYuaW50ZXJuYWwucGFnZVNpemUuZ2V0V2lkdGgoKTtcbiAgY29uc3QgcGFnZUhlaWdodCA9IHBkZi5pbnRlcm5hbC5wYWdlU2l6ZS5nZXRIZWlnaHQoKTtcbiAgY29uc3QgbWFyZ2luID0gNDA7XG4gIGNvbnN0IGNvbnRlbnRXaWR0aCA9IHBhZ2VXaWR0aCAtIG1hcmdpbiAqIDI7XG4gIGxldCB5ID0gbWFyZ2luO1xuXG4gIGZ1bmN0aW9uIGNoZWNrUGFnZUJyZWFrKHJlcXVpcmVkSGVpZ2h0OiBudW1iZXIpIHtcbiAgICBpZiAoeSArIHJlcXVpcmVkSGVpZ2h0ID4gcGFnZUhlaWdodCAtIG1hcmdpbikge1xuICAgICAgcGRmLmFkZFBhZ2UoKTtcbiAgICAgIHkgPSBtYXJnaW47XG4gICAgfVxuICB9XG5cbiAgLy8gSGVhZGVyIGJhbmRcbiAgY29uc3QgaXNBcHByb3ZlZCA9IGRvYy5zdGF0dXMgPT09ICdBUFBST1ZFRCc7XG4gIHBkZi5zZXRGaWxsQ29sb3IoaXNBcHByb3ZlZCA/IDIwOSA6IDI1NCwgaXNBcHByb3ZlZCA/IDI1MCA6IDI0MywgaXNBcHByb3ZlZCA/IDIyOSA6IDE5OSk7XG4gIHBkZi5yZWN0KG1hcmdpbiwgeSwgY29udGVudFdpZHRoLCAyNCwgJ0YnKTtcbiAgcGRmLnNldFRleHRDb2xvcihpc0FwcHJvdmVkID8gNCA6IDE4MCwgaXNBcHByb3ZlZCA/IDEyMCA6IDgzLCBpc0FwcHJvdmVkID8gODcgOiA5KTtcbiAgcGRmLnNldEZvbnQoJ2hlbHZldGljYScsICdib2xkJyk7XG4gIHBkZi5zZXRGb250U2l6ZSgxMCk7XG4gIHBkZi50ZXh0KFxuICAgIGlzQXBwcm92ZWQgPyAnQVBQUk9WRUQgU1RBTkRBUkQgT1BFUkFUSU5HIFBST0NFRFVSRScgOiAnRFJBRlQg4oCUIEhVTUFOIFJFVklFVyBSRVFVSVJFRCBCRUZPUkUgUFVCTElTSElORycsXG4gICAgbWFyZ2luICsgMTAsXG4gICAgeSArIDE2XG4gICk7XG4gIHkgKz0gMzQ7XG5cbiAgLy8gVGl0bGVcbiAgcGRmLnNldFRleHRDb2xvcigxMSwgMjgsIDQ4KTtcbiAgcGRmLnNldEZvbnQoJ2hlbHZldGljYScsICdib2xkJyk7XG4gIHBkZi5zZXRGb250U2l6ZSgxOCk7XG4gIGNvbnN0IHRpdGxlTGluZXMgPSBwZGYuc3BsaXRUZXh0VG9TaXplKGRvYy50aXRsZSwgY29udGVudFdpZHRoKTtcbiAgcGRmLnRleHQodGl0bGVMaW5lcywgbWFyZ2luLCB5KTtcbiAgeSArPSB0aXRsZUxpbmVzLmxlbmd0aCAqIDIyO1xuXG4gIC8vIE1ldGFkYXRhIFN1YmxpbmVcbiAgcGRmLnNldFRleHRDb2xvcig4MSwgOTUsIDExNik7XG4gIHBkZi5zZXRGb250KCdoZWx2ZXRpY2EnLCAnbm9ybWFsJyk7XG4gIHBkZi5zZXRGb250U2l6ZSgxMCk7XG4gIHBkZi50ZXh0KGBDb2RlOiAke2RvYy5jb2RlfSAgfCAgRGVwYXJ0bWVudDogJHtkb2MuZGVwYXJ0bWVudH0gIHwgIFN0YXR1czogJHtkb2Muc3RhdHVzfSAgfCAgVmVyc2lvbjogJHtkb2MudmVyc2lvbn1gLCBtYXJnaW4sIHkpO1xuICB5ICs9IDIwO1xuXG4gIC8vIE1pc3NpbmcgRmllbGRzIFdhcm5pbmcgaWYgYW55XG4gIGNvbnN0IHVucmVzb2x2ZWQgPSBkb2MubWlzc2luZ19maWVsZHMuZmlsdGVyKChtKSA9PiAhbS5yZXNvbHZlZCk7XG4gIGlmICh1bnJlc29sdmVkLmxlbmd0aCA+IDApIHtcbiAgICBjaGVja1BhZ2VCcmVhayg1MCArIHVucmVzb2x2ZWQubGVuZ3RoICogMTYpO1xuICAgIHBkZi5zZXREcmF3Q29sb3IoMjQ1LCAxNTgsIDExKTtcbiAgICBwZGYuc2V0RmlsbENvbG9yKDI1NCwgMjQzLCAxOTkpO1xuICAgIHBkZi5yb3VuZGVkUmVjdChtYXJnaW4sIHksIGNvbnRlbnRXaWR0aCwgMjQgKyB1bnJlc29sdmVkLmxlbmd0aCAqIDE2LCA0LCA0LCAnRkQnKTtcblxuICAgIHBkZi5zZXRUZXh0Q29sb3IoMTgwLCA4MywgOSk7XG4gICAgcGRmLnNldEZvbnQoJ2hlbHZldGljYScsICdib2xkJyk7XG4gICAgcGRmLnNldEZvbnRTaXplKDExKTtcbiAgICBwZGYudGV4dChgTWlzc2luZyBJbmZvcm1hdGlvbiAoJHt1bnJlc29sdmVkLmxlbmd0aH0gaXRlbXMgZm91bmQpIOKAlCBBY3Rpb24gTmVlZGVkOmAsIG1hcmdpbiArIDEwLCB5ICsgMTYpO1xuXG4gICAgbGV0IG15ID0geSArIDMyO1xuICAgIHBkZi5zZXRGb250KCdoZWx2ZXRpY2EnLCAnbm9ybWFsJyk7XG4gICAgcGRmLnNldEZvbnRTaXplKDkpO1xuICAgIHVucmVzb2x2ZWQuZm9yRWFjaCgoaXRlbSkgPT4ge1xuICAgICAgcGRmLnRleHQoYOKAoiAke2l0ZW0uZmllbGRfbmFtZX06ICR7aXRlbS5pc3N1ZV9kZXNjcmlwdGlvbn0gW01JU1NJTkcg4oCUIG5vdCBmb3VuZCBpbiBub3Rlc11gLCBtYXJnaW4gKyAxNCwgbXkpO1xuICAgICAgbXkgKz0gMTQ7XG4gICAgfSk7XG5cbiAgICB5ICs9IDMyICsgdW5yZXNvbHZlZC5sZW5ndGggKiAxNiArIDEwO1xuICB9XG5cbiAgLy8gU2VjdGlvbnNcbiAgZG9jLnNlY3Rpb25zLmZvckVhY2goKHNlYykgPT4ge1xuICAgIGNoZWNrUGFnZUJyZWFrKDYwKTtcblxuICAgIC8vIFNlY3Rpb24gdGl0bGVcbiAgICBwZGYuc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2JvbGQnKTtcbiAgICBwZGYuc2V0Rm9udFNpemUoMTMpO1xuICAgIHBkZi5zZXRUZXh0Q29sb3IoMCwgNTUsIDE3Nik7XG4gICAgcGRmLnRleHQoc2VjLmZpZWxkX25hbWUsIG1hcmdpbiwgeSk7XG5cbiAgICAvLyBDb25maWRlbmNlIGJhZGdlXG4gICAgcGRmLnNldEZvbnRTaXplKDkpO1xuICAgIGlmIChzZWMuY29uZmlkZW5jZSA9PT0gJ2hpZ2gnKSB7XG4gICAgICBwZGYuc2V0VGV4dENvbG9yKDAsIDEwNSwgNzIpO1xuICAgICAgcGRmLnRleHQoYFtDb25maWRlbmNlOiBIaWdoIChWYWxpZGF0ZWQpXWAsIG1hcmdpbiArIDI4MCwgeSk7XG4gICAgfSBlbHNlIGlmIChzZWMuY29uZmlkZW5jZSA9PT0gJ21lZGl1bScpIHtcbiAgICAgIHBkZi5zZXRUZXh0Q29sb3IoMTgwLCA4MywgOSk7XG4gICAgICBwZGYudGV4dChgW0NvbmZpZGVuY2U6IE1lZGl1bV1gLCBtYXJnaW4gKyAyODAsIHkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBwZGYuc2V0VGV4dENvbG9yKDE4NiwgMjYsIDI2KTtcbiAgICAgIHBkZi50ZXh0KGBbQ29uZmlkZW5jZTogTG93XWAsIG1hcmdpbiArIDI4MCwgeSk7XG4gICAgfVxuICAgIHkgKz0gMTg7XG5cbiAgICAvLyBDb250ZW50XG4gICAgcGRmLnNldEZvbnQoJ2hlbHZldGljYScsICdub3JtYWwnKTtcbiAgICBwZGYuc2V0Rm9udFNpemUoMTApO1xuICAgIHBkZi5zZXRUZXh0Q29sb3IoMTEsIDI4LCA0OCk7XG4gICAgY29uc3QgY29udGVudExpbmVzID0gcGRmLnNwbGl0VGV4dFRvU2l6ZShzZWMuY29udGVudCwgY29udGVudFdpZHRoKTtcbiAgICBjaGVja1BhZ2VCcmVhayhjb250ZW50TGluZXMubGVuZ3RoICogMTQgKyAyMCk7XG4gICAgcGRmLnRleHQoY29udGVudExpbmVzLCBtYXJnaW4sIHkpO1xuICAgIHkgKz0gY29udGVudExpbmVzLmxlbmd0aCAqIDE0ICsgMTA7XG5cbiAgICAvLyBTdWItc3RlcHMgaWYgYW55XG4gICAgaWYgKHNlYy5zdWJfc3RlcHMgJiYgc2VjLnN1Yl9zdGVwcy5sZW5ndGggPiAwKSB7XG4gICAgICBzZWMuc3ViX3N0ZXBzLmZvckVhY2goKHN0ZXApID0+IHtcbiAgICAgICAgY2hlY2tQYWdlQnJlYWsoMzYpO1xuICAgICAgICBwZGYuc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2JvbGQnKTtcbiAgICAgICAgcGRmLnNldEZvbnRTaXplKDEwKTtcbiAgICAgICAgcGRmLnNldFRleHRDb2xvcigyOSwgNzgsIDIxNik7XG4gICAgICAgIHBkZi50ZXh0KGAke3N0ZXAuc3RlcF9udW1iZXJ9LiAke3N0ZXAudGl0bGV9ICR7c3RlcC5zbGEgPyBgKFNMQTogJHtzdGVwLnNsYX0pYCA6ICcnfWAsIG1hcmdpbiArIDEwLCB5KTtcbiAgICAgICAgeSArPSAxNDtcblxuICAgICAgICBwZGYuc2V0Rm9udCgnaGVsdmV0aWNhJywgJ25vcm1hbCcpO1xuICAgICAgICBwZGYuc2V0Rm9udFNpemUoOSk7XG4gICAgICAgIHBkZi5zZXRUZXh0Q29sb3IoODEsIDk1LCAxMTYpO1xuICAgICAgICBjb25zdCBkZXNjTGluZXMgPSBwZGYuc3BsaXRUZXh0VG9TaXplKHN0ZXAuZGVzY3JpcHRpb24sIGNvbnRlbnRXaWR0aCAtIDIwKTtcbiAgICAgICAgY2hlY2tQYWdlQnJlYWsoZGVzY0xpbmVzLmxlbmd0aCAqIDEzICsgMTApO1xuICAgICAgICBwZGYudGV4dChkZXNjTGluZXMsIG1hcmdpbiArIDEwLCB5KTtcbiAgICAgICAgeSArPSBkZXNjTGluZXMubGVuZ3RoICogMTMgKyA4O1xuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gRXZpZGVuY2VcbiAgICBpZiAoc2VjLmV2aWRlbmNlX3F1b3RlcyAmJiBzZWMuZXZpZGVuY2VfcXVvdGVzLmxlbmd0aCA+IDApIHtcbiAgICAgIGNoZWNrUGFnZUJyZWFrKDMwICsgc2VjLmV2aWRlbmNlX3F1b3Rlcy5sZW5ndGggKiAxNCk7XG4gICAgICBwZGYuc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2l0YWxpYycpO1xuICAgICAgcGRmLnNldEZvbnRTaXplKDgpO1xuICAgICAgcGRmLnNldFRleHRDb2xvcigxMDAsIDExNiwgMTM5KTtcbiAgICAgIHBkZi50ZXh0KCdDaXRlZCBzb3VyY2UgZXZpZGVuY2U6JywgbWFyZ2luICsgNiwgeSk7XG4gICAgICB5ICs9IDEyO1xuXG4gICAgICBzZWMuZXZpZGVuY2VfcXVvdGVzLmZvckVhY2goKGVxKSA9PiB7XG4gICAgICAgIGNvbnN0IGVxTGluZXMgPSBwZGYuc3BsaXRUZXh0VG9TaXplKGBcIiR7ZXF9XCJgLCBjb250ZW50V2lkdGggLSAxMik7XG4gICAgICAgIGNoZWNrUGFnZUJyZWFrKGVxTGluZXMubGVuZ3RoICogMTEpO1xuICAgICAgICBwZGYudGV4dChlcUxpbmVzLCBtYXJnaW4gKyAxMiwgeSk7XG4gICAgICAgIHkgKz0gZXFMaW5lcy5sZW5ndGggKiAxMSArIDQ7XG4gICAgICB9KTtcbiAgICAgIHkgKz0gNjtcbiAgICB9XG5cbiAgICB5ICs9IDE0O1xuICB9KTtcblxuICAvLyBHb3Zlcm5hbmNlIHNlY3Rpb25cbiAgY2hlY2tQYWdlQnJlYWsoMTIwKTtcbiAgcGRmLnNldEZvbnQoJ2hlbHZldGljYScsICdib2xkJyk7XG4gIHBkZi5zZXRGb250U2l6ZSgxMik7XG4gIHBkZi5zZXRUZXh0Q29sb3IoMCwgNTUsIDE3Nik7XG4gIHBkZi50ZXh0KCdEb2N1bWVudCBHb3Zlcm5hbmNlICYgTWV0YWRhdGEnLCBtYXJnaW4sIHkpO1xuICB5ICs9IDE4O1xuXG4gIGNvbnN0IG1ldGFkYXRhSXRlbXMgPSBbXG4gICAgWydWZXJzaW9uJywgZG9jLnZlcnNpb24gfHwgJzEuMCAoRHJhZnQpJ10sXG4gICAgWydQcm9jZXNzIE93bmVyJywgZG9jLm93bmVyIHx8ICdbTUlTU0lORyDigJQgbm90IGZvdW5kIGluIHNvdXJjZSBub3Rlc10nXSxcbiAgICBbJ0VmZmVjdGl2ZSBEYXRlJywgZG9jLmVmZmVjdGl2ZV9kYXRlIHx8ICdbTUlTU0lORyDigJQgbm90IGZvdW5kIGluIHNvdXJjZSBub3Rlc10nXSxcbiAgICBbJ1JldmlldyBDYWRlbmNlJywgZG9jLnJldmlld19jeWNsZSB8fCAnQW5udWFsJ10sXG4gICAgWydDb21wbGlhbmNlIFN0YW5kYXJkJywgZG9jLmNvbXBsaWFuY2Vfc3RhbmRhcmQgfHwgJ1NPQyAyIFR5cGUgSUkgLyBJU08gOTAwMSddLFxuICAgIFsnQ2xhc3NpZmljYXRpb24nLCBkb2MuY2xhc3NpZmljYXRpb24gfHwgJ0ludGVybmFsIENvbmZpZGVudGlhbCddLFxuICBdO1xuXG4gIHBkZi5zZXRGb250U2l6ZSg5KTtcbiAgbWV0YWRhdGFJdGVtcy5mb3JFYWNoKChbbGFiZWwsIHZhbHVlXSkgPT4ge1xuICAgIGNoZWNrUGFnZUJyZWFrKDE2KTtcbiAgICBwZGYuc2V0Rm9udCgnaGVsdmV0aWNhJywgJ2JvbGQnKTtcbiAgICBwZGYuc2V0VGV4dENvbG9yKDgxLCA5NSwgMTE2KTtcbiAgICBwZGYudGV4dChgJHtsYWJlbH06YCwgbWFyZ2luICsgMTAsIHkpO1xuXG4gICAgcGRmLnNldEZvbnQoJ2hlbHZldGljYScsICdub3JtYWwnKTtcbiAgICBwZGYuc2V0VGV4dENvbG9yKDExLCAyOCwgNDgpO1xuICAgIHBkZi50ZXh0KGAke3ZhbHVlfWAsIG1hcmdpbiArIDE2MCwgeSk7XG4gICAgeSArPSAxNTtcbiAgfSk7XG5cbiAgY29uc3QgY2xlYW5UaXRsZSA9IChkb2MudGl0bGUgfHwgJ1NPUCcpLnJlcGxhY2UoL1teYS16QS1aMC05Xy1dL2csICdfJyk7XG4gIHBkZi5zYXZlKGAke2RvYy5jb2RlIHx8ICdTT1AnfV8ke2NsZWFuVGl0bGV9LnBkZmApO1xufVxuXG4vKipcbiAqIERvd25sb2FkIHBsYWluLXRleHQgZ2VuZXJhdGlvbiBub3RlcyBzdW1tYXJ5ICgudHh0KVxuICovXG5leHBvcnQgZnVuY3Rpb24gZG93bmxvYWRHZW5lcmF0aW9uTm90ZXMoZG9jOiBTT1BEb2N1bWVudCk6IHZvaWQge1xuICBjb25zdCB1bnJlc29sdmVkID0gZG9jLm1pc3NpbmdfZmllbGRzLmZpbHRlcigobSkgPT4gIW0ucmVzb2x2ZWQpO1xuICBjb25zdCByZXNvbHZlZCA9IGRvYy5taXNzaW5nX2ZpZWxkcy5maWx0ZXIoKG0pID0+IG0ucmVzb2x2ZWQpO1xuXG4gIGNvbnN0IGxpbmVzOiBzdHJpbmdbXSA9IFtcbiAgICAnPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09JyxcbiAgICBgU09QIEdFTkVSQVRJT04gTk9URVMgJiBBVURJVCBWRVJJRklDQVRJT04gTE9HYCxcbiAgICAnPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09JyxcbiAgICBgRG9jdW1lbnQgQ29kZSAgICAgICA6ICR7ZG9jLmNvZGV9YCxcbiAgICBgVGl0bGUgICAgICAgICAgICAgICA6ICR7ZG9jLnRpdGxlfWAsXG4gICAgYEdlbmVyYXRlZCBBdCAgICAgICAgOiAke2RvYy5jcmVhdGVkX2F0IHx8IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKX1gLFxuICAgIGBSZXZpZXcgU3RhdHVzICAgICAgIDogJHtkb2Muc3RhdHVzfWAsXG4gICAgYFRvbmUgUHJvZmlsZSAgICAgICAgOiAke2RvYy50b25lID09PSAncGxhaW4nID8gJ1BsYWluIEV2ZXJ5ZGF5IExhbmd1YWdlJyA6ICdGb3JtYWwgQXVkaXQtUmVhZHkgTGFuZ3VhZ2UnfWAsXG4gICAgYFRlbXBsYXRlIEFwcGxpZWQgICAgOiAke2RvYy50ZW1wbGF0ZV90eXBlLnRvVXBwZXJDYXNlKCl9YCxcbiAgICBgV29yZCBDb3VudCAgICAgICAgICA6IH4ke2RvYy5zdGF0cy53b3JkQ291bnR9IHdvcmRzYCxcbiAgICBgRXN0aW1hdGVkIFJlYWQgVGltZSA6ICR7ZG9jLnN0YXRzLnJlYWRUaW1lTWlufSBtaW4ocylgLFxuICAgICcnLFxuICAgICctLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0nLFxuICAgICcxLiBNSVNTSU5HIEZJRUxEUyAmIEhVTUFOIFJFU09MVVRJT04gQVVESVQgVFJBSUwnLFxuICAgICctLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0nLFxuICBdO1xuXG4gIGlmIChkb2MubWlzc2luZ19maWVsZHMubGVuZ3RoID09PSAwKSB7XG4gICAgbGluZXMucHVzaCgnTm8gbWlzc2luZyBjb3JlIGZpZWxkcyBkZXRlY3RlZC4gQWxsIHBhcmFtZXRlcnMgdmVyaWZpZWQgaW4gc291cmNlIG5vdGVzLicpO1xuICB9IGVsc2Uge1xuICAgIGxpbmVzLnB1c2goYFRvdGFsIE1pc3NpbmcgUGFyYW1ldGVycyBGbGFnZ2VkOiAke2RvYy5taXNzaW5nX2ZpZWxkcy5sZW5ndGh9YCk7XG4gICAgbGluZXMucHVzaChgUmVzb2x2ZWQgYnkgUmV2aWV3ZXIgICAgICAgICAgICAgOiAke3Jlc29sdmVkLmxlbmd0aH1gKTtcbiAgICBsaW5lcy5wdXNoKGBSZW1haW5pbmcgVW5yZXNvbHZlZCAgICAgICAgICAgICA6ICR7dW5yZXNvbHZlZC5sZW5ndGh9YCk7XG4gICAgbGluZXMucHVzaCgnJyk7XG5cbiAgICBpZiAocmVzb2x2ZWQubGVuZ3RoID4gMCkge1xuICAgICAgbGluZXMucHVzaCgnUkVTT0xWRUQgUEFSQU1FVEVSUzonKTtcbiAgICAgIHJlc29sdmVkLmZvckVhY2goKGl0ZW0sIGkpID0+IHtcbiAgICAgICAgbGluZXMucHVzaChgICAke2kgKyAxfS4gW1JFU09MVkVEXSAke2l0ZW0uZmllbGRfbmFtZX1gKTtcbiAgICAgICAgbGluZXMucHVzaChgICAgICBJc3N1ZSBEZXNjcmlwdGlvbiA6ICR7aXRlbS5pc3N1ZV9kZXNjcmlwdGlvbn1gKTtcbiAgICAgICAgbGluZXMucHVzaChgICAgICBSZXNvbHV0aW9uIE1ldGhvZCA6ICR7aXRlbS5yZXNvbHV0aW9uX21ldGhvZCA9PT0gJ2RpcmVjdF9pbmxpbmUnID8gJ0RpcmVjdCBJbmxpbmUgRmllbGQgRWRpdCcgOiAnQW5zd2VyZWQgQ2xhcmlmeWluZyBRdWVzdGlvbid9YCk7XG4gICAgICAgIGxpbmVzLnB1c2goYCAgICAgVXNlciBWYWx1ZSBJbnB1dCAgOiBcIiR7aXRlbS5yZXNvbHZlZF92YWx1ZSB8fCAnJ31cImApO1xuICAgICAgfSk7XG4gICAgICBsaW5lcy5wdXNoKCcnKTtcbiAgICB9XG5cbiAgICBpZiAodW5yZXNvbHZlZC5sZW5ndGggPiAwKSB7XG4gICAgICBsaW5lcy5wdXNoKCdVTlJFU09MVkVEIC8gU1RJTEwgTUlTU0lORyBQQVJBTUVURVJTOicpO1xuICAgICAgdW5yZXNvbHZlZC5mb3JFYWNoKChpdGVtLCBpKSA9PiB7XG4gICAgICAgIGxpbmVzLnB1c2goYCAgJHtpICsgMX0uIFtVTlJFU09MVkVEXSAke2l0ZW0uZmllbGRfbmFtZX1gKTtcbiAgICAgICAgbGluZXMucHVzaChgICAgICBJc3N1ZSBEZXNjcmlwdGlvbiA6ICR7aXRlbS5pc3N1ZV9kZXNjcmlwdGlvbn1gKTtcbiAgICAgICAgbGluZXMucHVzaChgICAgICBHdWFyZHJhaWwgU3RhdHVzICA6IFByZXNlcnZlZCBhcyBcIltNSVNTSU5HIOKAlCBub3QgZm91bmQgaW4gc291cmNlIG5vdGVzXVwiYCk7XG4gICAgICB9KTtcbiAgICAgIGxpbmVzLnB1c2goJycpO1xuICAgIH1cbiAgfVxuXG4gIGxpbmVzLnB1c2goJy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuICBsaW5lcy5wdXNoKCcyLiBTRUNUSU9OIENPTkZJREVOQ0UgJiBTT1VSQ0UgRVZJREVOQ0UgVFJBQ0VBQklMSVRZJyk7XG4gIGxpbmVzLnB1c2goJy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGRvYy5zZWN0aW9ucy5mb3JFYWNoKChzZWMsIGlkeCkgPT4ge1xuICAgIGxpbmVzLnB1c2goYFNlY3Rpb24gJHtpZHggKyAxfTogJHtzZWMuZmllbGRfbmFtZX1gKTtcbiAgICBsaW5lcy5wdXNoKGBDb25maWRlbmNlIExldmVsIDogJHtzZWMuY29uZmlkZW5jZS50b1VwcGVyQ2FzZSgpfSR7c2VjLnVzZXJfZWRpdGVkID8gJyAoSHVtYW4gZWRpdGVkKScgOiAnJ31gKTtcbiAgICBsaW5lcy5wdXNoKGBFdmlkZW5jZSBRdW90ZXMgQ2l0ZWQgKCR7c2VjLmV2aWRlbmNlX3F1b3Rlcy5sZW5ndGh9IGV4Y2VycHQocykpOmApO1xuICAgIGlmIChzZWMuZXZpZGVuY2VfcXVvdGVzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgbGluZXMucHVzaCgnICAtIE5vIGV4cGxpY2l0IHZlcmJhdGltIHF1b3RlIGZvdW5kOyBmaWVsZCBtYXJrZWQgbWlzc2luZyBvciBkZWZhdWx0ZWQuJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNlYy5ldmlkZW5jZV9xdW90ZXMuZm9yRWFjaCgocSkgPT4ge1xuICAgICAgICBsaW5lcy5wdXNoKGAgICogXCIke3F9XCJgKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBsaW5lcy5wdXNoKCcnKTtcbiAgfSk7XG5cbiAgbGluZXMucHVzaCgnLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG4gIGxpbmVzLnB1c2goJzMuIERBVEEgUFJJVkFDWSAmIFJFVEVOVElPTiBTVEFURU1FTlQnKTtcbiAgbGluZXMucHVzaCgnLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG4gIGxpbmVzLnB1c2goJ0hhcmQgcHJpdmFjeSBndWFyYW50ZWU6IE5vIHVwbG9hZGVkIHRyYW5zY3JpcHRzIG9yIG9wZXJhdGlvbmFsIG5vdGVzIGFyZScpO1xuICBsaW5lcy5wdXNoKCdyZXRhaW5lZCBpbiBhbnkgcGVybWFuZW50IGRhdGFiYXNlIG9yIGZpbGUgc3RvcmUuIFRoaXMgbG9nIGlzIGdlbmVyYXRlZCcpO1xuICBsaW5lcy5wdXNoKCdmcmVzaCBpbi1tZW1vcnkgYXQgZG93bmxvYWQgdGltZSBleGNsdXNpdmVseSBmb3IgeW91ciBjb21wbGlhbmNlIGF1ZGl0LicpO1xuICBsaW5lcy5wdXNoKCc9PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT0nKTtcblxuICBjb25zdCB0ZXh0Q29udGVudCA9IGxpbmVzLmpvaW4oJ1xcbicpO1xuICBjb25zdCBibG9iID0gbmV3IEJsb2IoW3RleHRDb250ZW50XSwgeyB0eXBlOiAndGV4dC9wbGFpbjtjaGFyc2V0PXV0Zi04JyB9KTtcbiAgY29uc3QgY2xlYW5UaXRsZSA9IChkb2MudGl0bGUgfHwgJ1NPUCcpLnJlcGxhY2UoL1teYS16QS1aMC05Xy1dL2csICdfJyk7XG4gIGRvd25sb2FkQmxvYihibG9iLCBgJHtkb2MuY29kZSB8fCAnU09QJ31fZ2VuZXJhdGlvbl9ub3Rlcy50eHRgKTtcbn1cblxuZnVuY3Rpb24gZG93bmxvYWRCbG9iKGJsb2I6IEJsb2IsIGZpbGVuYW1lOiBzdHJpbmcpOiB2b2lkIHtcbiAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKTtcbiAgY29uc3QgYSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgYS5ocmVmID0gdXJsO1xuICBhLmRvd25sb2FkID0gZmlsZW5hbWU7XG4gIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoYSk7XG4gIGEuY2xpY2soKTtcbiAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChhKTtcbiAgVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xufVxuIl19