const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"];/**
* @license
* SPDX-License-Identifier: Apache-2.0
*/
import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=aba35700";
import { TopAppBar } from "/src/components/TopAppBar.tsx";
import { PasscodeGate } from "/src/components/PasscodeGate.tsx";
import { InputScreen } from "/src/components/InputScreen.tsx";
import { ProcessingScreen } from "/src/components/ProcessingScreen.tsx";
import { InsufficientStepsScreen } from "/src/components/InsufficientStepsScreen.tsx";
import { ReviewScreen } from "/src/components/ReviewScreen.tsx";
import { NetlifyDeployModal } from "/src/components/NetlifyDeployModal.tsx";
import { HelpModal } from "/src/components/HelpModal.tsx";
import { SAMPLE_MESSY_NOTES, PRESET_TEMPLATES } from "/src/data/templates.ts";
import { downloadAsDocx, downloadAsPdf, downloadGenerationNotes } from "/src/utils/exporter.ts";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=aba35700";
export default function App() {
	// Authentication state
	const [isAuthenticated, setIsAuthenticated] = useState(() => {
		return localStorage.getItem("sop_passcode_auth") === "true" || sessionStorage.getItem("sop_passcode_auth") === "true";
	});
	// App workflow screen state
	const [screen, setScreen] = useState("input");
	// Input state
	const [notes, setNotes] = useState("");
	const [selectedTemplate, setSelectedTemplate] = useState("iso");
	const [customTemplateText, setCustomTemplateText] = useState("");
	const [tone, setTone] = useState("plain");
	// Processing progress state
	const [processingStage, setProcessingStage] = useState("ingest");
	const [errorMessage, setErrorMessage] = useState(null);
	// Active SOP Document state
	const [currentDoc, setCurrentDoc] = useState(null);
	// Modals
	const [showDeployModal, setShowDeployModal] = useState(false);
	const [showHelpModal, setShowHelpModal] = useState(false);
	// Cancel controller for in-flight generation
	const [abortController, setAbortController] = useState(null);
	const wordCount = notes.trim().split(/\s+/).filter(Boolean).length;
	const currentTemplateDef = PRESET_TEMPLATES.find((t) => t.id === selectedTemplate);
	const templateName = selectedTemplate === "custom" ? "Custom" : currentTemplateDef?.name || "Standard";
	const handleStartGeneration = async () => {
		const trimmedNotes = notes.trim();
		const count = trimmedNotes.split(/\s+/).filter(Boolean).length;
		// Client-side quick guardrail for brief inputs (< 15 words)
		if (count < 15) {
			setErrorMessage("Your notes appear to be too brief (under 15 words) or missing chronological steps. An SOP needs at least a few sequential actions or responsibilities to build a structured procedure.");
			setScreen("insufficient_steps");
			return;
		}
		setScreen("processing");
		setProcessingStage("ingest");
		setErrorMessage(null);
		const controller = new AbortController();
		setAbortController(controller);
		// Progress step milestones while model processes
		const progressTimer1 = setTimeout(() => setProcessingStage("identify_steps"), 1200);
		const progressTimer2 = setTimeout(() => setProcessingStage("check_core_fields"), 2800);
		const progressTimer3 = setTimeout(() => setProcessingStage("match_template"), 4500);
		try {
			const response = await fetch("/api/generate-sop", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					notes: trimmedNotes,
					templateType: selectedTemplate,
					customTemplateText: selectedTemplate === "custom" ? customTemplateText : undefined,
					tone
				}),
				signal: controller.signal
			});
			setProcessingStage("flag_missing");
			const data = await response.json();
			setProcessingStage("synthesize_evidence");
			if (response.ok && data.success && data.document) {
				// Successful generation!
				setTimeout(() => {
					setCurrentDoc(data.document);
					setScreen("review");
				}, 600);
			} else {
				// Failure or brevity guardrail triggered
				if (data.error_type === "too_brief") {
					setErrorMessage(data.error || "Notes are too brief to generate an SOP.");
					setScreen("insufficient_steps");
				} else {
					setErrorMessage(data.error || "Failed to generate SOP from notes. Please verify your Gemini API key or notes structure.");
					setScreen("insufficient_steps");
				}
			}
		} catch (err) {
			if (err.name === "AbortError") {
				setScreen("input");
				return;
			}
			console.error("Generation fetch error:", err);
			setErrorMessage(err?.message || "Network or server error while generating SOP.");
			setScreen("insufficient_steps");
		} finally {
			clearTimeout(progressTimer1);
			clearTimeout(progressTimer2);
			clearTimeout(progressTimer3);
		}
	};
	const handleCancelGeneration = () => {
		if (abortController) {
			abortController.abort();
		}
		setScreen("input");
	};
	const handleResetToInput = () => {
		setScreen("input");
	};
	const handleStartOverCompletely = () => {
		setNotes("");
		setCurrentDoc(null);
		setScreen("input");
	};
	const handleLoadSampleNotes = () => {
		setNotes(SAMPLE_MESSY_NOTES);
		setScreen("input");
	};
	// Determine current active step number for header
	let stepNumber = 1;
	if (!isAuthenticated) stepNumber = 0;
	else if (screen === "processing") stepNumber = 2;
	else if (screen === "review") stepNumber = 3;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen bg-background text-on-surface flex flex-col font-sans selection:bg-secondary-container selection:text-primary",
		children: [
			/* @__PURE__ */ _jsxDEV(TopAppBar, {
				currentStep: stepNumber,
				documentTitle: currentDoc?.title,
				documentCode: currentDoc?.code,
				isApproved: currentDoc?.status === "APPROVED",
				onOpenDeployModal: () => setShowDeployModal(true),
				onOpenHelpModal: () => setShowHelpModal(true),
				onReset: handleResetToInput,
				onMarkApproved: () => {
					if (currentDoc) {
						const nextStatus = currentDoc.status === "APPROVED" ? "REVIEWED" : "APPROVED";
						setCurrentDoc({
							...currentDoc,
							status: nextStatus
						});
					}
				},
				onExportWord: () => currentDoc && downloadAsDocx(currentDoc),
				onExportPdf: () => currentDoc && downloadAsPdf(currentDoc),
				onExportTxt: () => currentDoc && downloadGenerationNotes(currentDoc)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 164,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex-1 flex flex-col",
				children: !isAuthenticated ? /* @__PURE__ */ _jsxDEV(PasscodeGate, { onAuthenticated: () => setIsAuthenticated(true) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 186,
					columnNumber: 11
				}, this) : screen === "input" ? /* @__PURE__ */ _jsxDEV(InputScreen, {
					notes,
					setNotes,
					selectedTemplate,
					setSelectedTemplate,
					customTemplateText,
					setCustomTemplateText,
					tone,
					setTone,
					onGenerate: handleStartGeneration
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 188,
					columnNumber: 11
				}, this) : screen === "processing" ? /* @__PURE__ */ _jsxDEV(ProcessingScreen, {
					currentStage: processingStage,
					wordCount,
					templateName,
					onCancel: handleCancelGeneration
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 200,
					columnNumber: 11
				}, this) : screen === "insufficient_steps" ? /* @__PURE__ */ _jsxDEV(InsufficientStepsScreen, {
					errorMessage: errorMessage || undefined,
					onTryAgain: handleResetToInput,
					onLoadSample: handleLoadSampleNotes,
					onOpenGuide: () => setShowHelpModal(true)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 207,
					columnNumber: 11
				}, this) : screen === "review" && currentDoc ? /* @__PURE__ */ _jsxDEV(ReviewScreen, {
					document: currentDoc,
					onUpdateDocument: (updated) => setCurrentDoc(updated),
					onExportWord: () => downloadAsDocx(currentDoc),
					onExportPdf: () => downloadAsPdf(currentDoc),
					onExportTxt: () => downloadGenerationNotes(currentDoc),
					onOpenDeployModal: () => setShowDeployModal(true),
					onReset: handleStartOverCompletely
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 214,
					columnNumber: 11
				}, this) : null
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 184,
				columnNumber: 7
			}, this),
			isAuthenticated && /* @__PURE__ */ _jsxDEV("nav", {
				className: "fixed bottom-0 left-0 w-full z-50 flex md:hidden justify-around items-center px-4 py-2 bg-surface-container-lowest border-t border-outline-variant shadow-sm",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setScreen("input"),
						className: `flex flex-col items-center justify-center px-3 py-1 rounded-lg text-xs transition-colors ${screen === "input" ? "bg-secondary-container text-primary font-semibold" : "text-secondary hover:text-on-surface"}`,
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "material-symbols-outlined text-lg",
							children: "upload_file"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] mt-0.5",
							children: "Upload"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 239,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 230,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						disabled: screen === "input" && !notes,
						onClick: () => {
							if (screen === "review" || notes) {
								handleStartGeneration();
							}
						},
						className: `flex flex-col items-center justify-center px-3 py-1 rounded-lg text-xs transition-colors ${screen === "processing" ? "bg-secondary-container text-primary font-semibold" : "text-secondary hover:text-on-surface disabled:opacity-40"}`,
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "material-symbols-outlined text-lg",
							children: "hourglass_top"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 256,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] mt-0.5",
							children: "Process"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 257,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 243,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						disabled: !currentDoc,
						onClick: () => {
							if (currentDoc) setScreen("review");
						},
						className: `flex flex-col items-center justify-center px-3 py-1 rounded-lg text-xs transition-colors ${screen === "review" ? "bg-secondary-container text-primary font-semibold" : "text-secondary hover:text-on-surface disabled:opacity-40"}`,
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "material-symbols-outlined text-lg",
							children: "rule"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] mt-0.5",
							children: "Review"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 273,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 261,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setShowDeployModal(true),
						className: "flex flex-col items-center justify-center text-secondary hover:text-on-surface px-3 py-1 rounded-lg text-xs transition-colors",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "material-symbols-outlined text-lg",
							children: "cloud_upload"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 281,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] mt-0.5",
							children: "Netlify"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 282,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 277,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 228,
				columnNumber: 9
			}, this),
			showDeployModal && /* @__PURE__ */ _jsxDEV(NetlifyDeployModal, { onClose: () => setShowDeployModal(false) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 289,
				columnNumber: 9
			}, this),
			showHelpModal && /* @__PURE__ */ _jsxDEV(HelpModal, {
				onClose: () => setShowHelpModal(false),
				onOpenDeployModal: () => setShowDeployModal(true)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 294,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 162,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7OztBQUtBLE9BQU8sU0FBUyxnQkFBMkI7QUFDM0MsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyx3QkFBMkM7QUFDcEQsU0FBUywrQkFBK0I7QUFDeEMsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUywwQkFBMEI7QUFDbkMsU0FBUyxpQkFBaUI7QUFFMUIsU0FBUyxvQkFBb0Isd0JBQXdCO0FBQ3JELFNBQVMsZ0JBQWdCLGVBQWUsK0JBQStCOzs7QUFFdkUsZUFBZSxTQUFTLE1BQU07O0NBRTVCLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLGVBQXdCO0VBQ3BFLE9BQ0UsYUFBYSxRQUFRLG1CQUFtQixNQUFNLFVBQzlDLGVBQWUsUUFBUSxtQkFBbUIsTUFBTTtDQUVwRCxDQUFDOztDQUdELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBbUUsT0FBTzs7Q0FHdEcsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBZ0QsS0FBSztDQUNyRyxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLEVBQUU7Q0FDL0QsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUE2QixPQUFPOztDQUc1RCxNQUFNLENBQUMsaUJBQWlCLHNCQUFzQixTQUE0QixRQUFRO0NBQ2xGLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUF3QixJQUFJOztDQUdwRSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBNkIsSUFBSTs7Q0FHckUsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLO0NBQzVELE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEtBQUs7O0NBR3hELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQWlDLElBQUk7Q0FFbkYsTUFBTSxZQUFZLE1BQU0sS0FBSyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDO0NBRTVELE1BQU0scUJBQXFCLGlCQUFpQixNQUFNLE1BQU0sRUFBRSxPQUFPLGdCQUFnQjtDQUNqRixNQUFNLGVBQWUscUJBQXFCLFdBQVcsV0FBVyxvQkFBb0IsUUFBUTtDQUU1RixNQUFNLHdCQUF3QixZQUFZO0VBQ3hDLE1BQU0sZUFBZSxNQUFNLEtBQUs7RUFDaEMsTUFBTSxRQUFRLGFBQWEsTUFBTSxLQUFLLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDOztFQUd4RCxJQUFJLFFBQVEsSUFBSTtHQUNkLGdCQUNFLHdMQUNGO0dBQ0EsVUFBVSxvQkFBb0I7R0FDOUI7RUFDRjtFQUVBLFVBQVUsWUFBWTtFQUN0QixtQkFBbUIsUUFBUTtFQUMzQixnQkFBZ0IsSUFBSTtFQUVwQixNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7RUFDdkMsbUJBQW1CLFVBQVU7O0VBRzdCLE1BQU0saUJBQWlCLGlCQUFpQixtQkFBbUIsZ0JBQWdCLEdBQUcsSUFBSTtFQUNsRixNQUFNLGlCQUFpQixpQkFBaUIsbUJBQW1CLG1CQUFtQixHQUFHLElBQUk7RUFDckYsTUFBTSxpQkFBaUIsaUJBQWlCLG1CQUFtQixnQkFBZ0IsR0FBRyxJQUFJO0VBRWxGLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxNQUFNLHFCQUFxQjtJQUNoRCxRQUFRO0lBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7SUFDOUMsTUFBTSxLQUFLLFVBQVU7S0FDbkIsT0FBTztLQUNQLGNBQWM7S0FDZCxvQkFBb0IscUJBQXFCLFdBQVcscUJBQXFCO0tBQ3pFO0lBQ0YsQ0FBQztJQUNELFFBQVEsV0FBVztHQUNyQixDQUFDO0dBRUQsbUJBQW1CLGNBQWM7R0FFakMsTUFBTSxPQUE0QixNQUFNLFNBQVMsS0FBSztHQUV0RCxtQkFBbUIscUJBQXFCO0dBRXhDLElBQUksU0FBUyxNQUFNLEtBQUssV0FBVyxLQUFLLFVBQVU7O0lBRWhELGlCQUFpQjtLQUNmLGNBQWMsS0FBSyxRQUFTO0tBQzVCLFVBQVUsUUFBUTtJQUNwQixHQUFHLEdBQUc7R0FDUixPQUFPOztJQUVMLElBQUksS0FBSyxlQUFlLGFBQWE7S0FDbkMsZ0JBQWdCLEtBQUssU0FBUyx5Q0FBeUM7S0FDdkUsVUFBVSxvQkFBb0I7SUFDaEMsT0FBTztLQUNMLGdCQUNFLEtBQUssU0FBUywwRkFDaEI7S0FDQSxVQUFVLG9CQUFvQjtJQUNoQztHQUNGO0VBQ0YsU0FBUyxLQUFVO0dBQ2pCLElBQUksSUFBSSxTQUFTLGNBQWM7SUFDN0IsVUFBVSxPQUFPO0lBQ2pCO0dBQ0Y7R0FDQSxRQUFRLE1BQU0sMkJBQTJCLEdBQUc7R0FDNUMsZ0JBQWdCLEtBQUssV0FBVywrQ0FBK0M7R0FDL0UsVUFBVSxvQkFBb0I7RUFDaEMsVUFBVTtHQUNSLGFBQWEsY0FBYztHQUMzQixhQUFhLGNBQWM7R0FDM0IsYUFBYSxjQUFjO0VBQzdCO0NBQ0Y7Q0FFQSxNQUFNLCtCQUErQjtFQUNuQyxJQUFJLGlCQUFpQjtHQUNuQixnQkFBZ0IsTUFBTTtFQUN4QjtFQUNBLFVBQVUsT0FBTztDQUNuQjtDQUVBLE1BQU0sMkJBQTJCO0VBQy9CLFVBQVUsT0FBTztDQUNuQjtDQUVBLE1BQU0sa0NBQWtDO0VBQ3RDLFNBQVMsRUFBRTtFQUNYLGNBQWMsSUFBSTtFQUNsQixVQUFVLE9BQU87Q0FDbkI7Q0FFQSxNQUFNLDhCQUE4QjtFQUNsQyxTQUFTLGtCQUFrQjtFQUMzQixVQUFVLE9BQU87Q0FDbkI7O0NBR0EsSUFBSSxhQUFhO0NBQ2pCLElBQUksQ0FBQyxpQkFBaUIsYUFBYTtNQUM5QixJQUFJLFdBQVcsY0FBYyxhQUFhO01BQzFDLElBQUksV0FBVyxVQUFVLGFBQWE7Q0FFM0MsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsV0FBRDtJQUNFLGFBQWE7SUFDYixlQUFlLFlBQVk7SUFDM0IsY0FBYyxZQUFZO0lBQzFCLFlBQVksWUFBWSxXQUFXO0lBQ25DLHlCQUF5QixtQkFBbUIsSUFBSTtJQUNoRCx1QkFBdUIsaUJBQWlCLElBQUk7SUFDNUMsU0FBUztJQUNULHNCQUFzQjtLQUNwQixJQUFJLFlBQVk7TUFDZCxNQUFNLGFBQWEsV0FBVyxXQUFXLGFBQWEsYUFBYTtNQUNuRSxjQUFjO09BQUUsR0FBRztPQUFZLFFBQVE7TUFBVyxDQUFDO0tBQ3JEO0lBQ0Y7SUFDQSxvQkFBb0IsY0FBYyxlQUFlLFVBQVU7SUFDM0QsbUJBQW1CLGNBQWMsY0FBYyxVQUFVO0lBQ3pELG1CQUFtQixjQUFjLHdCQUF3QixVQUFVO0dBQ3BFOzs7OztHQUdELHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osQ0FBQyxrQkFDQSx3QkFBQyxjQUFELEVBQWMsdUJBQXVCLG1CQUFtQixJQUFJLEVBQUk7Ozs7ZUFDOUQsV0FBVyxVQUNiLHdCQUFDLGFBQUQ7S0FDUztLQUNHO0tBQ1E7S0FDRztLQUNEO0tBQ0c7S0FDakI7S0FDRztLQUNULFlBQVk7SUFDYjs7OztlQUNDLFdBQVcsZUFDYix3QkFBQyxrQkFBRDtLQUNFLGNBQWM7S0FDSDtLQUNHO0tBQ2QsVUFBVTtJQUNYOzs7O2VBQ0MsV0FBVyx1QkFDYix3QkFBQyx5QkFBRDtLQUNFLGNBQWMsZ0JBQWdCO0tBQzlCLFlBQVk7S0FDWixjQUFjO0tBQ2QsbUJBQW1CLGlCQUFpQixJQUFJO0lBQ3pDOzs7O2VBQ0MsV0FBVyxZQUFZLGFBQ3pCLHdCQUFDLGNBQUQ7S0FDRSxVQUFVO0tBQ1YsbUJBQW1CLFlBQVksY0FBYyxPQUFPO0tBQ3BELG9CQUFvQixlQUFlLFVBQVU7S0FDN0MsbUJBQW1CLGNBQWMsVUFBVTtLQUMzQyxtQkFBbUIsd0JBQXdCLFVBQVU7S0FDckQseUJBQXlCLG1CQUFtQixJQUFJO0tBQ2hELFNBQVM7SUFDVjs7OztlQUNDO0dBQ0Q7Ozs7O0dBR0osbUJBQ0Msd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUVFLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLFVBQVUsT0FBTztNQUNoQyxXQUFXLDRGQUNULFdBQVcsVUFDUCxzREFDQTtnQkFMUixDQVFFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFvQztNQUFpQjs7OztnQkFDckUsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXFCO01BQVk7Ozs7Y0FDM0M7Ozs7OztLQUdSLHdCQUFDLFVBQUQ7TUFDRSxVQUFVLFdBQVcsV0FBVyxDQUFDO01BQ2pDLGVBQWU7T0FDYixJQUFJLFdBQVcsWUFBWSxPQUFPO1FBQ2hDLHNCQUFzQjtPQUN4QjtNQUNGO01BQ0EsV0FBVyw0RkFDVCxXQUFXLGVBQ1Asc0RBQ0E7Z0JBVlIsQ0FhRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBb0M7TUFBbUI7Ozs7Z0JBQ3ZFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFxQjtNQUFhOzs7O2NBQzVDOzs7Ozs7S0FHUix3QkFBQyxVQUFEO01BQ0UsVUFBVSxDQUFDO01BQ1gsZUFBZTtPQUNiLElBQUksWUFBWSxVQUFVLFFBQVE7TUFDcEM7TUFDQSxXQUFXLDRGQUNULFdBQVcsV0FDUCxzREFDQTtnQkFSUixDQVdFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFvQztNQUFVOzs7O2dCQUM5RCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBcUI7TUFBWTs7OztjQUMzQzs7Ozs7O0tBR1Isd0JBQUMsVUFBRDtNQUNFLGVBQWUsbUJBQW1CLElBQUk7TUFDdEMsV0FBVTtnQkFGWixDQUlFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFvQztNQUFrQjs7OztnQkFDdEUsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXFCO01BQWE7Ozs7Y0FDNUM7Ozs7OztJQUNMOzs7Ozs7R0FJTixtQkFDQyx3QkFBQyxvQkFBRCxFQUFvQixlQUFlLG1CQUFtQixLQUFLLEVBQUk7Ozs7O0dBSWhFLGlCQUNDLHdCQUFDLFdBQUQ7SUFDRSxlQUFlLGlCQUFpQixLQUFLO0lBQ3JDLHlCQUF5QixtQkFBbUIsSUFBSTtHQUNqRDs7Ozs7RUFFQTs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEBsaWNlbnNlXG4gKiBTUERYLUxpY2Vuc2UtSWRlbnRpZmllcjogQXBhY2hlLTIuMFxuICovXG5cbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgVG9wQXBwQmFyIH0gZnJvbSAnLi9jb21wb25lbnRzL1RvcEFwcEJhcic7XG5pbXBvcnQgeyBQYXNzY29kZUdhdGUgfSBmcm9tICcuL2NvbXBvbmVudHMvUGFzc2NvZGVHYXRlJztcbmltcG9ydCB7IElucHV0U2NyZWVuIH0gZnJvbSAnLi9jb21wb25lbnRzL0lucHV0U2NyZWVuJztcbmltcG9ydCB7IFByb2Nlc3NpbmdTY3JlZW4sIFByb2Nlc3NpbmdTdGVwS2V5IH0gZnJvbSAnLi9jb21wb25lbnRzL1Byb2Nlc3NpbmdTY3JlZW4nO1xuaW1wb3J0IHsgSW5zdWZmaWNpZW50U3RlcHNTY3JlZW4gfSBmcm9tICcuL2NvbXBvbmVudHMvSW5zdWZmaWNpZW50U3RlcHNTY3JlZW4nO1xuaW1wb3J0IHsgUmV2aWV3U2NyZWVuIH0gZnJvbSAnLi9jb21wb25lbnRzL1Jldmlld1NjcmVlbic7XG5pbXBvcnQgeyBOZXRsaWZ5RGVwbG95TW9kYWwgfSBmcm9tICcuL2NvbXBvbmVudHMvTmV0bGlmeURlcGxveU1vZGFsJztcbmltcG9ydCB7IEhlbHBNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9IZWxwTW9kYWwnO1xuaW1wb3J0IHsgU09QRG9jdW1lbnQsIEdlbmVyYXRlU09QUmVzcG9uc2UgfSBmcm9tICcuL3R5cGVzL3NvcCc7XG5pbXBvcnQgeyBTQU1QTEVfTUVTU1lfTk9URVMsIFBSRVNFVF9URU1QTEFURVMgfSBmcm9tICcuL2RhdGEvdGVtcGxhdGVzJztcbmltcG9ydCB7IGRvd25sb2FkQXNEb2N4LCBkb3dubG9hZEFzUGRmLCBkb3dubG9hZEdlbmVyYXRpb25Ob3RlcyB9IGZyb20gJy4vdXRpbHMvZXhwb3J0ZXInO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIC8vIEF1dGhlbnRpY2F0aW9uIHN0YXRlXG4gIGNvbnN0IFtpc0F1dGhlbnRpY2F0ZWQsIHNldElzQXV0aGVudGljYXRlZF0gPSB1c2VTdGF0ZTxib29sZWFuPigoKSA9PiB7XG4gICAgcmV0dXJuIChcbiAgICAgIGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdzb3BfcGFzc2NvZGVfYXV0aCcpID09PSAndHJ1ZScgfHxcbiAgICAgIHNlc3Npb25TdG9yYWdlLmdldEl0ZW0oJ3NvcF9wYXNzY29kZV9hdXRoJykgPT09ICd0cnVlJ1xuICAgICk7XG4gIH0pO1xuXG4gIC8vIEFwcCB3b3JrZmxvdyBzY3JlZW4gc3RhdGVcbiAgY29uc3QgW3NjcmVlbiwgc2V0U2NyZWVuXSA9IHVzZVN0YXRlPCdpbnB1dCcgfCAncHJvY2Vzc2luZycgfCAncmV2aWV3JyB8ICdpbnN1ZmZpY2llbnRfc3RlcHMnPignaW5wdXQnKTtcblxuICAvLyBJbnB1dCBzdGF0ZVxuICBjb25zdCBbbm90ZXMsIHNldE5vdGVzXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW3NlbGVjdGVkVGVtcGxhdGUsIHNldFNlbGVjdGVkVGVtcGxhdGVdID0gdXNlU3RhdGU8J2lzbycgfCAnc2ltcGxlJyB8ICdhdWRpdCcgfCAnY3VzdG9tJz4oJ2lzbycpO1xuICBjb25zdCBbY3VzdG9tVGVtcGxhdGVUZXh0LCBzZXRDdXN0b21UZW1wbGF0ZVRleHRdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbdG9uZSwgc2V0VG9uZV0gPSB1c2VTdGF0ZTwncGxhaW4nIHwgJ2Zvcm1hbCc+KCdwbGFpbicpO1xuXG4gIC8vIFByb2Nlc3NpbmcgcHJvZ3Jlc3Mgc3RhdGVcbiAgY29uc3QgW3Byb2Nlc3NpbmdTdGFnZSwgc2V0UHJvY2Vzc2luZ1N0YWdlXSA9IHVzZVN0YXRlPFByb2Nlc3NpbmdTdGVwS2V5PignaW5nZXN0Jyk7XG4gIGNvbnN0IFtlcnJvck1lc3NhZ2UsIHNldEVycm9yTWVzc2FnZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICAvLyBBY3RpdmUgU09QIERvY3VtZW50IHN0YXRlXG4gIGNvbnN0IFtjdXJyZW50RG9jLCBzZXRDdXJyZW50RG9jXSA9IHVzZVN0YXRlPFNPUERvY3VtZW50IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gTW9kYWxzXG4gIGNvbnN0IFtzaG93RGVwbG95TW9kYWwsIHNldFNob3dEZXBsb3lNb2RhbF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtzaG93SGVscE1vZGFsLCBzZXRTaG93SGVscE1vZGFsXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICAvLyBDYW5jZWwgY29udHJvbGxlciBmb3IgaW4tZmxpZ2h0IGdlbmVyYXRpb25cbiAgY29uc3QgW2Fib3J0Q29udHJvbGxlciwgc2V0QWJvcnRDb250cm9sbGVyXSA9IHVzZVN0YXRlPEFib3J0Q29udHJvbGxlciB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IHdvcmRDb3VudCA9IG5vdGVzLnRyaW0oKS5zcGxpdCgvXFxzKy8pLmZpbHRlcihCb29sZWFuKS5sZW5ndGg7XG5cbiAgY29uc3QgY3VycmVudFRlbXBsYXRlRGVmID0gUFJFU0VUX1RFTVBMQVRFUy5maW5kKCh0KSA9PiB0LmlkID09PSBzZWxlY3RlZFRlbXBsYXRlKTtcbiAgY29uc3QgdGVtcGxhdGVOYW1lID0gc2VsZWN0ZWRUZW1wbGF0ZSA9PT0gJ2N1c3RvbScgPyAnQ3VzdG9tJyA6IGN1cnJlbnRUZW1wbGF0ZURlZj8ubmFtZSB8fCAnU3RhbmRhcmQnO1xuXG4gIGNvbnN0IGhhbmRsZVN0YXJ0R2VuZXJhdGlvbiA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCB0cmltbWVkTm90ZXMgPSBub3Rlcy50cmltKCk7XG4gICAgY29uc3QgY291bnQgPSB0cmltbWVkTm90ZXMuc3BsaXQoL1xccysvKS5maWx0ZXIoQm9vbGVhbikubGVuZ3RoO1xuXG4gICAgLy8gQ2xpZW50LXNpZGUgcXVpY2sgZ3VhcmRyYWlsIGZvciBicmllZiBpbnB1dHMgKDwgMTUgd29yZHMpXG4gICAgaWYgKGNvdW50IDwgMTUpIHtcbiAgICAgIHNldEVycm9yTWVzc2FnZShcbiAgICAgICAgJ1lvdXIgbm90ZXMgYXBwZWFyIHRvIGJlIHRvbyBicmllZiAodW5kZXIgMTUgd29yZHMpIG9yIG1pc3NpbmcgY2hyb25vbG9naWNhbCBzdGVwcy4gQW4gU09QIG5lZWRzIGF0IGxlYXN0IGEgZmV3IHNlcXVlbnRpYWwgYWN0aW9ucyBvciByZXNwb25zaWJpbGl0aWVzIHRvIGJ1aWxkIGEgc3RydWN0dXJlZCBwcm9jZWR1cmUuJ1xuICAgICAgKTtcbiAgICAgIHNldFNjcmVlbignaW5zdWZmaWNpZW50X3N0ZXBzJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgc2V0U2NyZWVuKCdwcm9jZXNzaW5nJyk7XG4gICAgc2V0UHJvY2Vzc2luZ1N0YWdlKCdpbmdlc3QnKTtcbiAgICBzZXRFcnJvck1lc3NhZ2UobnVsbCk7XG5cbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIHNldEFib3J0Q29udHJvbGxlcihjb250cm9sbGVyKTtcblxuICAgIC8vIFByb2dyZXNzIHN0ZXAgbWlsZXN0b25lcyB3aGlsZSBtb2RlbCBwcm9jZXNzZXNcbiAgICBjb25zdCBwcm9ncmVzc1RpbWVyMSA9IHNldFRpbWVvdXQoKCkgPT4gc2V0UHJvY2Vzc2luZ1N0YWdlKCdpZGVudGlmeV9zdGVwcycpLCAxMjAwKTtcbiAgICBjb25zdCBwcm9ncmVzc1RpbWVyMiA9IHNldFRpbWVvdXQoKCkgPT4gc2V0UHJvY2Vzc2luZ1N0YWdlKCdjaGVja19jb3JlX2ZpZWxkcycpLCAyODAwKTtcbiAgICBjb25zdCBwcm9ncmVzc1RpbWVyMyA9IHNldFRpbWVvdXQoKCkgPT4gc2V0UHJvY2Vzc2luZ1N0YWdlKCdtYXRjaF90ZW1wbGF0ZScpLCA0NTAwKTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKCcvYXBpL2dlbmVyYXRlLXNvcCcsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyB9LFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgbm90ZXM6IHRyaW1tZWROb3RlcyxcbiAgICAgICAgICB0ZW1wbGF0ZVR5cGU6IHNlbGVjdGVkVGVtcGxhdGUsXG4gICAgICAgICAgY3VzdG9tVGVtcGxhdGVUZXh0OiBzZWxlY3RlZFRlbXBsYXRlID09PSAnY3VzdG9tJyA/IGN1c3RvbVRlbXBsYXRlVGV4dCA6IHVuZGVmaW5lZCxcbiAgICAgICAgICB0b25lLFxuICAgICAgICB9KSxcbiAgICAgICAgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCxcbiAgICAgIH0pO1xuXG4gICAgICBzZXRQcm9jZXNzaW5nU3RhZ2UoJ2ZsYWdfbWlzc2luZycpO1xuXG4gICAgICBjb25zdCBkYXRhOiBHZW5lcmF0ZVNPUFJlc3BvbnNlID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuXG4gICAgICBzZXRQcm9jZXNzaW5nU3RhZ2UoJ3N5bnRoZXNpemVfZXZpZGVuY2UnKTtcblxuICAgICAgaWYgKHJlc3BvbnNlLm9rICYmIGRhdGEuc3VjY2VzcyAmJiBkYXRhLmRvY3VtZW50KSB7XG4gICAgICAgIC8vIFN1Y2Nlc3NmdWwgZ2VuZXJhdGlvbiFcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgc2V0Q3VycmVudERvYyhkYXRhLmRvY3VtZW50ISk7XG4gICAgICAgICAgc2V0U2NyZWVuKCdyZXZpZXcnKTtcbiAgICAgICAgfSwgNjAwKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEZhaWx1cmUgb3IgYnJldml0eSBndWFyZHJhaWwgdHJpZ2dlcmVkXG4gICAgICAgIGlmIChkYXRhLmVycm9yX3R5cGUgPT09ICd0b29fYnJpZWYnKSB7XG4gICAgICAgICAgc2V0RXJyb3JNZXNzYWdlKGRhdGEuZXJyb3IgfHwgJ05vdGVzIGFyZSB0b28gYnJpZWYgdG8gZ2VuZXJhdGUgYW4gU09QLicpO1xuICAgICAgICAgIHNldFNjcmVlbignaW5zdWZmaWNpZW50X3N0ZXBzJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgc2V0RXJyb3JNZXNzYWdlKFxuICAgICAgICAgICAgZGF0YS5lcnJvciB8fCAnRmFpbGVkIHRvIGdlbmVyYXRlIFNPUCBmcm9tIG5vdGVzLiBQbGVhc2UgdmVyaWZ5IHlvdXIgR2VtaW5pIEFQSSBrZXkgb3Igbm90ZXMgc3RydWN0dXJlLidcbiAgICAgICAgICApO1xuICAgICAgICAgIHNldFNjcmVlbignaW5zdWZmaWNpZW50X3N0ZXBzJyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnI6IGFueSkge1xuICAgICAgaWYgKGVyci5uYW1lID09PSAnQWJvcnRFcnJvcicpIHtcbiAgICAgICAgc2V0U2NyZWVuKCdpbnB1dCcpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zb2xlLmVycm9yKCdHZW5lcmF0aW9uIGZldGNoIGVycm9yOicsIGVycik7XG4gICAgICBzZXRFcnJvck1lc3NhZ2UoZXJyPy5tZXNzYWdlIHx8ICdOZXR3b3JrIG9yIHNlcnZlciBlcnJvciB3aGlsZSBnZW5lcmF0aW5nIFNPUC4nKTtcbiAgICAgIHNldFNjcmVlbignaW5zdWZmaWNpZW50X3N0ZXBzJyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGNsZWFyVGltZW91dChwcm9ncmVzc1RpbWVyMSk7XG4gICAgICBjbGVhclRpbWVvdXQocHJvZ3Jlc3NUaW1lcjIpO1xuICAgICAgY2xlYXJUaW1lb3V0KHByb2dyZXNzVGltZXIzKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2FuY2VsR2VuZXJhdGlvbiA9ICgpID0+IHtcbiAgICBpZiAoYWJvcnRDb250cm9sbGVyKSB7XG4gICAgICBhYm9ydENvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICB9XG4gICAgc2V0U2NyZWVuKCdpbnB1dCcpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVJlc2V0VG9JbnB1dCA9ICgpID0+IHtcbiAgICBzZXRTY3JlZW4oJ2lucHV0Jyk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlU3RhcnRPdmVyQ29tcGxldGVseSA9ICgpID0+IHtcbiAgICBzZXROb3RlcygnJyk7XG4gICAgc2V0Q3VycmVudERvYyhudWxsKTtcbiAgICBzZXRTY3JlZW4oJ2lucHV0Jyk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlTG9hZFNhbXBsZU5vdGVzID0gKCkgPT4ge1xuICAgIHNldE5vdGVzKFNBTVBMRV9NRVNTWV9OT1RFUyk7XG4gICAgc2V0U2NyZWVuKCdpbnB1dCcpO1xuICB9O1xuXG4gIC8vIERldGVybWluZSBjdXJyZW50IGFjdGl2ZSBzdGVwIG51bWJlciBmb3IgaGVhZGVyXG4gIGxldCBzdGVwTnVtYmVyID0gMTtcbiAgaWYgKCFpc0F1dGhlbnRpY2F0ZWQpIHN0ZXBOdW1iZXIgPSAwO1xuICBlbHNlIGlmIChzY3JlZW4gPT09ICdwcm9jZXNzaW5nJykgc3RlcE51bWJlciA9IDI7XG4gIGVsc2UgaWYgKHNjcmVlbiA9PT0gJ3JldmlldycpIHN0ZXBOdW1iZXIgPSAzO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC1zY3JlZW4gYmctYmFja2dyb3VuZCB0ZXh0LW9uLXN1cmZhY2UgZmxleCBmbGV4LWNvbCBmb250LXNhbnMgc2VsZWN0aW9uOmJnLXNlY29uZGFyeS1jb250YWluZXIgc2VsZWN0aW9uOnRleHQtcHJpbWFyeVwiPlxuICAgICAgey8qIFRvcCBBcHBsaWNhdGlvbiBCYXIgKi99XG4gICAgICA8VG9wQXBwQmFyXG4gICAgICAgIGN1cnJlbnRTdGVwPXtzdGVwTnVtYmVyfVxuICAgICAgICBkb2N1bWVudFRpdGxlPXtjdXJyZW50RG9jPy50aXRsZX1cbiAgICAgICAgZG9jdW1lbnRDb2RlPXtjdXJyZW50RG9jPy5jb2RlfVxuICAgICAgICBpc0FwcHJvdmVkPXtjdXJyZW50RG9jPy5zdGF0dXMgPT09ICdBUFBST1ZFRCd9XG4gICAgICAgIG9uT3BlbkRlcGxveU1vZGFsPXsoKSA9PiBzZXRTaG93RGVwbG95TW9kYWwodHJ1ZSl9XG4gICAgICAgIG9uT3BlbkhlbHBNb2RhbD17KCkgPT4gc2V0U2hvd0hlbHBNb2RhbCh0cnVlKX1cbiAgICAgICAgb25SZXNldD17aGFuZGxlUmVzZXRUb0lucHV0fVxuICAgICAgICBvbk1hcmtBcHByb3ZlZD17KCkgPT4ge1xuICAgICAgICAgIGlmIChjdXJyZW50RG9jKSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0U3RhdHVzID0gY3VycmVudERvYy5zdGF0dXMgPT09ICdBUFBST1ZFRCcgPyAnUkVWSUVXRUQnIDogJ0FQUFJPVkVEJztcbiAgICAgICAgICAgIHNldEN1cnJlbnREb2MoeyAuLi5jdXJyZW50RG9jLCBzdGF0dXM6IG5leHRTdGF0dXMgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9fVxuICAgICAgICBvbkV4cG9ydFdvcmQ9eygpID0+IGN1cnJlbnREb2MgJiYgZG93bmxvYWRBc0RvY3goY3VycmVudERvYyl9XG4gICAgICAgIG9uRXhwb3J0UGRmPXsoKSA9PiBjdXJyZW50RG9jICYmIGRvd25sb2FkQXNQZGYoY3VycmVudERvYyl9XG4gICAgICAgIG9uRXhwb3J0VHh0PXsoKSA9PiBjdXJyZW50RG9jICYmIGRvd25sb2FkR2VuZXJhdGlvbk5vdGVzKGN1cnJlbnREb2MpfVxuICAgICAgLz5cblxuICAgICAgey8qIE1haW4gU2NyZWVuIFJvdXRlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgeyFpc0F1dGhlbnRpY2F0ZWQgPyAoXG4gICAgICAgICAgPFBhc3Njb2RlR2F0ZSBvbkF1dGhlbnRpY2F0ZWQ9eygpID0+IHNldElzQXV0aGVudGljYXRlZCh0cnVlKX0gLz5cbiAgICAgICAgKSA6IHNjcmVlbiA9PT0gJ2lucHV0JyA/IChcbiAgICAgICAgICA8SW5wdXRTY3JlZW5cbiAgICAgICAgICAgIG5vdGVzPXtub3Rlc31cbiAgICAgICAgICAgIHNldE5vdGVzPXtzZXROb3Rlc31cbiAgICAgICAgICAgIHNlbGVjdGVkVGVtcGxhdGU9e3NlbGVjdGVkVGVtcGxhdGV9XG4gICAgICAgICAgICBzZXRTZWxlY3RlZFRlbXBsYXRlPXtzZXRTZWxlY3RlZFRlbXBsYXRlfVxuICAgICAgICAgICAgY3VzdG9tVGVtcGxhdGVUZXh0PXtjdXN0b21UZW1wbGF0ZVRleHR9XG4gICAgICAgICAgICBzZXRDdXN0b21UZW1wbGF0ZVRleHQ9e3NldEN1c3RvbVRlbXBsYXRlVGV4dH1cbiAgICAgICAgICAgIHRvbmU9e3RvbmV9XG4gICAgICAgICAgICBzZXRUb25lPXtzZXRUb25lfVxuICAgICAgICAgICAgb25HZW5lcmF0ZT17aGFuZGxlU3RhcnRHZW5lcmF0aW9ufVxuICAgICAgICAgIC8+XG4gICAgICAgICkgOiBzY3JlZW4gPT09ICdwcm9jZXNzaW5nJyA/IChcbiAgICAgICAgICA8UHJvY2Vzc2luZ1NjcmVlblxuICAgICAgICAgICAgY3VycmVudFN0YWdlPXtwcm9jZXNzaW5nU3RhZ2V9XG4gICAgICAgICAgICB3b3JkQ291bnQ9e3dvcmRDb3VudH1cbiAgICAgICAgICAgIHRlbXBsYXRlTmFtZT17dGVtcGxhdGVOYW1lfVxuICAgICAgICAgICAgb25DYW5jZWw9e2hhbmRsZUNhbmNlbEdlbmVyYXRpb259XG4gICAgICAgICAgLz5cbiAgICAgICAgKSA6IHNjcmVlbiA9PT0gJ2luc3VmZmljaWVudF9zdGVwcycgPyAoXG4gICAgICAgICAgPEluc3VmZmljaWVudFN0ZXBzU2NyZWVuXG4gICAgICAgICAgICBlcnJvck1lc3NhZ2U9e2Vycm9yTWVzc2FnZSB8fCB1bmRlZmluZWR9XG4gICAgICAgICAgICBvblRyeUFnYWluPXtoYW5kbGVSZXNldFRvSW5wdXR9XG4gICAgICAgICAgICBvbkxvYWRTYW1wbGU9e2hhbmRsZUxvYWRTYW1wbGVOb3Rlc31cbiAgICAgICAgICAgIG9uT3Blbkd1aWRlPXsoKSA9PiBzZXRTaG93SGVscE1vZGFsKHRydWUpfVxuICAgICAgICAgIC8+XG4gICAgICAgICkgOiBzY3JlZW4gPT09ICdyZXZpZXcnICYmIGN1cnJlbnREb2MgPyAoXG4gICAgICAgICAgPFJldmlld1NjcmVlblxuICAgICAgICAgICAgZG9jdW1lbnQ9e2N1cnJlbnREb2N9XG4gICAgICAgICAgICBvblVwZGF0ZURvY3VtZW50PXsodXBkYXRlZCkgPT4gc2V0Q3VycmVudERvYyh1cGRhdGVkKX1cbiAgICAgICAgICAgIG9uRXhwb3J0V29yZD17KCkgPT4gZG93bmxvYWRBc0RvY3goY3VycmVudERvYyl9XG4gICAgICAgICAgICBvbkV4cG9ydFBkZj17KCkgPT4gZG93bmxvYWRBc1BkZihjdXJyZW50RG9jKX1cbiAgICAgICAgICAgIG9uRXhwb3J0VHh0PXsoKSA9PiBkb3dubG9hZEdlbmVyYXRpb25Ob3RlcyhjdXJyZW50RG9jKX1cbiAgICAgICAgICAgIG9uT3BlbkRlcGxveU1vZGFsPXsoKSA9PiBzZXRTaG93RGVwbG95TW9kYWwodHJ1ZSl9XG4gICAgICAgICAgICBvblJlc2V0PXtoYW5kbGVTdGFydE92ZXJDb21wbGV0ZWx5fVxuICAgICAgICAgIC8+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNb2JpbGUgQm90dG9tIE5hdmlnYXRpb24gQmFyIChNYXRjaGluZyBTdGl0Y2ggRXhwb3J0KSAqL31cbiAgICAgIHtpc0F1dGhlbnRpY2F0ZWQgJiYgKFxuICAgICAgICA8bmF2IGNsYXNzTmFtZT1cImZpeGVkIGJvdHRvbS0wIGxlZnQtMCB3LWZ1bGwgei01MCBmbGV4IG1kOmhpZGRlbiBqdXN0aWZ5LWFyb3VuZCBpdGVtcy1jZW50ZXIgcHgtNCBweS0yIGJnLXN1cmZhY2UtY29udGFpbmVyLWxvd2VzdCBib3JkZXItdCBib3JkZXItb3V0bGluZS12YXJpYW50IHNoYWRvdy1zbVwiPlxuICAgICAgICAgIHsvKiBVcGxvYWQgVGFiICovfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNjcmVlbignaW5wdXQnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB4LTMgcHktMSByb3VuZGVkLWxnIHRleHQteHMgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgc2NyZWVuID09PSAnaW5wdXQnXG4gICAgICAgICAgICAgICAgPyAnYmctc2Vjb25kYXJ5LWNvbnRhaW5lciB0ZXh0LXByaW1hcnkgZm9udC1zZW1pYm9sZCdcbiAgICAgICAgICAgICAgICA6ICd0ZXh0LXNlY29uZGFyeSBob3Zlcjp0ZXh0LW9uLXN1cmZhY2UnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtbGdcIj51cGxvYWRfZmlsZTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIG10LTAuNVwiPlVwbG9hZDwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIHsvKiBQcm9jZXNzIFRhYiAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBkaXNhYmxlZD17c2NyZWVuID09PSAnaW5wdXQnICYmICFub3Rlc31cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgaWYgKHNjcmVlbiA9PT0gJ3JldmlldycgfHwgbm90ZXMpIHtcbiAgICAgICAgICAgICAgICBoYW5kbGVTdGFydEdlbmVyYXRpb24oKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB4LTMgcHktMSByb3VuZGVkLWxnIHRleHQteHMgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgc2NyZWVuID09PSAncHJvY2Vzc2luZydcbiAgICAgICAgICAgICAgICA/ICdiZy1zZWNvbmRhcnktY29udGFpbmVyIHRleHQtcHJpbWFyeSBmb250LXNlbWlib2xkJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtb24tc3VyZmFjZSBkaXNhYmxlZDpvcGFjaXR5LTQwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF0ZXJpYWwtc3ltYm9scy1vdXRsaW5lZCB0ZXh0LWxnXCI+aG91cmdsYXNzX3RvcDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIG10LTAuNVwiPlByb2Nlc3M8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICB7LyogUmV2aWV3IFRhYiAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBkaXNhYmxlZD17IWN1cnJlbnREb2N9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgIGlmIChjdXJyZW50RG9jKSBzZXRTY3JlZW4oJ3JldmlldycpO1xuICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHB4LTMgcHktMSByb3VuZGVkLWxnIHRleHQteHMgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgc2NyZWVuID09PSAncmV2aWV3J1xuICAgICAgICAgICAgICAgID8gJ2JnLXNlY29uZGFyeS1jb250YWluZXIgdGV4dC1wcmltYXJ5IGZvbnQtc2VtaWJvbGQnXG4gICAgICAgICAgICAgICAgOiAndGV4dC1zZWNvbmRhcnkgaG92ZXI6dGV4dC1vbi1zdXJmYWNlIGRpc2FibGVkOm9wYWNpdHktNDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtbGdcIj5ydWxlPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gbXQtMC41XCI+UmV2aWV3PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgey8qIERlcGxveSAvIE5ldGxpZnkgVGFiICovfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNob3dEZXBsb3lNb2RhbCh0cnVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2Vjb25kYXJ5IGhvdmVyOnRleHQtb24tc3VyZmFjZSBweC0zIHB5LTEgcm91bmRlZC1sZyB0ZXh0LXhzIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtYXRlcmlhbC1zeW1ib2xzLW91dGxpbmVkIHRleHQtbGdcIj5jbG91ZF91cGxvYWQ8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBtdC0wLjVcIj5OZXRsaWZ5PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L25hdj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBOZXRsaWZ5IERlcGxveSBNb2RhbCAqL31cbiAgICAgIHtzaG93RGVwbG95TW9kYWwgJiYgKFxuICAgICAgICA8TmV0bGlmeURlcGxveU1vZGFsIG9uQ2xvc2U9eygpID0+IHNldFNob3dEZXBsb3lNb2RhbChmYWxzZSl9IC8+XG4gICAgICApfVxuXG4gICAgICB7LyogSGVscCAmIERvY3VtZW50YXRpb24gTW9kYWwgKi99XG4gICAgICB7c2hvd0hlbHBNb2RhbCAmJiAoXG4gICAgICAgIDxIZWxwTW9kYWxcbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93SGVscE1vZGFsKGZhbHNlKX1cbiAgICAgICAgICBvbk9wZW5EZXBsb3lNb2RhbD17KCkgPT4gc2V0U2hvd0RlcGxveU1vZGFsKHRydWUpfVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==