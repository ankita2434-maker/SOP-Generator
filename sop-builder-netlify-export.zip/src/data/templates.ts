export const PRESET_TEMPLATES = [
	{
		id: "iso",
		name: "ISO-9001 Style",
		subtitle: "Auditable section codes, roles & metrics",
		icon: "verified",
		structureDescription: "Formal numbered clauses conforming to auditable standard structure: 1. Purpose & Scope, 2. Normative References & Definitions, 3. Roles & Responsibilities (RACI), 4. Step-by-Step Procedure with SLAs, 5. Quality Controls & Document Governance.",
		sections: [
			"Document Title & ID",
			"1. Purpose & Scope",
			"2. Roles & Responsibilities",
			"3. Step-by-Step Procedure",
			"4. Quality Controls & SLAs",
			"5. Document Governance & Metadata"
		]
	},
	{
		id: "simple",
		name: "Simple Internal",
		subtitle: "Checklists, team actions & FAQs",
		icon: "article",
		structureDescription: "Standard internal operational format: Title, Purpose, Scope, Definitions, Roles & Responsibilities, Process Steps, Document Metadata (Owner, Effective Date, Review Date).",
		sections: [
			"Title",
			"Purpose",
			"Scope",
			"Definitions",
			"Roles & Responsibilities",
			"Process Steps",
			"Document Governance (Owner, Effective Date, Version, Review Date)"
		]
	},
	{
		id: "audit",
		name: "Compliance-Style",
		subtitle: "Strict policy, risk flags & sign-offs",
		icon: "gavel",
		structureDescription: "Compliance and audit-ready framework: Policy & Regulatory Purpose, Scope & Jurisdiction, Control Objectives & Risk Flags, Segregation of Duties, Mandatory Operating Procedures, Control Sign-Offs & Audit Evidence Trail.",
		sections: [
			"Policy & Regulatory Purpose",
			"Scope & Jurisdictions",
			"Risk Flags & Control Objectives",
			"Roles & Segregation of Duties",
			"Mandatory Step-by-Step Procedure",
			"Control Sign-Offs & Audit Evidence Trail",
			"Document Governance & Metadata"
		]
	}
];
export const SAMPLE_MESSY_NOTES = `Audio Transcript & Slack Dump: Hardware Offboarding Workflow Sync
Attendees: Mark (People Ops), Sarah L. (IT Lead), Rachel (Legal)

[04:12] Mark (HR): We need clear timelines for equipment hand-in. People used to hold onto company MacBooks for weeks after leaving.
[04:30] Sarah (IT): Understood. Our standard protocol is revoking Okta and Google Workspace credentials right at the exit call (5:00 PM local time), and the courier returns kit ships inside 24 hours.
[04:45] Mark (HR): HR Operations kicks off the offboarding ticket in BambooHR roughly 5 business days before the last day, including home address for shipping return box.
[05:10] Mark (HR): And what about the NIST sanitization certificate?
[05:22] Sarah (IT): Once the courier delivers to IT cage, we run cryptographic NVMe wipes within Day 3 and upload tamper receipts to Jira. Hardware is reclassified in Snipe-IT ledger as "Available for Redeployment" or "Scheduled for E-Waste Disposal".
[06:05] Rachel (Legal): Remember the classification must be marked Internal Confidential for SOC 2 Type II audit. Scope applies to full-time, contract, and temporary staff globally with company laptops or YubiKeys valued over $250.
[06:40] Mark: Do we have a designated Process Owner or signed effective launch date yet?
[06:45] Sarah: We still need Ops Leadership to confirm the official Process Owner and set the exact Effective Date for the new quarter.`;

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsT0FBTyxNQUFNLG1CQUFxQztDQUNoRDtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sVUFBVTtFQUNWLE1BQU07RUFDTixzQkFDRTtFQUNGLFVBQVU7R0FDUjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRjtDQUNGO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLFVBQVU7RUFDVixNQUFNO0VBQ04sc0JBQ0U7RUFDRixVQUFVO0dBQ1I7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRjtDQUNGO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLFVBQVU7RUFDVixNQUFNO0VBQ04sc0JBQ0U7RUFDRixVQUFVO0dBQ1I7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRjtDQUNGO0FBQ0Y7QUFFQSxPQUFPLE1BQU0scUJBQXFCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInRlbXBsYXRlcy50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQcmVzZXRUZW1wbGF0ZSB9IGZyb20gJy4uL3R5cGVzL3NvcCc7XG5cbmV4cG9ydCBjb25zdCBQUkVTRVRfVEVNUExBVEVTOiBQcmVzZXRUZW1wbGF0ZVtdID0gW1xuICB7XG4gICAgaWQ6ICdpc28nLFxuICAgIG5hbWU6ICdJU08tOTAwMSBTdHlsZScsXG4gICAgc3VidGl0bGU6ICdBdWRpdGFibGUgc2VjdGlvbiBjb2Rlcywgcm9sZXMgJiBtZXRyaWNzJyxcbiAgICBpY29uOiAndmVyaWZpZWQnLFxuICAgIHN0cnVjdHVyZURlc2NyaXB0aW9uOlxuICAgICAgJ0Zvcm1hbCBudW1iZXJlZCBjbGF1c2VzIGNvbmZvcm1pbmcgdG8gYXVkaXRhYmxlIHN0YW5kYXJkIHN0cnVjdHVyZTogMS4gUHVycG9zZSAmIFNjb3BlLCAyLiBOb3JtYXRpdmUgUmVmZXJlbmNlcyAmIERlZmluaXRpb25zLCAzLiBSb2xlcyAmIFJlc3BvbnNpYmlsaXRpZXMgKFJBQ0kpLCA0LiBTdGVwLWJ5LVN0ZXAgUHJvY2VkdXJlIHdpdGggU0xBcywgNS4gUXVhbGl0eSBDb250cm9scyAmIERvY3VtZW50IEdvdmVybmFuY2UuJyxcbiAgICBzZWN0aW9uczogW1xuICAgICAgJ0RvY3VtZW50IFRpdGxlICYgSUQnLFxuICAgICAgJzEuIFB1cnBvc2UgJiBTY29wZScsXG4gICAgICAnMi4gUm9sZXMgJiBSZXNwb25zaWJpbGl0aWVzJyxcbiAgICAgICczLiBTdGVwLWJ5LVN0ZXAgUHJvY2VkdXJlJyxcbiAgICAgICc0LiBRdWFsaXR5IENvbnRyb2xzICYgU0xBcycsXG4gICAgICAnNS4gRG9jdW1lbnQgR292ZXJuYW5jZSAmIE1ldGFkYXRhJyxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgaWQ6ICdzaW1wbGUnLFxuICAgIG5hbWU6ICdTaW1wbGUgSW50ZXJuYWwnLFxuICAgIHN1YnRpdGxlOiAnQ2hlY2tsaXN0cywgdGVhbSBhY3Rpb25zICYgRkFRcycsXG4gICAgaWNvbjogJ2FydGljbGUnLFxuICAgIHN0cnVjdHVyZURlc2NyaXB0aW9uOlxuICAgICAgJ1N0YW5kYXJkIGludGVybmFsIG9wZXJhdGlvbmFsIGZvcm1hdDogVGl0bGUsIFB1cnBvc2UsIFNjb3BlLCBEZWZpbml0aW9ucywgUm9sZXMgJiBSZXNwb25zaWJpbGl0aWVzLCBQcm9jZXNzIFN0ZXBzLCBEb2N1bWVudCBNZXRhZGF0YSAoT3duZXIsIEVmZmVjdGl2ZSBEYXRlLCBSZXZpZXcgRGF0ZSkuJyxcbiAgICBzZWN0aW9uczogW1xuICAgICAgJ1RpdGxlJyxcbiAgICAgICdQdXJwb3NlJyxcbiAgICAgICdTY29wZScsXG4gICAgICAnRGVmaW5pdGlvbnMnLFxuICAgICAgJ1JvbGVzICYgUmVzcG9uc2liaWxpdGllcycsXG4gICAgICAnUHJvY2VzcyBTdGVwcycsXG4gICAgICAnRG9jdW1lbnQgR292ZXJuYW5jZSAoT3duZXIsIEVmZmVjdGl2ZSBEYXRlLCBWZXJzaW9uLCBSZXZpZXcgRGF0ZSknLFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBpZDogJ2F1ZGl0JyxcbiAgICBuYW1lOiAnQ29tcGxpYW5jZS1TdHlsZScsXG4gICAgc3VidGl0bGU6ICdTdHJpY3QgcG9saWN5LCByaXNrIGZsYWdzICYgc2lnbi1vZmZzJyxcbiAgICBpY29uOiAnZ2F2ZWwnLFxuICAgIHN0cnVjdHVyZURlc2NyaXB0aW9uOlxuICAgICAgJ0NvbXBsaWFuY2UgYW5kIGF1ZGl0LXJlYWR5IGZyYW1ld29yazogUG9saWN5ICYgUmVndWxhdG9yeSBQdXJwb3NlLCBTY29wZSAmIEp1cmlzZGljdGlvbiwgQ29udHJvbCBPYmplY3RpdmVzICYgUmlzayBGbGFncywgU2VncmVnYXRpb24gb2YgRHV0aWVzLCBNYW5kYXRvcnkgT3BlcmF0aW5nIFByb2NlZHVyZXMsIENvbnRyb2wgU2lnbi1PZmZzICYgQXVkaXQgRXZpZGVuY2UgVHJhaWwuJyxcbiAgICBzZWN0aW9uczogW1xuICAgICAgJ1BvbGljeSAmIFJlZ3VsYXRvcnkgUHVycG9zZScsXG4gICAgICAnU2NvcGUgJiBKdXJpc2RpY3Rpb25zJyxcbiAgICAgICdSaXNrIEZsYWdzICYgQ29udHJvbCBPYmplY3RpdmVzJyxcbiAgICAgICdSb2xlcyAmIFNlZ3JlZ2F0aW9uIG9mIER1dGllcycsXG4gICAgICAnTWFuZGF0b3J5IFN0ZXAtYnktU3RlcCBQcm9jZWR1cmUnLFxuICAgICAgJ0NvbnRyb2wgU2lnbi1PZmZzICYgQXVkaXQgRXZpZGVuY2UgVHJhaWwnLFxuICAgICAgJ0RvY3VtZW50IEdvdmVybmFuY2UgJiBNZXRhZGF0YScsXG4gICAgXSxcbiAgfSxcbl07XG5cbmV4cG9ydCBjb25zdCBTQU1QTEVfTUVTU1lfTk9URVMgPSBgQXVkaW8gVHJhbnNjcmlwdCAmIFNsYWNrIER1bXA6IEhhcmR3YXJlIE9mZmJvYXJkaW5nIFdvcmtmbG93IFN5bmNcbkF0dGVuZGVlczogTWFyayAoUGVvcGxlIE9wcyksIFNhcmFoIEwuIChJVCBMZWFkKSwgUmFjaGVsIChMZWdhbClcblxuWzA0OjEyXSBNYXJrIChIUik6IFdlIG5lZWQgY2xlYXIgdGltZWxpbmVzIGZvciBlcXVpcG1lbnQgaGFuZC1pbi4gUGVvcGxlIHVzZWQgdG8gaG9sZCBvbnRvIGNvbXBhbnkgTWFjQm9va3MgZm9yIHdlZWtzIGFmdGVyIGxlYXZpbmcuXG5bMDQ6MzBdIFNhcmFoIChJVCk6IFVuZGVyc3Rvb2QuIE91ciBzdGFuZGFyZCBwcm90b2NvbCBpcyByZXZva2luZyBPa3RhIGFuZCBHb29nbGUgV29ya3NwYWNlIGNyZWRlbnRpYWxzIHJpZ2h0IGF0IHRoZSBleGl0IGNhbGwgKDU6MDAgUE0gbG9jYWwgdGltZSksIGFuZCB0aGUgY291cmllciByZXR1cm5zIGtpdCBzaGlwcyBpbnNpZGUgMjQgaG91cnMuXG5bMDQ6NDVdIE1hcmsgKEhSKTogSFIgT3BlcmF0aW9ucyBraWNrcyBvZmYgdGhlIG9mZmJvYXJkaW5nIHRpY2tldCBpbiBCYW1ib29IUiByb3VnaGx5IDUgYnVzaW5lc3MgZGF5cyBiZWZvcmUgdGhlIGxhc3QgZGF5LCBpbmNsdWRpbmcgaG9tZSBhZGRyZXNzIGZvciBzaGlwcGluZyByZXR1cm4gYm94LlxuWzA1OjEwXSBNYXJrIChIUik6IEFuZCB3aGF0IGFib3V0IHRoZSBOSVNUIHNhbml0aXphdGlvbiBjZXJ0aWZpY2F0ZT9cblswNToyMl0gU2FyYWggKElUKTogT25jZSB0aGUgY291cmllciBkZWxpdmVycyB0byBJVCBjYWdlLCB3ZSBydW4gY3J5cHRvZ3JhcGhpYyBOVk1lIHdpcGVzIHdpdGhpbiBEYXkgMyBhbmQgdXBsb2FkIHRhbXBlciByZWNlaXB0cyB0byBKaXJhLiBIYXJkd2FyZSBpcyByZWNsYXNzaWZpZWQgaW4gU25pcGUtSVQgbGVkZ2VyIGFzIFwiQXZhaWxhYmxlIGZvciBSZWRlcGxveW1lbnRcIiBvciBcIlNjaGVkdWxlZCBmb3IgRS1XYXN0ZSBEaXNwb3NhbFwiLlxuWzA2OjA1XSBSYWNoZWwgKExlZ2FsKTogUmVtZW1iZXIgdGhlIGNsYXNzaWZpY2F0aW9uIG11c3QgYmUgbWFya2VkIEludGVybmFsIENvbmZpZGVudGlhbCBmb3IgU09DIDIgVHlwZSBJSSBhdWRpdC4gU2NvcGUgYXBwbGllcyB0byBmdWxsLXRpbWUsIGNvbnRyYWN0LCBhbmQgdGVtcG9yYXJ5IHN0YWZmIGdsb2JhbGx5IHdpdGggY29tcGFueSBsYXB0b3BzIG9yIFl1YmlLZXlzIHZhbHVlZCBvdmVyICQyNTAuXG5bMDY6NDBdIE1hcms6IERvIHdlIGhhdmUgYSBkZXNpZ25hdGVkIFByb2Nlc3MgT3duZXIgb3Igc2lnbmVkIGVmZmVjdGl2ZSBsYXVuY2ggZGF0ZSB5ZXQ/XG5bMDY6NDVdIFNhcmFoOiBXZSBzdGlsbCBuZWVkIE9wcyBMZWFkZXJzaGlwIHRvIGNvbmZpcm0gdGhlIG9mZmljaWFsIFByb2Nlc3MgT3duZXIgYW5kIHNldCB0aGUgZXhhY3QgRWZmZWN0aXZlIERhdGUgZm9yIHRoZSBuZXcgcXVhcnRlci5gO1xuIl19