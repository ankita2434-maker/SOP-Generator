import { GoogleGenAI, Type } from "/node_modules/.vite/deps/@google_genai.js?v=03df835a";
export async function processNotesWithGemini(req, apiKey) {
	const notes = req.notes?.trim() || "";
	const wordCount = notes.split(/\s+/).filter(Boolean).length;
	// Guardrail 1: Input brevity check (< 15 words or lacking actionable content)
	if (wordCount < 15) {
		return {
			success: false,
			error: "Your notes appear to be too brief (under 15 words) or missing chronological steps. An SOP needs at least a few sequential actions or responsibilities to build a structured procedure.",
			error_type: "too_brief"
		};
	}
	// Guardrail 2: Check for API Key
	const activeKey = apiKey || process.env.GEMINI_API_KEY;
	if (!activeKey) {
		return {
			success: false,
			error: "Missing GEMINI_API_KEY environment variable. Please configure your API key in environment variables or Netlify settings.",
			error_type: "api_error"
		};
	}
	const ai = new GoogleGenAI({
		apiKey: activeKey,
		httpOptions: { headers: { "User-Agent": "aistudio-build" } }
	});
	// Base system instruction (Exact as requested)
	let systemInstruction = `You convert messy operational notes into a formal Standard Operating Procedure (SOP). Follow these rules strictly:
(1) Use ONLY information present in the source notes. Never invent, assume, or infer facts, names, dates, owners, or steps that are not explicitly stated or clearly and unambiguously implied by the text.
(2) If a standard SOP field (Purpose, Scope, Owner, Effective Date, Version, Process Steps, Roles & Responsibilities, Review Date) cannot be filled from the notes, leave it explicitly marked as '[MISSING — not found in source notes]' rather than guessing.
(3) For every section you generate, include the exact short excerpt(s) from the source notes that justify that section's content, so the user can verify it (this is the 'evidence').
(4) Write in plain, simple language. No jargon, no corporate filler phrases, no invented policy language.
(5) Output valid structured JSON with fields: sections (each with: field_name, content, evidence_quotes[], confidence: 'high'|'medium'|'low'), missing_fields[].`;
	// Append Tone toggle
	if (req.tone === "formal") {
		systemInstruction += "\nWrite section content in formal, audit-ready language.";
	} else {
		systemInstruction += "\nWrite section content in plain, everyday language.";
	}
	// Template structure instructions
	let structurePrompt = "";
	if (req.customTemplateText && req.customTemplateText.trim()) {
		structurePrompt = `Target SOP Structure requested by user:\n${req.customTemplateText.trim()}`;
	} else if (req.templateType === "iso") {
		structurePrompt = `Target SOP Structure: ISO-9001 Auditable Clauses:
- Document Title
- 1. Purpose & Scope
- 2. Roles & Responsibilities
- 3. Step-by-Step Procedure (with numbered chronological steps and SLAs)
- 4. Document Governance & Control Metadata (Version, Owner, Effective Date, Review Cycle, Classification)`;
	} else if (req.templateType === "audit") {
		structurePrompt = `Target SOP Structure: Compliance & Audit Standard:
- Document Title & Policy Purpose
- 1. Scope & Regulatory Jurisdictions
- 2. Risk Flags & Segregation of Duties
- 3. Mandatory Operating Procedure
- 4. Control Sign-Offs & Audit Evidence Trail
- 5. Document Governance (Version, Owner, Effective Date, Review Cycle)`;
	} else {
		// Default simple internal
		structurePrompt = `Target SOP Structure: Standard Internal SOP:
- Title
- Purpose & Scope
- Roles & Responsibilities
- Step-by-Step Procedure
- Document Governance & Metadata (Version, Owner, Effective Date, Review Cycle, Classification)`;
	}
	const userPrompt = `${structurePrompt}

Source Operational Notes / Transcript:
"""
${notes}
"""

Ensure you return valid JSON strictly adhering to the schema. Include exact verbatim excerpts in evidence_quotes for each section. If Process Owner, Effective Date, or Process Steps are not stated in the source notes, explicitly list them in missing_fields array.`;
	const modelCandidates = ["gemini-3.8-flash", "gemini-3.1-flash-lite"];
	let rawText = undefined;
	let lastError = null;
	for (const model of modelCandidates) {
		for (let attempt = 0; attempt < 2; attempt++) {
			try {
				const response = await ai.models.generateContent({
					model,
					contents: userPrompt,
					config: {
						systemInstruction,
						responseMimeType: "application/json",
						responseSchema: {
							type: Type.OBJECT,
							properties: {
								title: {
									type: Type.STRING,
									description: "SOP Document Title"
								},
								code: {
									type: Type.STRING,
									description: "Document code or ID (e.g. SOP-8492)"
								},
								department: {
									type: Type.STRING,
									description: "Department or Team"
								},
								version: {
									type: Type.STRING,
									description: "SOP Version (e.g. 1.0 (Draft))"
								},
								owner: {
									type: Type.STRING,
									description: "Process Owner or [MISSING — not found in source notes]"
								},
								effective_date: {
									type: Type.STRING,
									description: "Effective Date or [MISSING — not found in source notes]"
								},
								review_cycle: {
									type: Type.STRING,
									description: "Review cadence (e.g. Annual)"
								},
								compliance_standard: {
									type: Type.STRING,
									description: "Compliance or standard name"
								},
								classification: {
									type: Type.STRING,
									description: "Classification (e.g. Internal Confidential)"
								},
								sections: {
									type: Type.ARRAY,
									items: {
										type: Type.OBJECT,
										properties: {
											field_name: { type: Type.STRING },
											content: { type: Type.STRING },
											evidence_quotes: {
												type: Type.ARRAY,
												items: { type: Type.STRING }
											},
											confidence: {
												type: Type.STRING,
												description: "high, medium, or low"
											}
										},
										required: [
											"field_name",
											"content",
											"evidence_quotes",
											"confidence"
										]
									}
								},
								missing_fields: {
									type: Type.ARRAY,
									items: {
										type: Type.OBJECT,
										properties: {
											field_name: { type: Type.STRING },
											issue_description: { type: Type.STRING },
											quick_question: { type: Type.STRING }
										},
										required: ["field_name", "issue_description"]
									}
								}
							},
							required: [
								"title",
								"sections",
								"missing_fields"
							]
						}
					}
				});
				rawText = response.text;
				if (rawText) break;
			} catch (err) {
				lastError = err;
				console.warn(`Attempt ${attempt + 1} with ${model} encountered:`, err?.message || err);
				// Delay 1 second before retrying
				await new Promise((resolve) => setTimeout(resolve, 1e3));
			}
		}
		if (rawText) break;
	}
	try {
		if (!rawText) {
			return {
				success: false,
				error: lastError?.message || "The AI model returned an empty response. Please check your notes and retry.",
				error_type: "api_error"
			};
		}
		let parsed;
		try {
			parsed = JSON.parse(rawText);
		} catch (parseErr) {
			// Clean possible markdown code fences
			const cleaned = rawText.replace(/^```json\s*/i, "").replace(/```\s*$/, "").trim();
			parsed = JSON.parse(cleaned);
		}
		if (!parsed || !Array.isArray(parsed.sections) || parsed.sections.length === 0) {
			return {
				success: false,
				error: "Invalid JSON structure returned by model.",
				error_type: "parse_failed"
			};
		}
		// =========================================================================
		// GUARDRAIL ENFORCEMENT IN THE APP (NOT JUST THE PROMPT)
		// "After parsing the AI response, run a simple validation pass: if any core field
		// (Owner, Effective Date, Process Steps) is empty or marked missing, it MUST
		// appear in the Missing Information banner — never silently drop it."
		// =========================================================================
		const missingMap = new Map();
		// Seed from AI response
		if (Array.isArray(parsed.missing_fields)) {
			parsed.missing_fields.forEach((mf, idx) => {
				const name = mf.field_name || `Missing Field ${idx + 1}`;
				missingMap.set(name.toLowerCase(), {
					id: `mf-${idx + 1}`,
					field_name: name,
					issue_description: mf.issue_description || `${name} was not found in source notes`,
					quick_question: mf.quick_question || `What is the value for ${name}?`,
					resolved: false,
					field_type: name.toLowerCase().includes("date") ? "date" : "text"
				});
			});
		}
		// Check core field: Owner
		const ownerValue = (parsed.owner || "").trim();
		const isOwnerMissing = !ownerValue || ownerValue.includes("[MISSING") || ownerValue.toLowerCase().includes("not found") || ownerValue === "TBD" || ownerValue === "N/A";
		if (isOwnerMissing) {
			if (!missingMap.has("process owner") && !missingMap.has("owner")) {
				missingMap.set("process owner", {
					id: `mf-owner-${Date.now()}`,
					field_name: "Process Owner",
					issue_description: "Process Owner not specified in notes",
					quick_question: "Who is the designated Process Owner for this procedure?",
					resolved: false,
					field_type: "text"
				});
			}
		}
		// Check core field: Effective Date
		const effectiveDateValue = (parsed.effective_date || "").trim();
		const isDateMissing = !effectiveDateValue || effectiveDateValue.includes("[MISSING") || effectiveDateValue.toLowerCase().includes("not found") || effectiveDateValue === "TBD" || effectiveDateValue === "N/A";
		if (isDateMissing) {
			if (!missingMap.has("effective date")) {
				missingMap.set("effective date", {
					id: `mf-date-${Date.now()}`,
					field_name: "Effective Date",
					issue_description: "Effective Date missing from source notes",
					quick_question: "When should this SOP become formally effective?",
					resolved: false,
					field_type: "date"
				});
			}
		}
		// Check core field: Process Steps
		const stepSection = parsed.sections.find((s) => s.field_name?.toLowerCase().includes("step") || s.field_name?.toLowerCase().includes("procedure") || s.field_name?.toLowerCase().includes("workflow"));
		if (!stepSection || !stepSection.content || stepSection.content.includes("[MISSING")) {
			if (!missingMap.has("process steps")) {
				missingMap.set("process steps", {
					id: `mf-steps-${Date.now()}`,
					field_name: "Process Steps",
					issue_description: "Sequential process steps could not be fully identified in notes",
					quick_question: "Can you describe the primary 2-3 steps in this procedure?",
					resolved: false,
					field_type: "text"
				});
			}
		}
		const missingFieldsList = Array.from(missingMap.values());
		// Format sections
		const formattedSections = parsed.sections.map((sec, idx) => {
			const conf = (sec.confidence || "medium").toLowerCase();
			const validConfidence = conf === "high" || conf === "medium" || conf === "low" ? conf : "medium";
			// Parse sub-steps if this is a procedure section
			let subSteps = undefined;
			if (sec.field_name?.toLowerCase().includes("step") || sec.field_name?.toLowerCase().includes("procedure")) {
				subSteps = parseSubStepsFromContent(sec.content, sec.evidence_quotes);
			}
			return {
				id: `sec-${idx + 1}`,
				field_name: sec.field_name || `Section ${idx + 1}`,
				content: sec.content || "",
				evidence_quotes: Array.isArray(sec.evidence_quotes) ? sec.evidence_quotes : [],
				confidence: validConfidence,
				user_edited: false,
				original_ai_content: sec.content || "",
				sub_steps: subSteps
			};
		});
		const totalCitations = formattedSections.reduce((acc, s) => acc + s.evidence_quotes.length, 0);
		const document = {
			id: `sop-${Date.now()}`,
			code: parsed.code || "SOP-8492",
			title: parsed.title || "Standard Operating Procedure",
			department: parsed.department || "Operations & Human Resources",
			version: parsed.version || "1.0 (Draft)",
			review_cycle: parsed.review_cycle || "Annual",
			compliance_standard: parsed.compliance_standard || "ISO 9001 / SOC 2 Type II",
			classification: parsed.classification || "Internal Confidential",
			owner: isOwnerMissing ? "" : parsed.owner,
			effective_date: isDateMissing ? "" : parsed.effective_date,
			status: "DRAFT",
			sections: formattedSections,
			missing_fields: missingFieldsList,
			source_notes: notes,
			tone: req.tone,
			template_type: req.templateType,
			created_at: new Date().toISOString(),
			stats: {
				wordCount,
				readTimeMin: Math.max(1, Math.ceil(wordCount / 200)),
				citationsCount: totalCitations
			}
		};
		return {
			success: true,
			document
		};
	} catch (err) {
		console.error("Error calling Gemini API:", err);
		return {
			success: false,
			error: err?.message || "Failed to generate SOP from notes. Please check the input and try again.",
			error_type: "api_error"
		};
	}
}
function parseSubStepsFromContent(content, evidenceQuotes = []) {
	const lines = content.split("\n").map((l) => l.trim()).filter(Boolean);
	const steps = [];
	let currentStep = null;
	let counter = 1;
	for (const line of lines) {
		const stepMatch = line.match(/^(?:Step\s*)?(\d+)[:.)\-]\s*(.*)/i);
		if (stepMatch) {
			if (currentStep) {
				steps.push(currentStep);
			}
			const rawTitle = stepMatch[2].trim();
			let sla = undefined;
			const slaMatch = rawTitle.match(/(?:SLA|within|day|hours?):\s*([a-zA-Z0-9\s+-]+)/i);
			if (slaMatch) {
				sla = slaMatch[1].trim();
			}
			currentStep = {
				step_number: parseInt(stepMatch[1], 10) || counter++,
				title: rawTitle.replace(/\s*\(?SLA:.*?\)?/i, ""),
				description: "",
				sla
			};
		} else if (currentStep) {
			currentStep.description += (currentStep.description ? " " : "") + line;
		}
	}
	if (currentStep) {
		steps.push(currentStep);
	}
	return steps.length > 0 ? steps : undefined;
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFlBQVk7QUFHbEMsT0FBTyxlQUFlLHVCQUNwQixLQUNBLFFBQ2dJO0NBQ2hJLE1BQU0sUUFBUSxJQUFJLE9BQU8sS0FBSyxLQUFLO0NBQ25DLE1BQU0sWUFBWSxNQUFNLE1BQU0sS0FBSyxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQzs7Q0FHckQsSUFBSSxZQUFZLElBQUk7RUFDbEIsT0FBTztHQUNMLFNBQVM7R0FDVCxPQUFPO0dBQ1AsWUFBWTtFQUNkO0NBQ0Y7O0NBR0EsTUFBTSxZQUFZLFVBQVUsUUFBUSxJQUFJO0NBQ3hDLElBQUksQ0FBQyxXQUFXO0VBQ2QsT0FBTztHQUNMLFNBQVM7R0FDVCxPQUFPO0dBQ1AsWUFBWTtFQUNkO0NBQ0Y7Q0FFQSxNQUFNLEtBQUssSUFBSSxZQUFZO0VBQ3pCLFFBQVE7RUFDUixhQUFhLEVBQ1gsU0FBUyxFQUNQLGNBQWMsaUJBQ2hCLEVBQ0Y7Q0FDRixDQUFDOztDQUdELElBQUksb0JBQW9COzs7Ozs7O0NBUXhCLElBQUksSUFBSSxTQUFTLFVBQVU7RUFDekIscUJBQXFCO0NBQ3ZCLE9BQU87RUFDTCxxQkFBcUI7Q0FDdkI7O0NBR0EsSUFBSSxrQkFBa0I7Q0FDdEIsSUFBSSxJQUFJLHNCQUFzQixJQUFJLG1CQUFtQixLQUFLLEdBQUc7RUFDM0Qsa0JBQWtCLDRDQUE0QyxJQUFJLG1CQUFtQixLQUFLO0NBQzVGLE9BQU8sSUFBSSxJQUFJLGlCQUFpQixPQUFPO0VBQ3JDLGtCQUFrQjs7Ozs7O0NBTXBCLE9BQU8sSUFBSSxJQUFJLGlCQUFpQixTQUFTO0VBQ3ZDLGtCQUFrQjs7Ozs7OztDQU9wQixPQUFPOztFQUVMLGtCQUFrQjs7Ozs7O0NBTXBCO0NBRUEsTUFBTSxhQUFhLEdBQUcsZ0JBQWdCOzs7O0VBSXRDLE1BQU07Ozs7Q0FLTixNQUFNLGtCQUFrQixDQUFDLG9CQUFvQix1QkFBdUI7Q0FDcEUsSUFBSSxVQUE4QjtDQUNsQyxJQUFJLFlBQWlCO0NBRXJCLEtBQUssTUFBTSxTQUFTLGlCQUFpQjtFQUNuQyxLQUFLLElBQUksVUFBVSxHQUFHLFVBQVUsR0FBRyxXQUFXO0dBQzVDLElBQUk7SUFDRixNQUFNLFdBQVcsTUFBTSxHQUFHLE9BQU8sZ0JBQWdCO0tBQy9DO0tBQ0EsVUFBVTtLQUNWLFFBQVE7TUFDTjtNQUNBLGtCQUFrQjtNQUNsQixnQkFBZ0I7T0FDZCxNQUFNLEtBQUs7T0FDWCxZQUFZO1FBQ1YsT0FBTztTQUFFLE1BQU0sS0FBSztTQUFRLGFBQWE7UUFBcUI7UUFDOUQsTUFBTTtTQUFFLE1BQU0sS0FBSztTQUFRLGFBQWE7UUFBc0M7UUFDOUUsWUFBWTtTQUFFLE1BQU0sS0FBSztTQUFRLGFBQWE7UUFBcUI7UUFDbkUsU0FBUztTQUFFLE1BQU0sS0FBSztTQUFRLGFBQWE7UUFBaUM7UUFDNUUsT0FBTztTQUFFLE1BQU0sS0FBSztTQUFRLGFBQWE7UUFBeUQ7UUFDbEcsZ0JBQWdCO1NBQUUsTUFBTSxLQUFLO1NBQVEsYUFBYTtRQUEwRDtRQUM1RyxjQUFjO1NBQUUsTUFBTSxLQUFLO1NBQVEsYUFBYTtRQUErQjtRQUMvRSxxQkFBcUI7U0FBRSxNQUFNLEtBQUs7U0FBUSxhQUFhO1FBQThCO1FBQ3JGLGdCQUFnQjtTQUFFLE1BQU0sS0FBSztTQUFRLGFBQWE7UUFBOEM7UUFDaEcsVUFBVTtTQUNSLE1BQU0sS0FBSztTQUNYLE9BQU87VUFDTCxNQUFNLEtBQUs7VUFDWCxZQUFZO1dBQ1YsWUFBWSxFQUFFLE1BQU0sS0FBSyxPQUFPO1dBQ2hDLFNBQVMsRUFBRSxNQUFNLEtBQUssT0FBTztXQUM3QixpQkFBaUI7WUFDZixNQUFNLEtBQUs7WUFDWCxPQUFPLEVBQUUsTUFBTSxLQUFLLE9BQU87V0FDN0I7V0FDQSxZQUFZO1lBQ1YsTUFBTSxLQUFLO1lBQ1gsYUFBYTtXQUNmO1VBQ0Y7VUFDQSxVQUFVO1dBQUM7V0FBYztXQUFXO1dBQW1CO1VBQVk7U0FDckU7UUFDRjtRQUNBLGdCQUFnQjtTQUNkLE1BQU0sS0FBSztTQUNYLE9BQU87VUFDTCxNQUFNLEtBQUs7VUFDWCxZQUFZO1dBQ1YsWUFBWSxFQUFFLE1BQU0sS0FBSyxPQUFPO1dBQ2hDLG1CQUFtQixFQUFFLE1BQU0sS0FBSyxPQUFPO1dBQ3ZDLGdCQUFnQixFQUFFLE1BQU0sS0FBSyxPQUFPO1VBQ3RDO1VBQ0EsVUFBVSxDQUFDLGNBQWMsbUJBQW1CO1NBQzlDO1FBQ0Y7T0FDRjtPQUNBLFVBQVU7UUFBQztRQUFTO1FBQVk7T0FBZ0I7TUFDbEQ7S0FDRjtJQUNGLENBQUM7SUFFRCxVQUFVLFNBQVM7SUFDbkIsSUFBSSxTQUFTO0dBQ2YsU0FBUyxLQUFVO0lBQ2pCLFlBQVk7SUFDWixRQUFRLEtBQUssV0FBVyxVQUFVLEVBQUUsUUFBUSxNQUFNLGdCQUFnQixLQUFLLFdBQVcsR0FBRzs7SUFFckYsTUFBTSxJQUFJLFNBQVMsWUFBWSxXQUFXLFNBQVMsR0FBSSxDQUFDO0dBQzFEO0VBQ0Y7RUFDQSxJQUFJLFNBQVM7Q0FDZjtDQUVBLElBQUk7RUFDRixJQUFJLENBQUMsU0FBUztHQUNaLE9BQU87SUFDTCxTQUFTO0lBQ1QsT0FBTyxXQUFXLFdBQVc7SUFDN0IsWUFBWTtHQUNkO0VBQ0Y7RUFFQSxJQUFJO0VBQ0osSUFBSTtHQUNGLFNBQVMsS0FBSyxNQUFNLE9BQU87RUFDN0IsU0FBUyxVQUFVOztHQUVqQixNQUFNLFVBQVUsUUFBUSxRQUFRLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxRQUFRLFdBQVcsRUFBRSxDQUFDLENBQUMsS0FBSztHQUNoRixTQUFTLEtBQUssTUFBTSxPQUFPO0VBQzdCO0VBRUEsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLFFBQVEsT0FBTyxRQUFRLEtBQUssT0FBTyxTQUFTLFdBQVcsR0FBRztHQUM5RSxPQUFPO0lBQ0wsU0FBUztJQUNULE9BQU87SUFDUCxZQUFZO0dBQ2Q7RUFDRjs7Ozs7OztFQVNBLE1BQU0sYUFBYSxJQUFJLElBQThCOztFQUdyRCxJQUFJLE1BQU0sUUFBUSxPQUFPLGNBQWMsR0FBRztHQUN4QyxPQUFPLGVBQWUsU0FBUyxJQUFTLFFBQWdCO0lBQ3RELE1BQU0sT0FBTyxHQUFHLGNBQWMsaUJBQWlCLE1BQU07SUFDckQsV0FBVyxJQUFJLEtBQUssWUFBWSxHQUFHO0tBQ2pDLElBQUksTUFBTSxNQUFNO0tBQ2hCLFlBQVk7S0FDWixtQkFBbUIsR0FBRyxxQkFBcUIsR0FBRyxLQUFLO0tBQ25ELGdCQUFnQixHQUFHLGtCQUFrQix5QkFBeUIsS0FBSztLQUNuRSxVQUFVO0tBQ1YsWUFBWSxLQUFLLFlBQVksQ0FBQyxDQUFDLFNBQVMsTUFBTSxJQUFJLFNBQVM7SUFDN0QsQ0FBQztHQUNILENBQUM7RUFDSDs7RUFHQSxNQUFNLGNBQWMsT0FBTyxTQUFTLEdBQUUsQ0FBRSxLQUFLO0VBQzdDLE1BQU0saUJBQ0osQ0FBQyxjQUNELFdBQVcsU0FBUyxVQUFVLEtBQzlCLFdBQVcsWUFBWSxDQUFDLENBQUMsU0FBUyxXQUFXLEtBQzdDLGVBQWUsU0FDZixlQUFlO0VBQ2pCLElBQUksZ0JBQWdCO0dBQ2xCLElBQUksQ0FBQyxXQUFXLElBQUksZUFBZSxLQUFLLENBQUMsV0FBVyxJQUFJLE9BQU8sR0FBRztJQUNoRSxXQUFXLElBQUksaUJBQWlCO0tBQzlCLElBQUksWUFBWSxLQUFLLElBQUk7S0FDekIsWUFBWTtLQUNaLG1CQUFtQjtLQUNuQixnQkFBZ0I7S0FDaEIsVUFBVTtLQUNWLFlBQVk7SUFDZCxDQUFDO0dBQ0g7RUFDRjs7RUFHQSxNQUFNLHNCQUFzQixPQUFPLGtCQUFrQixHQUFFLENBQUUsS0FBSztFQUM5RCxNQUFNLGdCQUNKLENBQUMsc0JBQ0QsbUJBQW1CLFNBQVMsVUFBVSxLQUN0QyxtQkFBbUIsWUFBWSxDQUFDLENBQUMsU0FBUyxXQUFXLEtBQ3JELHVCQUF1QixTQUN2Qix1QkFBdUI7RUFDekIsSUFBSSxlQUFlO0dBQ2pCLElBQUksQ0FBQyxXQUFXLElBQUksZ0JBQWdCLEdBQUc7SUFDckMsV0FBVyxJQUFJLGtCQUFrQjtLQUMvQixJQUFJLFdBQVcsS0FBSyxJQUFJO0tBQ3hCLFlBQVk7S0FDWixtQkFBbUI7S0FDbkIsZ0JBQWdCO0tBQ2hCLFVBQVU7S0FDVixZQUFZO0lBQ2QsQ0FBQztHQUNIO0VBQ0Y7O0VBR0EsTUFBTSxjQUFjLE9BQU8sU0FBUyxNQUFNLE1BQ3hDLEVBQUUsWUFBWSxZQUFZLENBQUMsQ0FBQyxTQUFTLE1BQU0sS0FDM0MsRUFBRSxZQUFZLFlBQVksQ0FBQyxDQUFDLFNBQVMsV0FBVyxLQUNoRCxFQUFFLFlBQVksWUFBWSxDQUFDLENBQUMsU0FBUyxVQUFVLENBQ2pEO0VBQ0EsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLFdBQVcsWUFBWSxRQUFRLFNBQVMsVUFBVSxHQUFHO0dBQ3BGLElBQUksQ0FBQyxXQUFXLElBQUksZUFBZSxHQUFHO0lBQ3BDLFdBQVcsSUFBSSxpQkFBaUI7S0FDOUIsSUFBSSxZQUFZLEtBQUssSUFBSTtLQUN6QixZQUFZO0tBQ1osbUJBQW1CO0tBQ25CLGdCQUFnQjtLQUNoQixVQUFVO0tBQ1YsWUFBWTtJQUNkLENBQUM7R0FDSDtFQUNGO0VBRUEsTUFBTSxvQkFBd0MsTUFBTSxLQUFLLFdBQVcsT0FBTyxDQUFDOztFQUc1RSxNQUFNLG9CQUFrQyxPQUFPLFNBQVMsS0FBSyxLQUFVLFFBQWdCO0dBQ3JGLE1BQU0sUUFBUSxJQUFJLGNBQWMsU0FBUSxDQUFFLFlBQVk7R0FDdEQsTUFBTSxrQkFBa0IsU0FBUyxVQUFVLFNBQVMsWUFBWSxTQUFTLFFBQVEsT0FBTzs7R0FHeEYsSUFBSSxXQUE4QjtHQUNsQyxJQUFJLElBQUksWUFBWSxZQUFZLENBQUMsQ0FBQyxTQUFTLE1BQU0sS0FBSyxJQUFJLFlBQVksWUFBWSxDQUFDLENBQUMsU0FBUyxXQUFXLEdBQUc7SUFDekcsV0FBVyx5QkFBeUIsSUFBSSxTQUFTLElBQUksZUFBZTtHQUN0RTtHQUVBLE9BQU87SUFDTCxJQUFJLE9BQU8sTUFBTTtJQUNqQixZQUFZLElBQUksY0FBYyxXQUFXLE1BQU07SUFDL0MsU0FBUyxJQUFJLFdBQVc7SUFDeEIsaUJBQWlCLE1BQU0sUUFBUSxJQUFJLGVBQWUsSUFBSSxJQUFJLGtCQUFrQixDQUFDO0lBQzdFLFlBQVk7SUFDWixhQUFhO0lBQ2IscUJBQXFCLElBQUksV0FBVztJQUNwQyxXQUFXO0dBQ2I7RUFDRixDQUFDO0VBRUQsTUFBTSxpQkFBaUIsa0JBQWtCLFFBQVEsS0FBSyxNQUFNLE1BQU0sRUFBRSxnQkFBZ0IsUUFBUSxDQUFDO0VBRTdGLE1BQU0sV0FBd0I7R0FDNUIsSUFBSSxPQUFPLEtBQUssSUFBSTtHQUNwQixNQUFNLE9BQU8sUUFBUTtHQUNyQixPQUFPLE9BQU8sU0FBUztHQUN2QixZQUFZLE9BQU8sY0FBYztHQUNqQyxTQUFTLE9BQU8sV0FBVztHQUMzQixjQUFjLE9BQU8sZ0JBQWdCO0dBQ3JDLHFCQUFxQixPQUFPLHVCQUF1QjtHQUNuRCxnQkFBZ0IsT0FBTyxrQkFBa0I7R0FDekMsT0FBTyxpQkFBaUIsS0FBSyxPQUFPO0dBQ3BDLGdCQUFnQixnQkFBZ0IsS0FBSyxPQUFPO0dBQzVDLFFBQVE7R0FDUixVQUFVO0dBQ1YsZ0JBQWdCO0dBQ2hCLGNBQWM7R0FDZCxNQUFNLElBQUk7R0FDVixlQUFlLElBQUk7R0FDbkIsWUFBWSxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDbkMsT0FBTztJQUNNO0lBQ1gsYUFBYSxLQUFLLElBQUksR0FBRyxLQUFLLEtBQUssWUFBWSxHQUFHLENBQUM7SUFDbkQsZ0JBQWdCO0dBQ2xCO0VBQ0Y7RUFFQSxPQUFPO0dBQ0wsU0FBUztHQUNUO0VBQ0Y7Q0FDRixTQUFTLEtBQVU7RUFDakIsUUFBUSxNQUFNLDZCQUE2QixHQUFHO0VBQzlDLE9BQU87R0FDTCxTQUFTO0dBQ1QsT0FBTyxLQUFLLFdBQVc7R0FDdkIsWUFBWTtFQUNkO0NBQ0Y7QUFDRjtBQUVBLFNBQVMseUJBQXlCLFNBQWlCLGlCQUEyQixDQUFDLEdBQW9IO0NBQ2pNLE1BQU0sUUFBUSxRQUFRLE1BQU0sSUFBSSxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxPQUFPLE9BQU87Q0FDckUsTUFBTSxRQUE2RyxDQUFDO0NBRXBILElBQUksY0FBbUg7Q0FDdkgsSUFBSSxVQUFVO0NBRWQsS0FBSyxNQUFNLFFBQVEsT0FBTztFQUN4QixNQUFNLFlBQVksS0FBSyxNQUFNLG1DQUFtQztFQUNoRSxJQUFJLFdBQVc7R0FDYixJQUFJLGFBQWE7SUFDZixNQUFNLEtBQUssV0FBVztHQUN4QjtHQUNBLE1BQU0sV0FBVyxVQUFVLEVBQUUsQ0FBQyxLQUFLO0dBQ25DLElBQUksTUFBTTtHQUNWLE1BQU0sV0FBVyxTQUFTLE1BQU0sa0RBQWtEO0dBQ2xGLElBQUksVUFBVTtJQUNaLE1BQU0sU0FBUyxFQUFFLENBQUMsS0FBSztHQUN6QjtHQUVBLGNBQWM7SUFDWixhQUFhLFNBQVMsVUFBVSxJQUFJLEVBQUUsS0FBSztJQUMzQyxPQUFPLFNBQVMsUUFBUSxxQkFBcUIsRUFBRTtJQUMvQyxhQUFhO0lBQ2I7R0FDRjtFQUNGLE9BQU8sSUFBSSxhQUFhO0dBQ3RCLFlBQVksZ0JBQWdCLFlBQVksY0FBYyxNQUFNLE1BQU07RUFDcEU7Q0FDRjtDQUVBLElBQUksYUFBYTtFQUNmLE1BQU0sS0FBSyxXQUFXO0NBQ3hCO0NBRUEsT0FBTyxNQUFNLFNBQVMsSUFBSSxRQUFRO0FBQ3BDIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImdlbWluaVNlcnZpY2UudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgR29vZ2xlR2VuQUksIFR5cGUgfSBmcm9tICdAZ29vZ2xlL2dlbmFpJztcbmltcG9ydCB7IEdlbmVyYXRlU09QUmVxdWVzdCwgU09QRG9jdW1lbnQsIFNPUFNlY3Rpb24sIE1pc3NpbmdGaWVsZEl0ZW0gfSBmcm9tICcuLi9zcmMvdHlwZXMvc29wJztcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByb2Nlc3NOb3Rlc1dpdGhHZW1pbmkoXG4gIHJlcTogR2VuZXJhdGVTT1BSZXF1ZXN0LFxuICBhcGlLZXk6IHN0cmluZyB8IHVuZGVmaW5lZFxuKTogUHJvbWlzZTx7IHN1Y2Nlc3M6IGJvb2xlYW47IGRvY3VtZW50PzogU09QRG9jdW1lbnQ7IGVycm9yPzogc3RyaW5nOyBlcnJvcl90eXBlPzogJ3Rvb19icmllZicgfCAncGFyc2VfZmFpbGVkJyB8ICdhcGlfZXJyb3InIH0+IHtcbiAgY29uc3Qgbm90ZXMgPSByZXEubm90ZXM/LnRyaW0oKSB8fCAnJztcbiAgY29uc3Qgd29yZENvdW50ID0gbm90ZXMuc3BsaXQoL1xccysvKS5maWx0ZXIoQm9vbGVhbikubGVuZ3RoO1xuXG4gIC8vIEd1YXJkcmFpbCAxOiBJbnB1dCBicmV2aXR5IGNoZWNrICg8IDE1IHdvcmRzIG9yIGxhY2tpbmcgYWN0aW9uYWJsZSBjb250ZW50KVxuICBpZiAod29yZENvdW50IDwgMTUpIHtcbiAgICByZXR1cm4ge1xuICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICBlcnJvcjogJ1lvdXIgbm90ZXMgYXBwZWFyIHRvIGJlIHRvbyBicmllZiAodW5kZXIgMTUgd29yZHMpIG9yIG1pc3NpbmcgY2hyb25vbG9naWNhbCBzdGVwcy4gQW4gU09QIG5lZWRzIGF0IGxlYXN0IGEgZmV3IHNlcXVlbnRpYWwgYWN0aW9ucyBvciByZXNwb25zaWJpbGl0aWVzIHRvIGJ1aWxkIGEgc3RydWN0dXJlZCBwcm9jZWR1cmUuJyxcbiAgICAgIGVycm9yX3R5cGU6ICd0b29fYnJpZWYnLFxuICAgIH07XG4gIH1cblxuICAvLyBHdWFyZHJhaWwgMjogQ2hlY2sgZm9yIEFQSSBLZXlcbiAgY29uc3QgYWN0aXZlS2V5ID0gYXBpS2V5IHx8IHByb2Nlc3MuZW52LkdFTUlOSV9BUElfS0VZO1xuICBpZiAoIWFjdGl2ZUtleSkge1xuICAgIHJldHVybiB7XG4gICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgIGVycm9yOiAnTWlzc2luZyBHRU1JTklfQVBJX0tFWSBlbnZpcm9ubWVudCB2YXJpYWJsZS4gUGxlYXNlIGNvbmZpZ3VyZSB5b3VyIEFQSSBrZXkgaW4gZW52aXJvbm1lbnQgdmFyaWFibGVzIG9yIE5ldGxpZnkgc2V0dGluZ3MuJyxcbiAgICAgIGVycm9yX3R5cGU6ICdhcGlfZXJyb3InLFxuICAgIH07XG4gIH1cblxuICBjb25zdCBhaSA9IG5ldyBHb29nbGVHZW5BSSh7XG4gICAgYXBpS2V5OiBhY3RpdmVLZXksXG4gICAgaHR0cE9wdGlvbnM6IHtcbiAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgJ1VzZXItQWdlbnQnOiAnYWlzdHVkaW8tYnVpbGQnLFxuICAgICAgfSxcbiAgICB9LFxuICB9KTtcblxuICAvLyBCYXNlIHN5c3RlbSBpbnN0cnVjdGlvbiAoRXhhY3QgYXMgcmVxdWVzdGVkKVxuICBsZXQgc3lzdGVtSW5zdHJ1Y3Rpb24gPSBgWW91IGNvbnZlcnQgbWVzc3kgb3BlcmF0aW9uYWwgbm90ZXMgaW50byBhIGZvcm1hbCBTdGFuZGFyZCBPcGVyYXRpbmcgUHJvY2VkdXJlIChTT1ApLiBGb2xsb3cgdGhlc2UgcnVsZXMgc3RyaWN0bHk6XG4oMSkgVXNlIE9OTFkgaW5mb3JtYXRpb24gcHJlc2VudCBpbiB0aGUgc291cmNlIG5vdGVzLiBOZXZlciBpbnZlbnQsIGFzc3VtZSwgb3IgaW5mZXIgZmFjdHMsIG5hbWVzLCBkYXRlcywgb3duZXJzLCBvciBzdGVwcyB0aGF0IGFyZSBub3QgZXhwbGljaXRseSBzdGF0ZWQgb3IgY2xlYXJseSBhbmQgdW5hbWJpZ3VvdXNseSBpbXBsaWVkIGJ5IHRoZSB0ZXh0LlxuKDIpIElmIGEgc3RhbmRhcmQgU09QIGZpZWxkIChQdXJwb3NlLCBTY29wZSwgT3duZXIsIEVmZmVjdGl2ZSBEYXRlLCBWZXJzaW9uLCBQcm9jZXNzIFN0ZXBzLCBSb2xlcyAmIFJlc3BvbnNpYmlsaXRpZXMsIFJldmlldyBEYXRlKSBjYW5ub3QgYmUgZmlsbGVkIGZyb20gdGhlIG5vdGVzLCBsZWF2ZSBpdCBleHBsaWNpdGx5IG1hcmtlZCBhcyAnW01JU1NJTkcg4oCUIG5vdCBmb3VuZCBpbiBzb3VyY2Ugbm90ZXNdJyByYXRoZXIgdGhhbiBndWVzc2luZy5cbigzKSBGb3IgZXZlcnkgc2VjdGlvbiB5b3UgZ2VuZXJhdGUsIGluY2x1ZGUgdGhlIGV4YWN0IHNob3J0IGV4Y2VycHQocykgZnJvbSB0aGUgc291cmNlIG5vdGVzIHRoYXQganVzdGlmeSB0aGF0IHNlY3Rpb24ncyBjb250ZW50LCBzbyB0aGUgdXNlciBjYW4gdmVyaWZ5IGl0ICh0aGlzIGlzIHRoZSAnZXZpZGVuY2UnKS5cbig0KSBXcml0ZSBpbiBwbGFpbiwgc2ltcGxlIGxhbmd1YWdlLiBObyBqYXJnb24sIG5vIGNvcnBvcmF0ZSBmaWxsZXIgcGhyYXNlcywgbm8gaW52ZW50ZWQgcG9saWN5IGxhbmd1YWdlLlxuKDUpIE91dHB1dCB2YWxpZCBzdHJ1Y3R1cmVkIEpTT04gd2l0aCBmaWVsZHM6IHNlY3Rpb25zIChlYWNoIHdpdGg6IGZpZWxkX25hbWUsIGNvbnRlbnQsIGV2aWRlbmNlX3F1b3Rlc1tdLCBjb25maWRlbmNlOiAnaGlnaCd8J21lZGl1bSd8J2xvdycpLCBtaXNzaW5nX2ZpZWxkc1tdLmA7XG5cbiAgLy8gQXBwZW5kIFRvbmUgdG9nZ2xlXG4gIGlmIChyZXEudG9uZSA9PT0gJ2Zvcm1hbCcpIHtcbiAgICBzeXN0ZW1JbnN0cnVjdGlvbiArPSAnXFxuV3JpdGUgc2VjdGlvbiBjb250ZW50IGluIGZvcm1hbCwgYXVkaXQtcmVhZHkgbGFuZ3VhZ2UuJztcbiAgfSBlbHNlIHtcbiAgICBzeXN0ZW1JbnN0cnVjdGlvbiArPSAnXFxuV3JpdGUgc2VjdGlvbiBjb250ZW50IGluIHBsYWluLCBldmVyeWRheSBsYW5ndWFnZS4nO1xuICB9XG5cbiAgLy8gVGVtcGxhdGUgc3RydWN0dXJlIGluc3RydWN0aW9uc1xuICBsZXQgc3RydWN0dXJlUHJvbXB0ID0gJyc7XG4gIGlmIChyZXEuY3VzdG9tVGVtcGxhdGVUZXh0ICYmIHJlcS5jdXN0b21UZW1wbGF0ZVRleHQudHJpbSgpKSB7XG4gICAgc3RydWN0dXJlUHJvbXB0ID0gYFRhcmdldCBTT1AgU3RydWN0dXJlIHJlcXVlc3RlZCBieSB1c2VyOlxcbiR7cmVxLmN1c3RvbVRlbXBsYXRlVGV4dC50cmltKCl9YDtcbiAgfSBlbHNlIGlmIChyZXEudGVtcGxhdGVUeXBlID09PSAnaXNvJykge1xuICAgIHN0cnVjdHVyZVByb21wdCA9IGBUYXJnZXQgU09QIFN0cnVjdHVyZTogSVNPLTkwMDEgQXVkaXRhYmxlIENsYXVzZXM6XG4tIERvY3VtZW50IFRpdGxlXG4tIDEuIFB1cnBvc2UgJiBTY29wZVxuLSAyLiBSb2xlcyAmIFJlc3BvbnNpYmlsaXRpZXNcbi0gMy4gU3RlcC1ieS1TdGVwIFByb2NlZHVyZSAod2l0aCBudW1iZXJlZCBjaHJvbm9sb2dpY2FsIHN0ZXBzIGFuZCBTTEFzKVxuLSA0LiBEb2N1bWVudCBHb3Zlcm5hbmNlICYgQ29udHJvbCBNZXRhZGF0YSAoVmVyc2lvbiwgT3duZXIsIEVmZmVjdGl2ZSBEYXRlLCBSZXZpZXcgQ3ljbGUsIENsYXNzaWZpY2F0aW9uKWA7XG4gIH0gZWxzZSBpZiAocmVxLnRlbXBsYXRlVHlwZSA9PT0gJ2F1ZGl0Jykge1xuICAgIHN0cnVjdHVyZVByb21wdCA9IGBUYXJnZXQgU09QIFN0cnVjdHVyZTogQ29tcGxpYW5jZSAmIEF1ZGl0IFN0YW5kYXJkOlxuLSBEb2N1bWVudCBUaXRsZSAmIFBvbGljeSBQdXJwb3NlXG4tIDEuIFNjb3BlICYgUmVndWxhdG9yeSBKdXJpc2RpY3Rpb25zXG4tIDIuIFJpc2sgRmxhZ3MgJiBTZWdyZWdhdGlvbiBvZiBEdXRpZXNcbi0gMy4gTWFuZGF0b3J5IE9wZXJhdGluZyBQcm9jZWR1cmVcbi0gNC4gQ29udHJvbCBTaWduLU9mZnMgJiBBdWRpdCBFdmlkZW5jZSBUcmFpbFxuLSA1LiBEb2N1bWVudCBHb3Zlcm5hbmNlIChWZXJzaW9uLCBPd25lciwgRWZmZWN0aXZlIERhdGUsIFJldmlldyBDeWNsZSlgO1xuICB9IGVsc2Uge1xuICAgIC8vIERlZmF1bHQgc2ltcGxlIGludGVybmFsXG4gICAgc3RydWN0dXJlUHJvbXB0ID0gYFRhcmdldCBTT1AgU3RydWN0dXJlOiBTdGFuZGFyZCBJbnRlcm5hbCBTT1A6XG4tIFRpdGxlXG4tIFB1cnBvc2UgJiBTY29wZVxuLSBSb2xlcyAmIFJlc3BvbnNpYmlsaXRpZXNcbi0gU3RlcC1ieS1TdGVwIFByb2NlZHVyZVxuLSBEb2N1bWVudCBHb3Zlcm5hbmNlICYgTWV0YWRhdGEgKFZlcnNpb24sIE93bmVyLCBFZmZlY3RpdmUgRGF0ZSwgUmV2aWV3IEN5Y2xlLCBDbGFzc2lmaWNhdGlvbilgO1xuICB9XG5cbiAgY29uc3QgdXNlclByb21wdCA9IGAke3N0cnVjdHVyZVByb21wdH1cblxuU291cmNlIE9wZXJhdGlvbmFsIE5vdGVzIC8gVHJhbnNjcmlwdDpcblwiXCJcIlxuJHtub3Rlc31cblwiXCJcIlxuXG5FbnN1cmUgeW91IHJldHVybiB2YWxpZCBKU09OIHN0cmljdGx5IGFkaGVyaW5nIHRvIHRoZSBzY2hlbWEuIEluY2x1ZGUgZXhhY3QgdmVyYmF0aW0gZXhjZXJwdHMgaW4gZXZpZGVuY2VfcXVvdGVzIGZvciBlYWNoIHNlY3Rpb24uIElmIFByb2Nlc3MgT3duZXIsIEVmZmVjdGl2ZSBEYXRlLCBvciBQcm9jZXNzIFN0ZXBzIGFyZSBub3Qgc3RhdGVkIGluIHRoZSBzb3VyY2Ugbm90ZXMsIGV4cGxpY2l0bHkgbGlzdCB0aGVtIGluIG1pc3NpbmdfZmllbGRzIGFycmF5LmA7XG5cbiAgY29uc3QgbW9kZWxDYW5kaWRhdGVzID0gWydnZW1pbmktMy44LWZsYXNoJywgJ2dlbWluaS0zLjEtZmxhc2gtbGl0ZSddO1xuICBsZXQgcmF3VGV4dDogc3RyaW5nIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuICBsZXQgbGFzdEVycm9yOiBhbnkgPSBudWxsO1xuXG4gIGZvciAoY29uc3QgbW9kZWwgb2YgbW9kZWxDYW5kaWRhdGVzKSB7XG4gICAgZm9yIChsZXQgYXR0ZW1wdCA9IDA7IGF0dGVtcHQgPCAyOyBhdHRlbXB0KyspIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgYWkubW9kZWxzLmdlbmVyYXRlQ29udGVudCh7XG4gICAgICAgICAgbW9kZWwsXG4gICAgICAgICAgY29udGVudHM6IHVzZXJQcm9tcHQsXG4gICAgICAgICAgY29uZmlnOiB7XG4gICAgICAgICAgICBzeXN0ZW1JbnN0cnVjdGlvbixcbiAgICAgICAgICAgIHJlc3BvbnNlTWltZVR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgICAgIHJlc3BvbnNlU2NoZW1hOiB7XG4gICAgICAgICAgICAgIHR5cGU6IFR5cGUuT0JKRUNULFxuICAgICAgICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgICAgICAgdGl0bGU6IHsgdHlwZTogVHlwZS5TVFJJTkcsIGRlc2NyaXB0aW9uOiAnU09QIERvY3VtZW50IFRpdGxlJyB9LFxuICAgICAgICAgICAgICAgIGNvZGU6IHsgdHlwZTogVHlwZS5TVFJJTkcsIGRlc2NyaXB0aW9uOiAnRG9jdW1lbnQgY29kZSBvciBJRCAoZS5nLiBTT1AtODQ5MiknIH0sXG4gICAgICAgICAgICAgICAgZGVwYXJ0bWVudDogeyB0eXBlOiBUeXBlLlNUUklORywgZGVzY3JpcHRpb246ICdEZXBhcnRtZW50IG9yIFRlYW0nIH0sXG4gICAgICAgICAgICAgICAgdmVyc2lvbjogeyB0eXBlOiBUeXBlLlNUUklORywgZGVzY3JpcHRpb246ICdTT1AgVmVyc2lvbiAoZS5nLiAxLjAgKERyYWZ0KSknIH0sXG4gICAgICAgICAgICAgICAgb3duZXI6IHsgdHlwZTogVHlwZS5TVFJJTkcsIGRlc2NyaXB0aW9uOiAnUHJvY2VzcyBPd25lciBvciBbTUlTU0lORyDigJQgbm90IGZvdW5kIGluIHNvdXJjZSBub3Rlc10nIH0sXG4gICAgICAgICAgICAgICAgZWZmZWN0aXZlX2RhdGU6IHsgdHlwZTogVHlwZS5TVFJJTkcsIGRlc2NyaXB0aW9uOiAnRWZmZWN0aXZlIERhdGUgb3IgW01JU1NJTkcg4oCUIG5vdCBmb3VuZCBpbiBzb3VyY2Ugbm90ZXNdJyB9LFxuICAgICAgICAgICAgICAgIHJldmlld19jeWNsZTogeyB0eXBlOiBUeXBlLlNUUklORywgZGVzY3JpcHRpb246ICdSZXZpZXcgY2FkZW5jZSAoZS5nLiBBbm51YWwpJyB9LFxuICAgICAgICAgICAgICAgIGNvbXBsaWFuY2Vfc3RhbmRhcmQ6IHsgdHlwZTogVHlwZS5TVFJJTkcsIGRlc2NyaXB0aW9uOiAnQ29tcGxpYW5jZSBvciBzdGFuZGFyZCBuYW1lJyB9LFxuICAgICAgICAgICAgICAgIGNsYXNzaWZpY2F0aW9uOiB7IHR5cGU6IFR5cGUuU1RSSU5HLCBkZXNjcmlwdGlvbjogJ0NsYXNzaWZpY2F0aW9uIChlLmcuIEludGVybmFsIENvbmZpZGVudGlhbCknIH0sXG4gICAgICAgICAgICAgICAgc2VjdGlvbnM6IHtcbiAgICAgICAgICAgICAgICAgIHR5cGU6IFR5cGUuQVJSQVksXG4gICAgICAgICAgICAgICAgICBpdGVtczoge1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBUeXBlLk9CSkVDVCxcbiAgICAgICAgICAgICAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgICAgICAgICAgICAgIGZpZWxkX25hbWU6IHsgdHlwZTogVHlwZS5TVFJJTkcgfSxcbiAgICAgICAgICAgICAgICAgICAgICBjb250ZW50OiB7IHR5cGU6IFR5cGUuU1RSSU5HIH0sXG4gICAgICAgICAgICAgICAgICAgICAgZXZpZGVuY2VfcXVvdGVzOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBUeXBlLkFSUkFZLFxuICAgICAgICAgICAgICAgICAgICAgICAgaXRlbXM6IHsgdHlwZTogVHlwZS5TVFJJTkcgfSxcbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgIGNvbmZpZGVuY2U6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU6IFR5cGUuU1RSSU5HLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVzY3JpcHRpb246ICdoaWdoLCBtZWRpdW0sIG9yIGxvdycsXG4gICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWQ6IFsnZmllbGRfbmFtZScsICdjb250ZW50JywgJ2V2aWRlbmNlX3F1b3RlcycsICdjb25maWRlbmNlJ10sXG4gICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgbWlzc2luZ19maWVsZHM6IHtcbiAgICAgICAgICAgICAgICAgIHR5cGU6IFR5cGUuQVJSQVksXG4gICAgICAgICAgICAgICAgICBpdGVtczoge1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBUeXBlLk9CSkVDVCxcbiAgICAgICAgICAgICAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgICAgICAgICAgICAgIGZpZWxkX25hbWU6IHsgdHlwZTogVHlwZS5TVFJJTkcgfSxcbiAgICAgICAgICAgICAgICAgICAgICBpc3N1ZV9kZXNjcmlwdGlvbjogeyB0eXBlOiBUeXBlLlNUUklORyB9LFxuICAgICAgICAgICAgICAgICAgICAgIHF1aWNrX3F1ZXN0aW9uOiB7IHR5cGU6IFR5cGUuU1RSSU5HIH0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiBbJ2ZpZWxkX25hbWUnLCAnaXNzdWVfZGVzY3JpcHRpb24nXSxcbiAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgcmVxdWlyZWQ6IFsndGl0bGUnLCAnc2VjdGlvbnMnLCAnbWlzc2luZ19maWVsZHMnXSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgcmF3VGV4dCA9IHJlc3BvbnNlLnRleHQ7XG4gICAgICAgIGlmIChyYXdUZXh0KSBicmVhaztcbiAgICAgIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgICAgIGxhc3RFcnJvciA9IGVycjtcbiAgICAgICAgY29uc29sZS53YXJuKGBBdHRlbXB0ICR7YXR0ZW1wdCArIDF9IHdpdGggJHttb2RlbH0gZW5jb3VudGVyZWQ6YCwgZXJyPy5tZXNzYWdlIHx8IGVycik7XG4gICAgICAgIC8vIERlbGF5IDEgc2Vjb25kIGJlZm9yZSByZXRyeWluZ1xuICAgICAgICBhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gc2V0VGltZW91dChyZXNvbHZlLCAxMDAwKSk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChyYXdUZXh0KSBicmVhaztcbiAgfVxuXG4gIHRyeSB7XG4gICAgaWYgKCFyYXdUZXh0KSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzdWNjZXNzOiBmYWxzZSxcbiAgICAgICAgZXJyb3I6IGxhc3RFcnJvcj8ubWVzc2FnZSB8fCAnVGhlIEFJIG1vZGVsIHJldHVybmVkIGFuIGVtcHR5IHJlc3BvbnNlLiBQbGVhc2UgY2hlY2sgeW91ciBub3RlcyBhbmQgcmV0cnkuJyxcbiAgICAgICAgZXJyb3JfdHlwZTogJ2FwaV9lcnJvcicsXG4gICAgICB9O1xuICAgIH1cblxuICAgIGxldCBwYXJzZWQ6IGFueTtcbiAgICB0cnkge1xuICAgICAgcGFyc2VkID0gSlNPTi5wYXJzZShyYXdUZXh0KTtcbiAgICB9IGNhdGNoIChwYXJzZUVycikge1xuICAgICAgLy8gQ2xlYW4gcG9zc2libGUgbWFya2Rvd24gY29kZSBmZW5jZXNcbiAgICAgIGNvbnN0IGNsZWFuZWQgPSByYXdUZXh0LnJlcGxhY2UoL15gYGBqc29uXFxzKi9pLCAnJykucmVwbGFjZSgvYGBgXFxzKiQvLCAnJykudHJpbSgpO1xuICAgICAgcGFyc2VkID0gSlNPTi5wYXJzZShjbGVhbmVkKTtcbiAgICB9XG5cbiAgICBpZiAoIXBhcnNlZCB8fCAhQXJyYXkuaXNBcnJheShwYXJzZWQuc2VjdGlvbnMpIHx8IHBhcnNlZC5zZWN0aW9ucy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICBlcnJvcjogJ0ludmFsaWQgSlNPTiBzdHJ1Y3R1cmUgcmV0dXJuZWQgYnkgbW9kZWwuJyxcbiAgICAgICAgZXJyb3JfdHlwZTogJ3BhcnNlX2ZhaWxlZCcsXG4gICAgICB9O1xuICAgIH1cblxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cbiAgICAvLyBHVUFSRFJBSUwgRU5GT1JDRU1FTlQgSU4gVEhFIEFQUCAoTk9UIEpVU1QgVEhFIFBST01QVClcbiAgICAvLyBcIkFmdGVyIHBhcnNpbmcgdGhlIEFJIHJlc3BvbnNlLCBydW4gYSBzaW1wbGUgdmFsaWRhdGlvbiBwYXNzOiBpZiBhbnkgY29yZSBmaWVsZFxuICAgIC8vIChPd25lciwgRWZmZWN0aXZlIERhdGUsIFByb2Nlc3MgU3RlcHMpIGlzIGVtcHR5IG9yIG1hcmtlZCBtaXNzaW5nLCBpdCBNVVNUXG4gICAgLy8gYXBwZWFyIGluIHRoZSBNaXNzaW5nIEluZm9ybWF0aW9uIGJhbm5lciDigJQgbmV2ZXIgc2lsZW50bHkgZHJvcCBpdC5cIlxuICAgIC8vID09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT1cblxuICAgIGNvbnN0IG1pc3NpbmdNYXAgPSBuZXcgTWFwPHN0cmluZywgTWlzc2luZ0ZpZWxkSXRlbT4oKTtcblxuICAgIC8vIFNlZWQgZnJvbSBBSSByZXNwb25zZVxuICAgIGlmIChBcnJheS5pc0FycmF5KHBhcnNlZC5taXNzaW5nX2ZpZWxkcykpIHtcbiAgICAgIHBhcnNlZC5taXNzaW5nX2ZpZWxkcy5mb3JFYWNoKChtZjogYW55LCBpZHg6IG51bWJlcikgPT4ge1xuICAgICAgICBjb25zdCBuYW1lID0gbWYuZmllbGRfbmFtZSB8fCBgTWlzc2luZyBGaWVsZCAke2lkeCArIDF9YDtcbiAgICAgICAgbWlzc2luZ01hcC5zZXQobmFtZS50b0xvd2VyQ2FzZSgpLCB7XG4gICAgICAgICAgaWQ6IGBtZi0ke2lkeCArIDF9YCxcbiAgICAgICAgICBmaWVsZF9uYW1lOiBuYW1lLFxuICAgICAgICAgIGlzc3VlX2Rlc2NyaXB0aW9uOiBtZi5pc3N1ZV9kZXNjcmlwdGlvbiB8fCBgJHtuYW1lfSB3YXMgbm90IGZvdW5kIGluIHNvdXJjZSBub3Rlc2AsXG4gICAgICAgICAgcXVpY2tfcXVlc3Rpb246IG1mLnF1aWNrX3F1ZXN0aW9uIHx8IGBXaGF0IGlzIHRoZSB2YWx1ZSBmb3IgJHtuYW1lfT9gLFxuICAgICAgICAgIHJlc29sdmVkOiBmYWxzZSxcbiAgICAgICAgICBmaWVsZF90eXBlOiBuYW1lLnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ2RhdGUnKSA/ICdkYXRlJyA6ICd0ZXh0JyxcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICAvLyBDaGVjayBjb3JlIGZpZWxkOiBPd25lclxuICAgIGNvbnN0IG93bmVyVmFsdWUgPSAocGFyc2VkLm93bmVyIHx8ICcnKS50cmltKCk7XG4gICAgY29uc3QgaXNPd25lck1pc3NpbmcgPVxuICAgICAgIW93bmVyVmFsdWUgfHxcbiAgICAgIG93bmVyVmFsdWUuaW5jbHVkZXMoJ1tNSVNTSU5HJykgfHxcbiAgICAgIG93bmVyVmFsdWUudG9Mb3dlckNhc2UoKS5pbmNsdWRlcygnbm90IGZvdW5kJykgfHxcbiAgICAgIG93bmVyVmFsdWUgPT09ICdUQkQnIHx8XG4gICAgICBvd25lclZhbHVlID09PSAnTi9BJztcbiAgICBpZiAoaXNPd25lck1pc3NpbmcpIHtcbiAgICAgIGlmICghbWlzc2luZ01hcC5oYXMoJ3Byb2Nlc3Mgb3duZXInKSAmJiAhbWlzc2luZ01hcC5oYXMoJ293bmVyJykpIHtcbiAgICAgICAgbWlzc2luZ01hcC5zZXQoJ3Byb2Nlc3Mgb3duZXInLCB7XG4gICAgICAgICAgaWQ6IGBtZi1vd25lci0ke0RhdGUubm93KCl9YCxcbiAgICAgICAgICBmaWVsZF9uYW1lOiAnUHJvY2VzcyBPd25lcicsXG4gICAgICAgICAgaXNzdWVfZGVzY3JpcHRpb246ICdQcm9jZXNzIE93bmVyIG5vdCBzcGVjaWZpZWQgaW4gbm90ZXMnLFxuICAgICAgICAgIHF1aWNrX3F1ZXN0aW9uOiAnV2hvIGlzIHRoZSBkZXNpZ25hdGVkIFByb2Nlc3MgT3duZXIgZm9yIHRoaXMgcHJvY2VkdXJlPycsXG4gICAgICAgICAgcmVzb2x2ZWQ6IGZhbHNlLFxuICAgICAgICAgIGZpZWxkX3R5cGU6ICd0ZXh0JyxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgY29yZSBmaWVsZDogRWZmZWN0aXZlIERhdGVcbiAgICBjb25zdCBlZmZlY3RpdmVEYXRlVmFsdWUgPSAocGFyc2VkLmVmZmVjdGl2ZV9kYXRlIHx8ICcnKS50cmltKCk7XG4gICAgY29uc3QgaXNEYXRlTWlzc2luZyA9XG4gICAgICAhZWZmZWN0aXZlRGF0ZVZhbHVlIHx8XG4gICAgICBlZmZlY3RpdmVEYXRlVmFsdWUuaW5jbHVkZXMoJ1tNSVNTSU5HJykgfHxcbiAgICAgIGVmZmVjdGl2ZURhdGVWYWx1ZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKCdub3QgZm91bmQnKSB8fFxuICAgICAgZWZmZWN0aXZlRGF0ZVZhbHVlID09PSAnVEJEJyB8fFxuICAgICAgZWZmZWN0aXZlRGF0ZVZhbHVlID09PSAnTi9BJztcbiAgICBpZiAoaXNEYXRlTWlzc2luZykge1xuICAgICAgaWYgKCFtaXNzaW5nTWFwLmhhcygnZWZmZWN0aXZlIGRhdGUnKSkge1xuICAgICAgICBtaXNzaW5nTWFwLnNldCgnZWZmZWN0aXZlIGRhdGUnLCB7XG4gICAgICAgICAgaWQ6IGBtZi1kYXRlLSR7RGF0ZS5ub3coKX1gLFxuICAgICAgICAgIGZpZWxkX25hbWU6ICdFZmZlY3RpdmUgRGF0ZScsXG4gICAgICAgICAgaXNzdWVfZGVzY3JpcHRpb246ICdFZmZlY3RpdmUgRGF0ZSBtaXNzaW5nIGZyb20gc291cmNlIG5vdGVzJyxcbiAgICAgICAgICBxdWlja19xdWVzdGlvbjogJ1doZW4gc2hvdWxkIHRoaXMgU09QIGJlY29tZSBmb3JtYWxseSBlZmZlY3RpdmU/JyxcbiAgICAgICAgICByZXNvbHZlZDogZmFsc2UsXG4gICAgICAgICAgZmllbGRfdHlwZTogJ2RhdGUnLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBDaGVjayBjb3JlIGZpZWxkOiBQcm9jZXNzIFN0ZXBzXG4gICAgY29uc3Qgc3RlcFNlY3Rpb24gPSBwYXJzZWQuc2VjdGlvbnMuZmluZCgoczogYW55KSA9PlxuICAgICAgcy5maWVsZF9uYW1lPy50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKCdzdGVwJykgfHxcbiAgICAgIHMuZmllbGRfbmFtZT8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcygncHJvY2VkdXJlJykgfHxcbiAgICAgIHMuZmllbGRfbmFtZT8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcygnd29ya2Zsb3cnKVxuICAgICk7XG4gICAgaWYgKCFzdGVwU2VjdGlvbiB8fCAhc3RlcFNlY3Rpb24uY29udGVudCB8fCBzdGVwU2VjdGlvbi5jb250ZW50LmluY2x1ZGVzKCdbTUlTU0lORycpKSB7XG4gICAgICBpZiAoIW1pc3NpbmdNYXAuaGFzKCdwcm9jZXNzIHN0ZXBzJykpIHtcbiAgICAgICAgbWlzc2luZ01hcC5zZXQoJ3Byb2Nlc3Mgc3RlcHMnLCB7XG4gICAgICAgICAgaWQ6IGBtZi1zdGVwcy0ke0RhdGUubm93KCl9YCxcbiAgICAgICAgICBmaWVsZF9uYW1lOiAnUHJvY2VzcyBTdGVwcycsXG4gICAgICAgICAgaXNzdWVfZGVzY3JpcHRpb246ICdTZXF1ZW50aWFsIHByb2Nlc3Mgc3RlcHMgY291bGQgbm90IGJlIGZ1bGx5IGlkZW50aWZpZWQgaW4gbm90ZXMnLFxuICAgICAgICAgIHF1aWNrX3F1ZXN0aW9uOiAnQ2FuIHlvdSBkZXNjcmliZSB0aGUgcHJpbWFyeSAyLTMgc3RlcHMgaW4gdGhpcyBwcm9jZWR1cmU/JyxcbiAgICAgICAgICByZXNvbHZlZDogZmFsc2UsXG4gICAgICAgICAgZmllbGRfdHlwZTogJ3RleHQnLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBtaXNzaW5nRmllbGRzTGlzdDogTWlzc2luZ0ZpZWxkSXRlbVtdID0gQXJyYXkuZnJvbShtaXNzaW5nTWFwLnZhbHVlcygpKTtcblxuICAgIC8vIEZvcm1hdCBzZWN0aW9uc1xuICAgIGNvbnN0IGZvcm1hdHRlZFNlY3Rpb25zOiBTT1BTZWN0aW9uW10gPSBwYXJzZWQuc2VjdGlvbnMubWFwKChzZWM6IGFueSwgaWR4OiBudW1iZXIpID0+IHtcbiAgICAgIGNvbnN0IGNvbmYgPSAoc2VjLmNvbmZpZGVuY2UgfHwgJ21lZGl1bScpLnRvTG93ZXJDYXNlKCk7XG4gICAgICBjb25zdCB2YWxpZENvbmZpZGVuY2UgPSBjb25mID09PSAnaGlnaCcgfHwgY29uZiA9PT0gJ21lZGl1bScgfHwgY29uZiA9PT0gJ2xvdycgPyBjb25mIDogJ21lZGl1bSc7XG5cbiAgICAgIC8vIFBhcnNlIHN1Yi1zdGVwcyBpZiB0aGlzIGlzIGEgcHJvY2VkdXJlIHNlY3Rpb25cbiAgICAgIGxldCBzdWJTdGVwczogYW55W10gfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG4gICAgICBpZiAoc2VjLmZpZWxkX25hbWU/LnRvTG93ZXJDYXNlKCkuaW5jbHVkZXMoJ3N0ZXAnKSB8fCBzZWMuZmllbGRfbmFtZT8udG9Mb3dlckNhc2UoKS5pbmNsdWRlcygncHJvY2VkdXJlJykpIHtcbiAgICAgICAgc3ViU3RlcHMgPSBwYXJzZVN1YlN0ZXBzRnJvbUNvbnRlbnQoc2VjLmNvbnRlbnQsIHNlYy5ldmlkZW5jZV9xdW90ZXMpO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4ge1xuICAgICAgICBpZDogYHNlYy0ke2lkeCArIDF9YCxcbiAgICAgICAgZmllbGRfbmFtZTogc2VjLmZpZWxkX25hbWUgfHwgYFNlY3Rpb24gJHtpZHggKyAxfWAsXG4gICAgICAgIGNvbnRlbnQ6IHNlYy5jb250ZW50IHx8ICcnLFxuICAgICAgICBldmlkZW5jZV9xdW90ZXM6IEFycmF5LmlzQXJyYXkoc2VjLmV2aWRlbmNlX3F1b3RlcykgPyBzZWMuZXZpZGVuY2VfcXVvdGVzIDogW10sXG4gICAgICAgIGNvbmZpZGVuY2U6IHZhbGlkQ29uZmlkZW5jZSxcbiAgICAgICAgdXNlcl9lZGl0ZWQ6IGZhbHNlLFxuICAgICAgICBvcmlnaW5hbF9haV9jb250ZW50OiBzZWMuY29udGVudCB8fCAnJyxcbiAgICAgICAgc3ViX3N0ZXBzOiBzdWJTdGVwcyxcbiAgICAgIH07XG4gICAgfSk7XG5cbiAgICBjb25zdCB0b3RhbENpdGF0aW9ucyA9IGZvcm1hdHRlZFNlY3Rpb25zLnJlZHVjZSgoYWNjLCBzKSA9PiBhY2MgKyBzLmV2aWRlbmNlX3F1b3Rlcy5sZW5ndGgsIDApO1xuXG4gICAgY29uc3QgZG9jdW1lbnQ6IFNPUERvY3VtZW50ID0ge1xuICAgICAgaWQ6IGBzb3AtJHtEYXRlLm5vdygpfWAsXG4gICAgICBjb2RlOiBwYXJzZWQuY29kZSB8fCAnU09QLTg0OTInLFxuICAgICAgdGl0bGU6IHBhcnNlZC50aXRsZSB8fCAnU3RhbmRhcmQgT3BlcmF0aW5nIFByb2NlZHVyZScsXG4gICAgICBkZXBhcnRtZW50OiBwYXJzZWQuZGVwYXJ0bWVudCB8fCAnT3BlcmF0aW9ucyAmIEh1bWFuIFJlc291cmNlcycsXG4gICAgICB2ZXJzaW9uOiBwYXJzZWQudmVyc2lvbiB8fCAnMS4wIChEcmFmdCknLFxuICAgICAgcmV2aWV3X2N5Y2xlOiBwYXJzZWQucmV2aWV3X2N5Y2xlIHx8ICdBbm51YWwnLFxuICAgICAgY29tcGxpYW5jZV9zdGFuZGFyZDogcGFyc2VkLmNvbXBsaWFuY2Vfc3RhbmRhcmQgfHwgJ0lTTyA5MDAxIC8gU09DIDIgVHlwZSBJSScsXG4gICAgICBjbGFzc2lmaWNhdGlvbjogcGFyc2VkLmNsYXNzaWZpY2F0aW9uIHx8ICdJbnRlcm5hbCBDb25maWRlbnRpYWwnLFxuICAgICAgb3duZXI6IGlzT3duZXJNaXNzaW5nID8gJycgOiBwYXJzZWQub3duZXIsXG4gICAgICBlZmZlY3RpdmVfZGF0ZTogaXNEYXRlTWlzc2luZyA/ICcnIDogcGFyc2VkLmVmZmVjdGl2ZV9kYXRlLFxuICAgICAgc3RhdHVzOiAnRFJBRlQnLFxuICAgICAgc2VjdGlvbnM6IGZvcm1hdHRlZFNlY3Rpb25zLFxuICAgICAgbWlzc2luZ19maWVsZHM6IG1pc3NpbmdGaWVsZHNMaXN0LFxuICAgICAgc291cmNlX25vdGVzOiBub3RlcyxcbiAgICAgIHRvbmU6IHJlcS50b25lLFxuICAgICAgdGVtcGxhdGVfdHlwZTogcmVxLnRlbXBsYXRlVHlwZSxcbiAgICAgIGNyZWF0ZWRfYXQ6IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKSxcbiAgICAgIHN0YXRzOiB7XG4gICAgICAgIHdvcmRDb3VudDogd29yZENvdW50LFxuICAgICAgICByZWFkVGltZU1pbjogTWF0aC5tYXgoMSwgTWF0aC5jZWlsKHdvcmRDb3VudCAvIDIwMCkpLFxuICAgICAgICBjaXRhdGlvbnNDb3VudDogdG90YWxDaXRhdGlvbnMsXG4gICAgICB9LFxuICAgIH07XG5cbiAgICByZXR1cm4ge1xuICAgICAgc3VjY2VzczogdHJ1ZSxcbiAgICAgIGRvY3VtZW50LFxuICAgIH07XG4gIH0gY2F0Y2ggKGVycjogYW55KSB7XG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgY2FsbGluZyBHZW1pbmkgQVBJOicsIGVycik7XG4gICAgcmV0dXJuIHtcbiAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgZXJyb3I6IGVycj8ubWVzc2FnZSB8fCAnRmFpbGVkIHRvIGdlbmVyYXRlIFNPUCBmcm9tIG5vdGVzLiBQbGVhc2UgY2hlY2sgdGhlIGlucHV0IGFuZCB0cnkgYWdhaW4uJyxcbiAgICAgIGVycm9yX3R5cGU6ICdhcGlfZXJyb3InLFxuICAgIH07XG4gIH1cbn1cblxuZnVuY3Rpb24gcGFyc2VTdWJTdGVwc0Zyb21Db250ZW50KGNvbnRlbnQ6IHN0cmluZywgZXZpZGVuY2VRdW90ZXM6IHN0cmluZ1tdID0gW10pOiBBcnJheTx7IHN0ZXBfbnVtYmVyOiBudW1iZXI7IHRpdGxlOiBzdHJpbmc7IGRlc2NyaXB0aW9uOiBzdHJpbmc7IHNsYT86IHN0cmluZzsgZXZpZGVuY2U/OiBzdHJpbmcgfT4gfCB1bmRlZmluZWQge1xuICBjb25zdCBsaW5lcyA9IGNvbnRlbnQuc3BsaXQoJ1xcbicpLm1hcCgobCkgPT4gbC50cmltKCkpLmZpbHRlcihCb29sZWFuKTtcbiAgY29uc3Qgc3RlcHM6IEFycmF5PHsgc3RlcF9udW1iZXI6IG51bWJlcjsgdGl0bGU6IHN0cmluZzsgZGVzY3JpcHRpb246IHN0cmluZzsgc2xhPzogc3RyaW5nOyBldmlkZW5jZT86IHN0cmluZyB9PiA9IFtdO1xuXG4gIGxldCBjdXJyZW50U3RlcDogeyBzdGVwX251bWJlcjogbnVtYmVyOyB0aXRsZTogc3RyaW5nOyBkZXNjcmlwdGlvbjogc3RyaW5nOyBzbGE/OiBzdHJpbmc7IGV2aWRlbmNlPzogc3RyaW5nIH0gfCBudWxsID0gbnVsbDtcbiAgbGV0IGNvdW50ZXIgPSAxO1xuXG4gIGZvciAoY29uc3QgbGluZSBvZiBsaW5lcykge1xuICAgIGNvbnN0IHN0ZXBNYXRjaCA9IGxpbmUubWF0Y2goL14oPzpTdGVwXFxzKik/KFxcZCspWzouKVxcLV1cXHMqKC4qKS9pKTtcbiAgICBpZiAoc3RlcE1hdGNoKSB7XG4gICAgICBpZiAoY3VycmVudFN0ZXApIHtcbiAgICAgICAgc3RlcHMucHVzaChjdXJyZW50U3RlcCk7XG4gICAgICB9XG4gICAgICBjb25zdCByYXdUaXRsZSA9IHN0ZXBNYXRjaFsyXS50cmltKCk7XG4gICAgICBsZXQgc2xhID0gdW5kZWZpbmVkO1xuICAgICAgY29uc3Qgc2xhTWF0Y2ggPSByYXdUaXRsZS5tYXRjaCgvKD86U0xBfHdpdGhpbnxkYXl8aG91cnM/KTpcXHMqKFthLXpBLVowLTlcXHMrLV0rKS9pKTtcbiAgICAgIGlmIChzbGFNYXRjaCkge1xuICAgICAgICBzbGEgPSBzbGFNYXRjaFsxXS50cmltKCk7XG4gICAgICB9XG5cbiAgICAgIGN1cnJlbnRTdGVwID0ge1xuICAgICAgICBzdGVwX251bWJlcjogcGFyc2VJbnQoc3RlcE1hdGNoWzFdLCAxMCkgfHwgY291bnRlcisrLFxuICAgICAgICB0aXRsZTogcmF3VGl0bGUucmVwbGFjZSgvXFxzKlxcKD9TTEE6Lio/XFwpPy9pLCAnJyksXG4gICAgICAgIGRlc2NyaXB0aW9uOiAnJyxcbiAgICAgICAgc2xhLFxuICAgICAgfTtcbiAgICB9IGVsc2UgaWYgKGN1cnJlbnRTdGVwKSB7XG4gICAgICBjdXJyZW50U3RlcC5kZXNjcmlwdGlvbiArPSAoY3VycmVudFN0ZXAuZGVzY3JpcHRpb24gPyAnICcgOiAnJykgKyBsaW5lO1xuICAgIH1cbiAgfVxuXG4gIGlmIChjdXJyZW50U3RlcCkge1xuICAgIHN0ZXBzLnB1c2goY3VycmVudFN0ZXApO1xuICB9XG5cbiAgcmV0dXJuIHN0ZXBzLmxlbmd0aCA+IDAgPyBzdGVwcyA6IHVuZGVmaW5lZDtcbn1cbiJdfQ==